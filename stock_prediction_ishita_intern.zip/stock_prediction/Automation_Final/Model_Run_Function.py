""""
The script has 3 functions.
1. create_Target - To create target variable before model Training
2. get_top_n_stocks - The function uses TI data with target varaible to train model and predict stocks.
3. Back_Test - A function that sorts the data and calls create_Target function and get_top_n_stocks function. 

"""


def create_Target(df,**kwargs):
    """"
    The Target variable of more than 4% in 5 days is created using create_Target function.
    Input-
    Dataframe with columns (nse_symbol, date, close)
    
    Output-
    Dataframe with input data and additional 2 columns (Returns_5D, Target_1).
    """
    import pandas as pd
    import numpy as np
    
    df.sort_values(by ='date', ascending = True,inplace=True)

    #Target Creation
    df['Returns_5D'] = df.groupby('nse_symbol')['close'].apply(lambda x: (x.shift(-5)- x)/x *100).reset_index(drop = True)
    df['Target_1']= (df['Returns_5D'] > 4).astype(int)
    
    return df

def get_top_n_stocks(df, **kwargs):
    
    #Import Libraries
    import pandas as pd
    import numpy as np
    import xgboost as xgb
    from sklearn.model_selection import RandomizedSearchCV
    from sklearn.metrics import precision_score, make_scorer
    from sklearn.model_selection import train_test_split
    from keras.models import Sequential
    from keras.layers import Dense, LSTM
    from keras.metrics import Precision
    import keras
    from tensorflow.keras.layers import LeakyReLU
    from tensorflow.keras.optimizers import Nadam

    """"
    The Function Returns a two Dataframes-
    1. Dataframe with top "n" stocks
    2. Dataframe with count of actual '1' per date by using model
    
    The input parameters-
    1. df(dataframe): Dataframe with 'date' & 'nse_symbol' as index columns. The dataframe is considered to have fetaures along with ('Target_1','Target_2','Returns_5D','Returns_1D') as columns in Dataframe.
    
    2. day_of_week(string): It is the day of week for which model needs to be trained. Default is 'Friday'. Can take values as ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                            Note: There should data for specified 'day_of_week' else the function would not get executed.
    
    3. test_date(string) : The date specified must be in 'yyyy-mm-dd' format. The parameter is used to set a date from which we want to test model performance.
                           That is, the test_date is used to find all the 'day_of_week' post test_date. In conclusion, model will be trained for every 'day_of_week' on & post 'test_date'.
                           If the parameter is not specified, the function finds the last occurence of 'day_of_week' & takes the corresponding date as 'test_date'.
    
    4. no_of_days(int): The period to be considered for training (in days) (Default: 90 days training). That is,leaving 5 dates before the prediction date,  90 dates avaialbe in dataframe will be considered for training.    
    
    5. top_n (int): No. of top stocks needed from the model. (Default: 10)
    """
    
    
    test_date   =kwargs.get('test_date', None)
    day_of_week =kwargs.get('day_of_week','Friday')
    no_of_days  =kwargs.get('no_of_days', 30)
    top_n =kwargs.get('top_n',10)
    
    # Check if 'date' and 'nse_symbol' columns are in the index
    if 'date' not in df.index.names and 'nse_symbol' not in df.index.names:
        df.set_index(['date', 'nse_symbol'], inplace=True)

    categorical = ['nse_symbol', 'Indi_ADL_gt_SMA_ADL', 'Indicator_ADL_5_Slope', 'Indicator_Slope5_ADL', 'Indicator_ADL_10_Slope', 'Indicator_Slope10_ADL', 'Indicator_ADL_15_Slope', 'Indicator_Slope15_ADL', 'Indicator_ADL_20_Slope', 'Indicator_Slope20_ADL', 'ADX_Indicator', 'UorD_25', 'Indi_DI_cross', 'plusDI_cross_from_below', 'plusDI_cross_from_above', 'No_of_times_DI_cross_5D', 'plusDI_cross_from_below_5D', 'plusDI_cross_from_above_5D', 'No_of_times_DI_cross_10D', 'plusDI_cross_from_below_10D', 'plusDI_cross_from_above_10D', 'No_of_times_DI_cross_15D', 'plusDI_cross_from_below_15D', 'plusDI_cross_from_above_15D', 'No_of_times_DI_cross_20D', 'plusDI_cross_from_below_20D', 'plusDI_cross_from_above_20D', 'Indicator_ATR', 'Indi_ATR_gtAV_ATR_5D', 'Indi_ATR_gtAV_ATR_10D', 'Indi_ATR_gtAV_ATR_15D', 'Indi_ATR_gtAV_ATR_20D', 'Indicator_EOM_5Slope', 'Indi_EOM_gt_crossover', 'Indi_EOM_lt_crossover', 'Indi_EOM_slope_cross', 'Indicator_EOM_10Slope', 'Indicator_EOM_15Slope', 'Indicator_EOM_20Slope', 'Force_cross_Up_gt', 'Force_cross_Up_lt', 'Indi_Force_cross', 'Indi_keltnerU_gt_crossover', 'Indi_keltnerU_lt_crossover', 'Indi_keltnerL_gt_crossover', 'Indi_keltnerL_lt_crossover', 'Keltner_Indicator', 'Indicator_macd_12f_26s_gt_Signal', 'Indi_MACD_12f_26s_cross_SIGNAL', 'Indi_MACD_12f_26s_lt_signal', 'Indi_MACD_12f_26s_gt_signal', 'Indicator_macd_12f_52s_gt_Signal', 'Indi_MACD_12f_52s_cross_SIGNAL', 'Indi_MACD_12f_52s_lt_signal', 'Indi_MACD_12f_52s_gt_signal', 'Indicator_macd_12f_78s_gt_Signal', 'Indi_MACD_12f_78s_cross_SIGNAL', 'Indi_MACD_12f_78s_lt_signal', 'Indi_MACD_12f_78s_gt_signal', 'Indicator_macd_12f_104s_gt_Signal', 'Indi_MACD_12f_104s_cross_SIGNAL', 'Indi_MACD_12f_104s_lt_signal', 'Indi_MACD_12f_104s_gt_signal', 'Indicator_macd_24f_26s_gt_Signal', 'Indi_MACD_24f_26s_cross_SIGNAL', 'Indi_MACD_24f_26s_lt_signal', 'Indi_MACD_24f_26s_gt_signal', 'Indicator_macd_24f_52s_gt_Signal', 'Indi_MACD_24f_52s_cross_SIGNAL', 'Indi_MACD_24f_52s_lt_signal', 'Indi_MACD_24f_52s_gt_signal', 'Indicator_macd_24f_78s_gt_Signal', 'Indi_MACD_24f_78s_cross_SIGNAL', 'Indi_MACD_24f_78s_lt_signal', 'Indi_MACD_24f_78s_gt_signal', 'Indicator_macd_24f_104s_gt_Signal', 'Indi_MACD_24f_104s_cross_SIGNAL', 'Indi_MACD_24f_104s_lt_signal', 'Indi_MACD_24f_104s_gt_signal', 'Indicator_macd_36f_52s_gt_Signal', 'Indi_MACD_36f_52s_cross_SIGNAL', 'Indi_MACD_36f_52s_lt_signal', 'Indi_MACD_36f_52s_gt_signal', 'Indicator_macd_36f_78s_gt_Signal', 'Indi_MACD_36f_78s_cross_SIGNAL', 'Indi_MACD_36f_78s_lt_signal', 'Indi_MACD_36f_78s_gt_signal', 'Indicator_macd_36f_104s_gt_Signal', 'Indi_MACD_36f_104s_cross_SIGNAL', 'Indi_MACD_36f_104s_lt_signal', 'Indi_MACD_36f_104s_gt_signal', 'Indicator_macd_48f_52s_gt_Signal', 'Indi_MACD_48f_52s_cross_SIGNAL', 'Indi_MACD_48f_52s_lt_signal', 'Indi_MACD_48f_52s_gt_signal', 'Indicator_macd_48f_78s_gt_Signal', 'Indi_MACD_48f_78s_cross_SIGNAL', 'Indi_MACD_48f_78s_lt_signal', 'Indi_MACD_48f_78s_gt_signal', 'Indicator_macd_48f_104s_gt_Signal', 'Indi_MACD_48f_104s_cross_SIGNAL', 'Indi_MACD_48f_104s_lt_signal', 'Indi_MACD_48f_104s_gt_signal', 'Indicator_SAR1', 'Indicator_SAR', 'Parabolic_SAR_cross_gt', 'Parabolic_SAR_cross_lt', 'Indi_Parabolic_SAR_cross', 'Indicator_PVO_12f_26s', 'Indi_PVO_12f_26s_gt_crossover', 'Indi_PVO_12f_26s_lt_crossover', 'Indicator_PVO_12f_52s', 'Indi_PVO_12f_52s_gt_crossover', 'Indi_PVO_12f_52s_lt_crossover', 'Indicator_PVO_12f_78s', 'Indi_PVO_12f_78s_gt_crossover', 'Indi_PVO_12f_78s_lt_crossover', 'Indicator_PVO_12f_104s', 'Indi_PVO_12f_104s_gt_crossover', 'Indi_PVO_12f_104s_lt_crossover', 'Indicator_PVO_24f_26s', 'Indi_PVO_24f_26s_gt_crossover', 'Indi_PVO_24f_26s_lt_crossover', 'Indicator_PVO_24f_52s', 'Indi_PVO_24f_52s_gt_crossover', 'Indi_PVO_24f_52s_lt_crossover', 'Indicator_PVO_24f_78s', 'Indi_PVO_24f_78s_gt_crossover', 'Indi_PVO_24f_78s_lt_crossover', 'Indicator_PVO_24f_104s', 'Indi_PVO_24f_104s_gt_crossover', 'Indi_PVO_24f_104s_lt_crossover', 'Indicator_PVO_36f_52s', 'Indi_PVO_36f_52s_gt_crossover', 'Indi_PVO_36f_52s_lt_crossover', 'Indicator_PVO_36f_78s', 'Indi_PVO_36f_78s_gt_crossover', 'Indi_PVO_36f_78s_lt_crossover', 'Indicator_PVO_36f_104s', 'Indi_PVO_36f_104s_gt_crossover', 'Indi_PVO_36f_104s_lt_crossover', 'Indicator_PVO_48f_52s', 'Indi_PVO_48f_52s_gt_crossover', 'Indi_PVO_48f_52s_lt_crossover', 'Indicator_PVO_48f_78s', 'Indi_PVO_48f_78s_gt_crossover', 'Indi_PVO_48f_78s_lt_crossover', 'Indicator_PVO_48f_104s', 'Indi_PVO_48f_104s_gt_crossover', 'Indi_PVO_48f_104s_lt_crossover', 'golden_cross_stochastic', 'Death_cross_stochastic', 'Indicator_VPT', 'Indi_VPT_gt_crossover', 'Indi_VPT_lt_crossover', 'Indi_VPT_signal_cross', 'ADX_gt25_vpt_gt_Signal', 'ADX_lt25_vpt_lt_Signal', 'Indi_Dist_close_VWAP', 'Indi_VWAP_lt_crossover', 'Indi_VWAP_gt_crossover', 'Indi_VWAP_close_cross', 'WILLR_Indicator', 'If_WILLR_UB', 'Indi_WILLR_gt_crossover', 'Indi_WILLR_lt_crossover', 'compare_open_close', 'Doji', 'ROC_gt_0_or_not', 'ROC_Thresholds', 'Indicator_Cross_of_Slow_SMA_of_PVI_and_Fast_SMA_of_PVI', 'golden_cross_of_Slow_SMA_of_PVI_and_Fast_SMA_of_PVI_Indicator', 'death_cross_of_Slow_SMA_of_PVI_and_Fast_SMA_of_PVI_Indicator', 'Indicator_MFI_and_SMA_of_MFI_20_Cross', 'golden_cross_MFI_and_SMA_of_MFI_20Indicator_5D', 'death_cross_MFI_and_SMA_of_MFI_20Indicator_5D', 'golden_cross_MFI_and_SMA_of_MFI_20Indicator_10D', 'death_cross_MFI_and_SMA_of_MFI_20Indicator_10D', 'golden_cross_MFI_and_SMA_of_MFI_20Indicator_15D', 'death_cross_MFI_and_SMA_of_MFI_20Indicator_15D', 'golden_cross_MFI_and_SMA_of_MFI_20Indicator_20D', 'death_cross_MFI_and_SMA_of_MFI_20Indicator_20D', 'compare_close_and_UpperBB', 'compare_close_and_LowerBB', 'Cross_of_CMF_and_0_paired_with_EMA5_Indicator', 'golden_cross_CMF_and_0_paired_with_EMA5_Indicator_5D', 'death_cross_CMF_and_0_paired_with_EMA5_Indicator_5D', 'Cross_of_CMF_and_0_paired_with_EMA10_Indicator', 'golden_cross_CMF_and_0_paired_with_EMA10_Indicator_5D', 'death_cross_CMF_and_0_paired_with_EMA10_Indicator_5D', 'Cross_of_CMF_and_0_paired_with_EMA15_Indicator', 'golden_cross_CMF_and_0_paired_with_EMA15_Indicator_5D', 'death_cross_CMF_and_0_paired_with_EMA15_Indicator_5D', 'Cross_of_CMF_and_0_paired_with_EMA20_Indicator', 'golden_cross_CMF_and_0_paired_with_EMA20_Indicator_5D', 'death_cross_CMF_and_0_paired_with_EMA20_Indicator_5D', 'golden_cross_CMF_and_0_paired_with_EMA5_Indicator_10D', 'death_cross_CMF_and_0_paired_with_EMA5_Indicator_10D', 'golden_cross_CMF_and_0_paired_with_EMA10_Indicator_10D', 'death_cross_CMF_and_0_paired_with_EMA10_Indicator_10D', 'golden_cross_CMF_and_0_paired_with_EMA15_Indicator_10D', 'death_cross_CMF_and_0_paired_with_EMA15_Indicator_10D', 'golden_cross_CMF_and_0_paired_with_EMA20_Indicator_10D', 'death_cross_CMF_and_0_paired_with_EMA20_Indicator_10D', 'golden_cross_CMF_and_0_paired_with_EMA5_Indicator_15D', 'death_cross_CMF_and_0_paired_with_EMA5_Indicator_15D', 'golden_cross_CMF_and_0_paired_with_EMA10_Indicator_15D', 'death_cross_CMF_and_0_paired_with_EMA10_Indicator_15D', 'golden_cross_CMF_and_0_paired_with_EMA15_Indicator_15D', 'death_cross_CMF_and_0_paired_with_EMA15_Indicator_15D', 'golden_cross_CMF_and_0_paired_with_EMA20_Indicator_15D', 'death_cross_CMF_and_0_paired_with_EMA20_Indicator_15D', 'golden_cross_CMF_and_0_paired_with_EMA5_Indicator_20D', 'death_cross_CMF_and_0_paired_with_EMA5_Indicator_20D', 'golden_cross_CMF_and_0_paired_with_EMA10_Indicator_20D', 'death_cross_CMF_and_0_paired_with_EMA10_Indicator_20D', 'golden_cross_CMF_and_0_paired_with_EMA15_Indicator_20D', 'death_cross_CMF_and_0_paired_with_EMA15_Indicator_20D', 'golden_cross_CMF_and_0_paired_with_EMA20_Indicator_20D', 'death_cross_CMF_and_0_paired_with_EMA20_Indicator_20D', 'Compare_Today_and_Yesterday_OBV', 'Indicator_for_Cross_of_OBV_and_SMA_of_OBV_10', 'golden_cross_OBV_and_SMA_of_OBV_10Indicator_5D', 'death_cross_OBV_and_SMA_of_OBV_10Indicator_5D', 'Indicator_for_Cross_of_OBV_and_SMA_of_OBV_40', 'golden_cross_OBV_and_SMA_of_OBV_40Indicator_5D', 'death_cross_OBV_and_SMA_of_OBV_40Indicator_5D', 'Indicator_for_Cross_of_OBV_and_SMA_of_OBV_70', 'golden_cross_OBV_and_SMA_of_OBV_70Indicator_5D', 'death_cross_OBV_and_SMA_of_OBV_70Indicator_5D', 'Indicator_for_Cross_of_OBV_and_SMA_of_OBV_100', 'golden_cross_OBV_and_SMA_of_OBV_100Indicator_5D', 'death_cross_OBV_and_SMA_of_OBV_100Indicator_5D', 'golden_cross_OBV_and_SMA_of_OBV_10Indicator_10D', 'death_cross_OBV_and_SMA_of_OBV_10Indicator_10D', 'golden_cross_OBV_and_SMA_of_OBV_40Indicator_10D', 'death_cross_OBV_and_SMA_of_OBV_40Indicator_10D', 'golden_cross_OBV_and_SMA_of_OBV_70Indicator_10D', 'death_cross_OBV_and_SMA_of_OBV_70Indicator_10D', 'golden_cross_OBV_and_SMA_of_OBV_100Indicator_10D', 'death_cross_OBV_and_SMA_of_OBV_100Indicator_10D', 'golden_cross_OBV_and_SMA_of_OBV_10Indicator_15D', 'death_cross_OBV_and_SMA_of_OBV_10Indicator_15D', 'golden_cross_OBV_and_SMA_of_OBV_40Indicator_15D', 'death_cross_OBV_and_SMA_of_OBV_40Indicator_15D', 'golden_cross_OBV_and_SMA_of_OBV_70Indicator_15D', 'death_cross_OBV_and_SMA_of_OBV_70Indicator_15D', 'golden_cross_OBV_and_SMA_of_OBV_100Indicator_15D', 'death_cross_OBV_and_SMA_of_OBV_100Indicator_15D', 'golden_cross_OBV_and_SMA_of_OBV_10Indicator_20D', 'death_cross_OBV_and_SMA_of_OBV_10Indicator_20D', 'golden_cross_OBV_and_SMA_of_OBV_40Indicator_20D', 'death_cross_OBV_and_SMA_of_OBV_40Indicator_20D', 'golden_cross_OBV_and_SMA_of_OBV_70Indicator_20D', 'death_cross_OBV_and_SMA_of_OBV_70Indicator_20D', 'golden_cross_OBV_and_SMA_of_OBV_100Indicator_20D', 'death_cross_OBV_and_SMA_of_OBV_100Indicator_20D', 'Indicator_Cross_Alligator', 'golden_cross_Alligator_Indicator_5D', 'death_cross_Alligator_Indicator_5D', 'golden_cross_Alligator_Indicator_10D', 'death_cross_Alligator_Indicator_10D', 'golden_cross_Alligator_Indicator_15D', 'death_cross_Alligator_Indicator_15D', 'golden_cross_Alligator_Indicator_20D', 'death_cross_Alligator_Indicator_20D', 'cci_Thresholds_Indicator', 'compare_Conversion_Baseline_Ichimoku', 'Indicator_Cross_of_Conversion_and_Baseline', 'compare_LeadingA_LeadingB_ichimoku', 'Indicator_golden_cross_of_Conversion_and_Baseline_5D', 'Indicator_death_cross_of_Conversion_and_Baseline_5D', 'Indicator_golden_cross_of_Conversion_and_Baseline_10D', 'Indicator_death_cross_of_Conversion_and_Baseline_10D', 'Indicator_golden_cross_of_Conversion_and_Baseline_15D', 'Indicator_death_cross_of_Conversion_and_Baseline_15D', 'Indicator_golden_cross_of_Conversion_and_Baseline_20D', 'Indicator_death_cross_of_Conversion_and_Baseline_20D', 'Indicator_Cross_KAMA_Fast_14Slow28', 'Indicator_golden_cross_KAMA_Fast_14Slow_28_5D', 'Indicator_death_cross_KAMA_Fast_14Slow_28_5D', 'Indicator_golden_cross_KAMA_Fast_14Slow_28_10D', 'Indicator_death_cross_KAMA_Fast_14Slow_28_10D', 'Indicator_golden_cross_KAMA_Fast_14Slow_28_15D', 'Indicator_death_cross_KAMA_Fast_14Slow_28_15D', 'Indicator_golden_cross_KAMA_Fast_14Slow_28_20D', 'Indicator_death_cross_KAMA_Fast_14Slow_28_20D', 'Indicator_Cross_KAMA_Fast_14Slow56', 'Indicator_golden_cross_KAMA_Fast_14Slow_56_5D', 'Indicator_death_cross_KAMA_Fast_14Slow_56_5D', 'Indicator_golden_cross_KAMA_Fast_14Slow_56_10D', 'Indicator_death_cross_KAMA_Fast_14Slow_56_10D', 'Indicator_golden_cross_KAMA_Fast_14Slow_56_15D', 'Indicator_death_cross_KAMA_Fast_14Slow_56_15D', 'Indicator_golden_cross_KAMA_Fast_14Slow_56_20D', 'Indicator_death_cross_KAMA_Fast_14Slow_56_20D', 'Indicator_Cross_KAMA_Fast_14Slow84', 'Indicator_golden_cross_KAMA_Fast_14Slow_84_5D', 'Indicator_death_cross_KAMA_Fast_14Slow_84_5D', 'Indicator_golden_cross_KAMA_Fast_14Slow_84_10D', 'Indicator_death_cross_KAMA_Fast_14Slow_84_10D', 'Indicator_golden_cross_KAMA_Fast_14Slow_84_15D', 'Indicator_death_cross_KAMA_Fast_14Slow_84_15D', 'Indicator_golden_cross_KAMA_Fast_14Slow_84_20D', 'Indicator_death_cross_KAMA_Fast_14Slow_84_20D', 'Indicator_Cross_KAMA_Fast_14Slow112', 'Indicator_golden_cross_KAMA_Fast_14Slow_112_5D', 'Indicator_death_cross_KAMA_Fast_14Slow_112_5D', 'Indicator_golden_cross_KAMA_Fast_14Slow_112_10D', 'Indicator_death_cross_KAMA_Fast_14Slow_112_10D', 'Indicator_golden_cross_KAMA_Fast_14Slow_112_15D', 'Indicator_death_cross_KAMA_Fast_14Slow_112_15D', 'Indicator_golden_cross_KAMA_Fast_14Slow_112_20D', 'Indicator_death_cross_KAMA_Fast_14Slow_112_20D', 'Indicator_Cross_KAMA_Fast_28Slow56', 'Indicator_golden_cross_KAMA_Fast_28Slow_56_5D', 'Indicator_death_cross_KAMA_Fast_28Slow_56_5D', 'Indicator_golden_cross_KAMA_Fast_28Slow_56_10D', 'Indicator_death_cross_KAMA_Fast_28Slow_56_10D', 'Indicator_golden_cross_KAMA_Fast_28Slow_56_15D', 'Indicator_death_cross_KAMA_Fast_28Slow_56_15D', 'Indicator_golden_cross_KAMA_Fast_28Slow_56_20D', 'Indicator_death_cross_KAMA_Fast_28Slow_56_20D', 'Indicator_Cross_KAMA_Fast_28Slow84', 'Indicator_golden_cross_KAMA_Fast_28Slow_84_5D', 'Indicator_death_cross_KAMA_Fast_28Slow_84_5D', 'Indicator_golden_cross_KAMA_Fast_28Slow_84_10D', 'Indicator_death_cross_KAMA_Fast_28Slow_84_10D', 'Indicator_golden_cross_KAMA_Fast_28Slow_84_15D', 'Indicator_death_cross_KAMA_Fast_28Slow_84_15D', 'Indicator_golden_cross_KAMA_Fast_28Slow_84_20D', 'Indicator_death_cross_KAMA_Fast_28Slow_84_20D', 'Indicator_Cross_KAMA_Fast_28Slow112', 'Indicator_golden_cross_KAMA_Fast_28Slow_112_5D', 'Indicator_death_cross_KAMA_Fast_28Slow_112_5D', 'Indicator_golden_cross_KAMA_Fast_28Slow_112_10D', 'Indicator_death_cross_KAMA_Fast_28Slow_112_10D', 'Indicator_golden_cross_KAMA_Fast_28Slow_112_15D', 'Indicator_death_cross_KAMA_Fast_28Slow_112_15D', 'Indicator_golden_cross_KAMA_Fast_28Slow_112_20D', 'Indicator_death_cross_KAMA_Fast_28Slow_112_20D', 'Indicator_Cross_KAMA_Fast_42Slow56', 'Indicator_golden_cross_KAMA_Fast_42Slow_56_5D', 'Indicator_death_cross_KAMA_Fast_42Slow_56_5D', 'Indicator_golden_cross_KAMA_Fast_42Slow_56_10D', 'Indicator_death_cross_KAMA_Fast_42Slow_56_10D', 'Indicator_golden_cross_KAMA_Fast_42Slow_56_15D', 'Indicator_death_cross_KAMA_Fast_42Slow_56_15D', 'Indicator_golden_cross_KAMA_Fast_42Slow_56_20D', 'Indicator_death_cross_KAMA_Fast_42Slow_56_20D', 'Indicator_Cross_KAMA_Fast_42Slow84', 'Indicator_golden_cross_KAMA_Fast_42Slow_84_5D', 'Indicator_death_cross_KAMA_Fast_42Slow_84_5D', 'Indicator_golden_cross_KAMA_Fast_42Slow_84_10D', 'Indicator_death_cross_KAMA_Fast_42Slow_84_10D', 'Indicator_golden_cross_KAMA_Fast_42Slow_84_15D', 'Indicator_death_cross_KAMA_Fast_42Slow_84_15D', 'Indicator_golden_cross_KAMA_Fast_42Slow_84_20D', 'Indicator_death_cross_KAMA_Fast_42Slow_84_20D', 'Indicator_Cross_KAMA_Fast_42Slow112', 'Indicator_golden_cross_KAMA_Fast_42Slow_112_5D', 'Indicator_death_cross_KAMA_Fast_42Slow_112_5D', 'Indicator_golden_cross_KAMA_Fast_42Slow_112_10D', 'Indicator_death_cross_KAMA_Fast_42Slow_112_10D', 'Indicator_golden_cross_KAMA_Fast_42Slow_112_15D', 'Indicator_death_cross_KAMA_Fast_42Slow_112_15D', 'Indicator_golden_cross_KAMA_Fast_42Slow_112_20D', 'Indicator_death_cross_KAMA_Fast_42Slow_112_20D', 'Indicator_Cross_KAMA_Fast_56Slow84', 'Indicator_golden_cross_KAMA_Fast_56Slow_84_5D', 'Indicator_death_cross_KAMA_Fast_56Slow_84_5D', 'Indicator_golden_cross_KAMA_Fast_56Slow_84_10D', 'Indicator_death_cross_KAMA_Fast_56Slow_84_10D', 'Indicator_golden_cross_KAMA_Fast_56Slow_84_15D', 'Indicator_death_cross_KAMA_Fast_56Slow_84_15D', 'Indicator_golden_cross_KAMA_Fast_56Slow_84_20D', 'Indicator_death_cross_KAMA_Fast_56Slow_84_20D', 'Indicator_Cross_KAMA_Fast_56Slow112', 'Indicator_golden_cross_KAMA_Fast_56Slow_112_5D', 'Indicator_death_cross_KAMA_Fast_56Slow_112_5D', 'Indicator_golden_cross_KAMA_Fast_56Slow_112_10D', 'Indicator_death_cross_KAMA_Fast_56Slow_112_10D', 'Indicator_golden_cross_KAMA_Fast_56Slow_112_15D', 'Indicator_death_cross_KAMA_Fast_56Slow_112_15D', 'Indicator_golden_cross_KAMA_Fast_56Slow_112_20D', 'Indicator_death_cross_KAMA_Fast_56Slow_112_20D', 'Compare_close_and_Fast_SMA_5_10', 'Compare_close_and_Slow_SMA_10_5', 'Indicator_for_Cross_of_Fast_SMA_5_Slow_SMA_10', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_10_5D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_10_5D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_10_10D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_10_10D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_10_15D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_10_15D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_10_20D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_10_20D', 'Compare_close_and_Fast_SMA_5_20', 'Compare_close_and_Slow_SMA_20_5', 'Indicator_for_Cross_of_Fast_SMA_5_Slow_SMA_20', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_20_5D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_20_5D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_20_10D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_20_10D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_20_15D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_20_15D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_20_20D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_20_20D', 'Compare_close_and_Fast_SMA_5_40', 'Compare_close_and_Slow_SMA_40_5', 'Indicator_for_Cross_of_Fast_SMA_5_Slow_SMA_40', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_40_5D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_40_5D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_40_10D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_40_10D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_40_15D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_40_15D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_40_20D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_40_20D', 'Compare_close_and_Fast_SMA_5_80', 'Compare_close_and_Slow_SMA_80_5', 'Indicator_for_Cross_of_Fast_SMA_5_Slow_SMA_80', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_80_5D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_80_5D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_80_10D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_80_10D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_80_15D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_80_15D', 'Indicator_for_golden_cross_of_Fast_SMA_5_Slow_SMA_80_20D', 'Indicator_for_death_cross_of_Fast_SMA_5_Slow_SMA_80_20D', 'Compare_close_and_Fast_SMA_10_20', 'Compare_close_and_Slow_SMA_20_10', 'Indicator_for_Cross_of_Fast_SMA_10_Slow_SMA_20', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_20_5D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_20_5D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_20_10D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_20_10D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_20_15D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_20_15D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_20_20D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_20_20D', 'Compare_close_and_Fast_SMA_10_40', 'Compare_close_and_Slow_SMA_40_10', 'Indicator_for_Cross_of_Fast_SMA_10_Slow_SMA_40', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_40_5D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_40_5D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_40_10D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_40_10D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_40_15D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_40_15D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_40_20D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_40_20D', 'Compare_close_and_Fast_SMA_10_80', 'Compare_close_and_Slow_SMA_80_10', 'Indicator_for_Cross_of_Fast_SMA_10_Slow_SMA_80', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_80_5D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_80_5D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_80_10D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_80_10D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_80_15D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_80_15D', 'Indicator_for_golden_cross_of_Fast_SMA_10_Slow_SMA_80_20D', 'Indicator_for_death_cross_of_Fast_SMA_10_Slow_SMA_80_20D', 'Compare_close_and_Fast_SMA_15_20', 'Compare_close_and_Slow_SMA_20_15', 'Indicator_for_Cross_of_Fast_SMA_15_Slow_SMA_20', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_20_5D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_20_5D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_20_10D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_20_10D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_20_15D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_20_15D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_20_20D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_20_20D', 'Compare_close_and_Fast_SMA_15_40', 'Compare_close_and_Slow_SMA_40_15', 'Indicator_for_Cross_of_Fast_SMA_15_Slow_SMA_40', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_40_5D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_40_5D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_40_10D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_40_10D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_40_15D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_40_15D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_40_20D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_40_20D', 'Compare_close_and_Fast_SMA_15_80', 'Compare_close_and_Slow_SMA_80_15', 'Indicator_for_Cross_of_Fast_SMA_15_Slow_SMA_80', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_80_5D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_80_5D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_80_10D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_80_10D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_80_15D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_80_15D', 'Indicator_for_golden_cross_of_Fast_SMA_15_Slow_SMA_80_20D', 'Indicator_for_death_cross_of_Fast_SMA_15_Slow_SMA_80_20D', 'Compare_close_and_Fast_SMA_20_40', 'Compare_close_and_Slow_SMA_40_20', 'Indicator_for_Cross_of_Fast_SMA_20_Slow_SMA_40', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_40_5D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_40_5D', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_40_10D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_40_10D', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_40_15D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_40_15D', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_40_20D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_40_20D', 'Compare_close_and_Fast_SMA_20_80', 'Compare_close_and_Slow_SMA_80_20', 'Indicator_for_Cross_of_Fast_SMA_20_Slow_SMA_80', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_80_5D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_80_5D', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_80_10D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_80_10D', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_80_15D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_80_15D', 'Indicator_for_golden_cross_of_Fast_SMA_20_Slow_SMA_80_20D', 'Indicator_for_death_cross_of_Fast_SMA_20_Slow_SMA_80_20D', 'Compare_close_and_Fast_EMA_5_10', 'Compare_close_and_Slow_EMA_10_5', 'Indicator_for_Cross_of_Fast_EMA_5_Slow_EMA_10', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_10_5D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_10_5D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_10_10D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_10_10D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_10_15D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_10_15D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_10_20D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_10_20D', 'Compare_close_and_Fast_EMA_5_20', 'Compare_close_and_Slow_EMA_20_5', 'Indicator_for_Cross_of_Fast_EMA_5_Slow_EMA_20', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_20_5D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_20_5D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_20_10D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_20_10D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_20_15D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_20_15D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_20_20D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_20_20D', 'Compare_close_and_Fast_EMA_5_40', 'Compare_close_and_Slow_EMA_40_5', 'Indicator_for_Cross_of_Fast_EMA_5_Slow_EMA_40', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_40_5D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_40_5D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_40_10D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_40_10D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_40_15D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_40_15D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_40_20D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_40_20D', 'Compare_close_and_Fast_EMA_5_80', 'Compare_close_and_Slow_EMA_80_5', 'Indicator_for_Cross_of_Fast_EMA_5_Slow_EMA_80', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_80_5D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_80_5D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_80_10D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_80_10D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_80_15D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_80_15D', 'Indicator_for_golden_cross_of_Fast_EMA_5_Slow_EMA_80_20D', 'Indicator_for_death_cross_of_Fast_EMA_5_Slow_EMA_80_20D', 'Compare_close_and_Fast_EMA_10_20', 'Compare_close_and_Slow_EMA_20_10', 'Indicator_for_Cross_of_Fast_EMA_10_Slow_EMA_20', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_20_5D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_20_5D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_20_10D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_20_10D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_20_15D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_20_15D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_20_20D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_20_20D', 'Compare_close_and_Fast_EMA_10_40', 'Compare_close_and_Slow_EMA_40_10', 'Indicator_for_Cross_of_Fast_EMA_10_Slow_EMA_40', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_40_5D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_40_5D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_40_10D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_40_10D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_40_15D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_40_15D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_40_20D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_40_20D', 'Compare_close_and_Fast_EMA_10_80', 'Compare_close_and_Slow_EMA_80_10', 'Indicator_for_Cross_of_Fast_EMA_10_Slow_EMA_80', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_80_5D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_80_5D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_80_10D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_80_10D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_80_15D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_80_15D', 'Indicator_for_golden_cross_of_Fast_EMA_10_Slow_EMA_80_20D', 'Indicator_for_death_cross_of_Fast_EMA_10_Slow_EMA_80_20D', 'Compare_close_and_Fast_EMA_15_20', 'Compare_close_and_Slow_EMA_20_15', 'Indicator_for_Cross_of_Fast_EMA_15_Slow_EMA_20', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_20_5D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_20_5D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_20_10D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_20_10D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_20_15D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_20_15D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_20_20D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_20_20D', 'Compare_close_and_Fast_EMA_15_40', 'Compare_close_and_Slow_EMA_40_15', 'Indicator_for_Cross_of_Fast_EMA_15_Slow_EMA_40', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_40_5D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_40_5D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_40_10D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_40_10D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_40_15D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_40_15D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_40_20D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_40_20D', 'Compare_close_and_Fast_EMA_15_80', 'Compare_close_and_Slow_EMA_80_15', 'Indicator_for_Cross_of_Fast_EMA_15_Slow_EMA_80', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_80_5D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_80_5D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_80_10D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_80_10D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_80_15D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_80_15D', 'Indicator_for_golden_cross_of_Fast_EMA_15_Slow_EMA_80_20D', 'Indicator_for_death_cross_of_Fast_EMA_15_Slow_EMA_80_20D', 'Compare_close_and_Fast_EMA_20_40', 'Compare_close_and_Slow_EMA_40_20', 'Indicator_for_Cross_of_Fast_EMA_20_Slow_EMA_40', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_40_5D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_40_5D', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_40_10D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_40_10D', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_40_15D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_40_15D', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_40_20D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_40_20D', 'Compare_close_and_Fast_EMA_20_80', 'Compare_close_and_Slow_EMA_80_20', 'Indicator_for_Cross_of_Fast_EMA_20_Slow_EMA_80', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_80_5D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_80_5D', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_80_10D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_80_10D', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_80_15D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_80_15D', 'Indicator_for_golden_cross_of_Fast_EMA_20_Slow_EMA_80_20D', 'Indicator_for_death_cross_of_Fast_EMA_20_Slow_EMA_80_20D', 'Aroon_Up_gt70_Down_lt30', 'Aroon_Up_lt70_Down_gt30', 'Aroon_up_gt_50', 'Aroon_down_lt_50', 'Indicator_Aroon', 'Aroon_cross_Up_gt', 'Aroon_cross_Up_lt', 'Indi_Aroon_cross', 'Indicator2_Aroon']
    
    import pandas as pd
    drop_columns=['close','open','high','low','volume','No_Days_since_last_cross_MACD_36f_104s','No_Days_since_last cross_MACD_36f_104s']

    # Iterate over the columns to drop and check if they exist in the DataFrame
    for column in drop_columns:
        if column in df.columns:
            df.drop(column, axis=1, inplace=True)
            
    #Check for Null values
    null_columns = df.columns[df.isnull().any()]
    # Print the column names with null values
    print("Columns with null values:")
    for column in null_columns:
        print(column)

    def set_column_datatypes(dataframe, column_datatypes):   
        for column in dataframe.columns:
            if column in column_datatypes:
                datatype = column_datatypes[column]
                dataframe[column] = dataframe[column].astype(datatype)
            else:
                print(f"Column '{column}' not found in the dictionary.")
        return dataframe

    column_datatypes ={'date': 'datetime64[ns]', 'nse_symbol': 'string', 'close': 'float64', 'open': 'float64', 'high': 'float64', 'low': 'float64', 'volume': 'Int64', 'Indicator_ADL_15_Slope': 'int64', 'Indicator_Slope15_ADL': 'float64', 'No_ADL_gt0_5D': 'float64', 'No_ADL_lt0_5D': 'float64', 'ADX_gt_20_5D': 'float64', 'ADX_gt_25_5D': 'float64', 'ADX_Indicator': 'int32', 'No_of_times_DI_cross_5D': 'float64', 'plusDI_cross_from_above': 'int32', 'plusDI_cross_from_above_5D': 'float64', 'plusDI_cross_from_below_5D': 'float64', 'SMA_ADX_5D': 'float64', 'UorD_25': 'int64', '20D_Slope_Aroon_down': 'float64', '5D_Slope_Aroon_up': 'float64', 'Aroon_No_cross_Up_gt0_in_10D': 'float64', 'Aroon_No_cross_Up_lt_in_20D': 'float64', 'Aroon_Up_lt70_Down_gt30': 'int32', 'pct_DaysAroon_U_gt_50_20D': 'float64', 'ATR': 'float64', 'ATR_SMA5D': 'float64', 'Indi_ATR_gtAV_ATR_5D': 'int32', 'Indicator_ATR': 'int64', 'No_Indicator_ATR_EQ-1_inLast_5D': 'float64', 'No_Indicator_ATR_EQ1_inLast_5D': 'float64', 'compare_close_and_LowerBB': 'int32', 'compare_close_and_UpperBB': 'int32', 'diff_UpperBB_and_LowerBB': 'float64', 'SMA_LowerBB_5': 'float64', 'SMA_UpperBB_5': 'float64', 'Std_Dev_LowerBB_5D': 'float64', 'Std_Dev_UpperBB_5D': 'float64', 'Doji': 'int32', 'cci_Thresholds_Indicator': 'int64', 'diff_Upper_Donchian_Lower_Donchian10': 'float64', 'diff_Upper_Donchian_Lower_Donchian20': 'float64', 'diff_Upper_Donchian_Lower_Donchian30': 'float64', 'diff_Upper_Donchian_Lower_Donchian40': 'float64', 'Lower_Donchian_10_Std_Dev_10D': 'float64', 'Lower_Donchian_20_Std_Dev_15D': 'float64', 'Lower_Donchian_30_Std_Dev_5D': 'float64', 'Lower_Donchian_40_Std_Dev_20D': 'float64', 'Upper_Donchian_10_Std_Dev_10D': 'float64', 'Upper_Donchian_20_Std_Dev_5D': 'float64', 'Count_of_death_cross_of_Fast_EMA_10_Slow_EMA_20_15D': 'float64', 'Count_of_death_cross_of_Fast_EMA_10_Slow_EMA_40_15D': 'float64', 'Count_of_death_cross_of_Fast_EMA_15_Slow_EMA_20_15D': 'float64', 'Count_of_death_cross_of_Fast_EMA_15_Slow_EMA_40_20D': 'float64', 'Count_of_death_cross_of_Fast_EMA_5_Slow_EMA_20_20D': 'float64', 'Count_of_death_cross_of_Fast_EMA_5_Slow_EMA_40_20D': 'float64', 'Count_of_golden_cross_of_Fast_EMA_20_Slow_EMA_80_20D': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_10_Slow_EMA_20': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_10_Slow_EMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_10_Slow_EMA_80': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_15_Slow_EMA_20': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_15_Slow_EMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_15_Slow_EMA_80': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_20_Slow_EMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_20_Slow_EMA_80': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_5_Slow_EMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_EMA_5_Slow_EMA_80': 'float64', 'Indi_EOM_lt_crossover': 'int32', 'Indicator_EOM_10Slope': 'int64', 'No_EOM_gt_2_5D': 'float64', 'No_Days_since_last_cross_Force': 'float64', 'compare_Conversion_Baseline_Ichimoku': 'int32', 'Count_of_golden_crosses_of_Conversion_and_Baseline_20D': 'float64', 'Indicator_Cross_KAMA_Fast_14Slow56': 'int32', 'Dist_Keltner_u&l': 'float64', 'Distance_close_low_Keltner': 'float64', 'Indi_keltnerL_gt_crossover': 'int32', 'Indi_keltnerL_lt_crossover': 'int32', 'keltner_channel_wband': 'float64', 'keltner_hband': 'float64', 'keltner_lband': 'float64', 'keltner_mband': 'float64', 'KeltnerL_MA_5D': 'float64', 'KeltnerU_MA_5D': 'float64', 'No_keltnerL_lt_crossover_inLast_5D': 'float64', 'vol_Lkeltner_5D': 'float64', 'vol_Ukeltner_5D': 'float64', 'Indi_MACD_12f_104s_gt_signal': 'int32', 'Indicator_MACD_36f_104s_gt_Signal': 'int32', 'Indicator_MACD_48f_104s_gt_Signal': 'int32', 'Indicator_MACD_48f_78s_gt_Signal': 'int32', 'MACD_12f_104s_GT_0_15D': 'int32', 'MACD_12f_104s_LT_0_15D': 'int32', 'MACD_24f_104s_GT_0_5D': 'int32', 'MACD_24f_104s_LT_0_5D': 'int32', 'MACD_24f_78s_GT_0_20D': 'int32', 'MACD_24f_78s_LT_0_20D': 'int32', 'MACD_36f_104s_GT_0_5D': 'int32', 'MACD_36f_104s_LT_0_5D': 'int32', 'MACD_36f_78s_GT_0_5D': 'int32', 'MACD_36f_78s_LT_0_5D': 'int32', 'MACD_48f_104s_GT_0_5D': 'int32', 'MACD_48f_104s_LT_0_5D': 'int32', 'MACD_48f_52s_GT_0_15D': 'int32', 'MACD_48f_52s_LT_0_15D': 'int32', 'MACD_48f_78s_GT_0_5D': 'int32', 'MACD_48f_78s_LT_0_5D': 'int32', 'No_Days_since_last cross_MACD_36f_104s': 'float64', 'No_MACD_24f_104s_lt_signal_20D': 'float64', 'No_MACD_24f_52s_lt_signal_20D': 'float64', 'No_MACD_24f_78s_lt_signal_20D': 'float64', 'No_MACD_36f_104s_lt_signal_20D': 'float64', 'No_MACD_36f_78s_lt_signal_20D': 'float64', 'No_MACD_48f_104s_lt_signal_20D': 'float64', 'No_MACD_48f_52s_lt_signal_20D': 'float64', 'No_MACD_48f_78s_lt_signal_20D': 'float64', 'vol_MACD_12f_104s_in_5D': 'float64', 'vol_MACD_12f_26s_in_5D': 'float64', 'vol_MACD_12f_52s_in_5D': 'float64', 'vol_MACD_12f_78s_in_5D': 'float64', 'vol_MACD_24f_104s_in_5D': 'float64', 'vol_MACD_24f_26s_in_5D': 'float64', 'vol_MACD_24f_52s_in_5D': 'float64', 'vol_MACD_24f_78s_in_5D': 'float64', 'vol_MACD_36f_104s_in_5D': 'float64', 'vol_MACD_36f_52s_in_5D': 'float64', 'vol_MACD_36f_78s_in_5D': 'float64', 'vol_MACD_48f_104s_in_5D': 'float64', 'vol_MACD_48f_52s_in_5D': 'float64', 'vol_MACD_48f_78s_in_5D': 'float64', 'Count_MFI_gt_80_in_last_15D': 'float64', 'Slope_MFI_5': 'float64', 'SMA_MFI_20': 'float64', 'Count_NVI_gt_SMA_of_NVI_104_in_last_15D': 'float64', 'Count_NVI_gt_SMA_of_NVI_78_in_last_10D': 'float64', 'Count_NVI_lt_SMA_of_NVI_104_in_last_15D': 'float64', 'Count_NVI_lt_SMA_of_NVI_78_in_last_10D': 'float64', 'Slope_of_SMA_of_nvi_78in_last10D': 'float64', 'Count_of_golden_crosses_OBV_and_SMA_of_OBV_100_in_20D': 'float64', 'Count_of_golden_crosses_OBV_and_SMA_of_OBV_70_in_20D': 'float64', 'Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_100': 'float64', 'Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_40': 'float64', 'Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_70': 'float64', 'OBV_Std_Dev_5D': 'float64', 'Indicator_SAR': 'int64', 'Indicator_SAR1': 'int32', 'No_Parabolic_SAR_cross_inLast_20D': 'float64', 'Parabolic_SAR': 'float64', 'Parabolic_SAR_No_cross_gt_inLast_10D': 'float64', 'Parabolic_SAR_No_cross_lt_inLast_20D': 'float64', 'Parabolic_SAR_SMA_5D': 'float64', 'Fast_SMA_of_PVI': 'float64', 'pvi': 'object', 'PVI_Max_in_last_5D': 'float64', 'PVI_Min_in_last_5D': 'float64', 'Slope_of_Fast_SMA_of_PVI20D': 'float64', 'Slope_of_Slow_SMA_of_PVI20D': 'float64', 'Slow_SMA_of_PVI': 'float64', '10D_Slope_PVO_12f_26s': 'float64', 'Indicator_PVO_12f_104s': 'int32', 'Indicator_PVO_12f_26s': 'int32', 'Indicator_PVO_12f_52s': 'int32', 'Indicator_PVO_12f_78s': 'int32', 'Indicator_PVO_24f_104s': 'int32', 'Indicator_PVO_24f_26s': 'int32', 'Indicator_PVO_24f_52s': 'int32', 'Indicator_PVO_24f_78s': 'int32', 'Indicator_PVO_36f_104s': 'int32', 'Indicator_PVO_36f_52s': 'int32', 'Indicator_PVO_36f_78s': 'int32', 'Indicator_PVO_48f_104s': 'int32', 'Indicator_PVO_48f_52s': 'int32', 'Indicator_PVO_48f_78s': 'int32', 'No_PVO_36f_104s_gt0_5D': 'float64', 'No_PVO_36f_104s_Lt0_5D': 'float64', 'No_PVO_48f_104s_gt0_5D': 'float64', 'No_PVO_48f_104s_Lt0_5D': 'float64', 'No_PVO_48f_78s_gt0_5D': 'float64', 'No_PVO_48f_78s_Lt0_5D': 'float64', 'No_times_PVO_24f_52s_gt_crossover_inLast_15D': 'float64', 'No_times_PVO_24f_78s_gt_crossover_inLast_20D': 'float64', 'No_times_PVO_36f_52s_lt_crossover_inLast_10D': 'float64', 'No_times_PVO_48f_104s_lt_crossover_inLast_10D': 'float64', 'No_times_PVO_48f_52s_lt_crossover_inLast_10D': 'float64', 'No_times_PVO_48f_78s_lt_crossover_inLast_10D': 'float64', 'PVO_12f_104s_hist': 'float64', 'PVO_12f_26s_hist': 'float64', 'PVO_12f_52s_hist': 'float64', 'PVO_12f_78s_hist': 'float64', 'PVO_24f_104s_hist': 'float64', 'PVO_24f_26s_hist': 'float64', 'PVO_24f_52s_hist': 'float64', 'PVO_24f_78s_hist': 'float64', 'PVO_36f_104s_hist': 'float64', 'PVO_36f_52s_hist': 'float64', 'PVO_36f_78s_hist': 'float64', 'PVO_48f_104s_hist': 'float64', 'PVO_48f_52s_hist': 'float64', 'PVO_48f_78s_hist': 'float64', 'ROC_Thresholds': 'int64', 'Slope_ROC15': 'float64', 'No_RSI_lt30_inLast_5D': 'float64', 'Count_of_death_cross_of_Fast_SMA_10_Slow_SMA_20_20D': 'float64', 'Count_of_death_cross_of_Fast_SMA_10_Slow_SMA_40_15D': 'float64', 'Count_of_death_cross_of_Fast_SMA_15_Slow_SMA_20_15D': 'float64', 'Count_of_death_cross_of_Fast_SMA_15_Slow_SMA_40_15D': 'float64', 'Count_of_death_cross_of_Fast_SMA_20_Slow_SMA_40_10D': 'float64', 'Count_of_death_cross_of_Fast_SMA_5_Slow_SMA_20_20D': 'float64', 'Count_of_death_cross_of_Fast_SMA_5_Slow_SMA_40_20D': 'float64', 'Count_of_golden_cross_of_Fast_SMA_15_Slow_SMA_20_15D': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_10_Slow_SMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_10_Slow_SMA_80': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_15_Slow_SMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_15_Slow_SMA_80': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_20_Slow_SMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_20_Slow_SMA_80': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_5_Slow_SMA_40': 'float64', 'Num_days_since_last_cross_of_Fast_SMA_5_Slow_SMA_80': 'float64', '15D_Slope_Stochd': 'float64', 'Indicator_STOCH_15D': 'float64', 'No_golden_cross_stochastic_in_20D': 'float64', 'No_times_stochk_lt20_20D': 'float64', 'Count_Slope_of_UI_gt_0_in_last_10D': 'float64', 'Count_Slope_of_UI_lt_0_in_last_10D': 'float64', 'Count_UI_gt_UI_SMA_14_in_last_10D': 'float64', 'Count_UI_gt_UI_SMA_42_in_last_20D': 'float64', 'Count_UI_gt_UI_SMA_56_in_last_15D': 'float64', 'Count_UI_lt_UI_SMA_14_in_last_10D': 'float64', 'Count_UI_lt_UI_SMA_42_in_last_20D': 'float64', 'Count_UI_lt_UI_SMA_56_in_last_15D': 'float64', 'Slope_UI15': 'float64', 'SMA_of_UI_14': 'float64', 'SMA_of_UI_28': 'float64', 'SMA_of_UI_42': 'float64', 'SMA_of_UI_56': 'float64', 'UI_Max_5D': 'float64', 'UI_Min_5D': 'float64', 'ulcer_index': 'float64', 'ADX_gt25_vpt_gt_Signal': 'int32', 'ADX_lt25_vpt_lt_Signal': 'int32', 'Indi_VPT_gt_crossover': 'int32', 'VWAP': 'float64', 'No_of_times_WILLR_gt_crossover_in_15D': 'float64', 'EMA_close_for_CMF_5': 'float64', 'Returns_5D':'float64','Target_1':'int32'}
    
    df = set_column_datatypes(df, column_datatypes)
#     print(df.dtypes)
    print('datatype changed')
    
    # Assuming your DataFrame is named 'df'
    if df.isnull().values.any():
        print("Null values are present in the DataFrame.")
        print("Null values:")
        print(df[df.isnull().any(axis=1)])
    else:
        print("No null values found in the DataFrame.")
        
    categorical = list(set(categorical).intersection(df.columns.to_list()))
    df = pd.get_dummies(df,columns = categorical)
    #Sort index to get date in proper order.
    df = df.sort_index()
    
    # Determine the test date if not specified
    if test_date is None:
        df_day = df[df.index.get_level_values('date').day_name() == day_of_week ]
        if len(df_day) == 0:
            print("No Data with this weekday data is available.")
            return None
        test_date = df_day.index.get_level_values('date').max()
    else:
        test_date = pd.to_datetime(test_date)
        
    def find_train_test_pred_dates_from_df(df,test_date):        
        """""
        The function creates tuples as (train_start_date, train_end_date, prediction_date)
        """
        # (Create list A) with unique dates from the dataframe
        unique_dates_df = df.index.get_level_values('date').unique().tolist()

        # (Create list B) with dates on and after the test_date that match the specified day_of_week
        dates_after_test_date_w_weekday = []
        day_of_week_dict = {'Monday': 0, 'Tuesday': 1, 'Wednesday': 2, 'Thursday': 3, 'Friday': 4, 'Saturday': 5, 'Sunday': 6}
        test_day_of_week = day_of_week_dict[day_of_week]

        for date in unique_dates_df:
            if date >= pd.to_datetime(test_date) and date.day_of_week == test_day_of_week:
                dates_after_test_date_w_weekday.append(date)

        # (Create List c) Find list B element in list A, leave 5 previous elements, append the 6th element in a list
        test_end_after_test_date=[]
        for date in dates_after_test_date_w_weekday:
            if date in unique_dates_df:
                idx = unique_dates_df.index(date)
                if idx > 5:
                    test_end_after_test_date.append(unique_dates_df[idx-6:idx+1][0])

        # (Create list D & E)
        train_start = []  # List to store previous 90th elements
        dates_wo_no_of_days = []  # List to store dates that do not have 90th element

        # Loop through list_c to find matches
        for date_c in test_end_after_test_date:
            if date_c in unique_dates_df:
                index_c = unique_dates_df.index(date_c)  # Find index of date_c in list_a
                if index_c >= int(no_of_days):
                    prev_90th = unique_dates_df[index_c - int(no_of_days)]  # Get previous 90th element
                    train_start.append(prev_90th)  # Append to train_start
                else:
                    print(f'There are no {no_of_days} days before date {date_c} in the data.')
                    dates_wo_no_of_days.append(date_c)  # Append to list_no_90th if no previous 90 elements

        # (Create list F) Determine the actual train end dates by leaves those dates that do no have 90 dates prior to it
        train_end = [x for x in test_end_after_test_date if x not in dates_wo_no_of_days]

        # Create Pred Lists
        pred_date_list=[]
        for i, elem_b in enumerate(dates_after_test_date_w_weekday):
            for j, elem_a in enumerate(unique_dates_df):
                if elem_b == elem_a:
                    if j >= int(no_of_days)+5 :
                        pred_date_list.append(elem_b)           

        #Data Formation  Complete . Next Code for Modelling.

        # Define your lists of train_start_date and train_end_date
        train_start_date =train_start.copy()  # List of train start dates
        train_end_date = train_end.copy()  # List of train end dates
        test_date =pred_date_list.copy

        # Create a list to store the results of each model
        results = []
        count_dict=[]
        zipped= list(zip(train_start, train_end, pred_date_list))
        
        return zipped
    
    zipped=find_train_test_pred_dates_from_df(df,test_date)

    def train_model(zipped,**kwargs):
        
        """"
        The Function uses zipped to train model based on Method Parameter.
        Parameter:
        Method(string): Model to be used for prediction must be specified. (Default: None . That is, LSTM). can take Value as 'XGB'.       
        """

        Method= kwargs.get('Method', None)
        
        if Method == 'XGB':
            """""
            Uses zipped tuple output of 'find_train_test_pred_dates_from_df' to sequentially train  'XGBoost Model' for every prediction date.
            The function iterates over each element in zipped to form Train & Test dataframes. the function then uses RandomSearchCV to find best parameters.
            The best parameters found are used to build model. The model is then used to predict for pred_date of that tuple. 

            Output:
            The function iterates over loop and gives 2 dataframes-
            1. stacked_df: With columns as [date,nse_symbol(top_n),y_test_actual(actual classification of y in test), y_pred(classification of stock by model), Probability]
            2. summary_df: Summary of model performance in terms of actual 1s. Columns[date, count (sum of y_test_actual 's for each date)]
            """
            results = []
            count_dict=[]
            # Loop between the two lists and train a model for each iteration
            for i in zipped:
                start_date=i[0]
                end_date=i[1]
                pred_date=i[2]
                print("Training Start Date is:",start_date)
                print("Training End Date is:", end_date)
                print("Test Date is:",pred_date )
                print("\n")

                Train = df.loc[start_date:end_date]
                X_train = Train.drop(['Target_1','Returns_5D'], axis=1)
                y_train = Train['Target_1']

                Test = df.loc[pred_date:pred_date]
                X_pred = Test.drop(['Target_1','Returns_5D'], axis=1)
                y_pred_actual = Test['Target_1']

                # Define the parameter space to explore
                param_dist = {
                    'max_depth': [5, 6, 7, 8],
                    'min_child_weight': [1, 2, 3, 4],
                    'gamma': [0.2, 0.3, 0.4, 0.5],
                    'n_estimators': [400, 500, 600, 700],
                    'subsample': [0.8, 0.9, 1.0],
                    'scale_pos_weight': [3, 4, 5],
                    'eta': [0.01,0.05,0.1]
                }


                # Define the XGBoost model
                XGBoost_Model = xgb.XGBClassifier()

                # Define the scoring metric to use
                scoring = make_scorer(precision_score, pos_label=1)

                # Create a RandomizedSearchCV object
                random_search = RandomizedSearchCV(
                    XGBoost_Model, 
                    param_distributions=param_dist, 
                    n_iter=4, 
                    scoring=scoring, 
                    cv=3, 
                    n_jobs=-1
                )

                # Fit the RandomizedSearchCV object to the training data
                random_search.fit(X_train, y_train)
    
                # Get the best XGBoost model from the RandomizedSearchCV object
                XGBoost_Model_best = random_search.best_estimator_

                # print best parameters
                print('Best parameters are:',XGBoost_Model_best)
                # Fit the best model to the training data
                XGBoost_Model_best.fit(X_train, y_train)

                #Predict
                y_pred = XGBoost_Model_best.predict(X_pred)
                y_test_pred_probs = XGBoost_Model_best.predict_proba(X_pred)

                # Create a dataframe with y test and predicted probabilities
                df_prob = pd.DataFrame({'y_pred': y_pred, 'y_test_pred_prob': y_test_pred_probs[:,1]})
                df_prob = df_prob.reset_index(level='date') #Make Date as column from Index

                # Sort dataframe by date and predicted probability
                df_prob = df_prob.sort_values(by=['date', 'y_test_pred_prob'], ascending=[True, False])
                df_prob = df_prob.reset_index(level='nse_symbol') #Make Stockname as column from Index

                # Select top N values for each unique date
                df_topn = df_prob.groupby('date').apply(lambda x: x.head(top_n)).reset_index(drop=True)
                top_n_stocks = df_topn['nse_symbol'].tolist()
                date=df_topn['date'].tolist()
                #y_test_actual= df_topn['y_test_actual'].tolist()
                y_pred = df_topn['y_pred'].tolist()
                Probabilities =  df_topn['y_test_pred_prob'].tolist()

                # Append the results to the list
                results.append((date, top_n_stocks, y_pred, Probabilities))
                
            # Create a dataframe with rows for each date and each stock and its corresponding probability
            stocks_df = pd.concat([pd.DataFrame({'date': row[0], 'nse_symbol': row[1], 'y_pred':row[2], 'Probability': row[3]}) for row in results], ignore_index=True)
            Output_1 = stocks_df
            
             #Output_2 = performance_summary_df    
        else:
            
            """""
            Uses zipped tuple output of 'find_train_test_pred_dates_from_df' to sequentially train 'LSTM Model' for every prediction date.
            The function iterates over each element in zipped to form Train & Test dataframes. 
            It then specifes the architecture of LSTM Model.
            Then for each stock in train, model forms Sequential data of train and then sequentially forms data for test.
            Then fit model to sequential Train data and used fitted model for prediction.
            Append the prediction in dataframe for each stock in loop.

            Parameters:
            n_timesteps(int): sequence lenth for sequential data. (Default: 5)
            epochs(int): Epoch for training model. (Default: 25)
            batch_size (int) : Batch Size for training. (Default: 32)
            optimizer (string): Optimizer for optimizing weights( Deafult: adam)

            Output:
            The function iterates over loop and gives 2 dataframes-
            1. df_topn: With columns as [date,nse_symbol(top_n),y_test_actual(actual classification of y in test), y_pred(classification of stock by model), Probability]
            2. summary_df: Summary of model performance in terms of actual 1s. Columns[date, count (sum of y_test_actual 's for each date)]

            """
            n_timesteps = kwargs.get('n_timesteps', 5)
            epochs= kwargs.get('epochs', 10)
            batch_size=  kwargs.get('batch_size', 32)
            optimizer =  kwargs.get('optimizer', 'adam')
            
            df_prob = pd.DataFrame(columns=['date','nse_symbol', 'y_pred', 'Probability'])
            for i in zipped:

                start_date=i[0]
                end_date=i[1]
                pred_date=i[2]
#                 print("Training Start Date is:",start_date)
#                 print("Training End Date is:", end_date)
#                 print("Test Date is:",pred_date )
#                 print("\n")

                Train = df.loc[start_date:end_date]
                train_data=Train.reset_index()
                train_data=train_data.reset_index()

                Test = df.loc[pred_date:pred_date]        
                
                # Model Define
                def create_lstm_model(input_shape):
                    model = Sequential()
                    model.add(LSTM(units=256, input_shape= input_shape, return_sequences=True))
                    model.add(LSTM(units=120, input_shape= input_shape, return_sequences=True))
                    model.add(LSTM(units=64))
                    model.add(Dense(units=64, activation=LeakyReLU()))
                    model.add(Dense(units=1, activation='sigmoid'))
                    optimizer=Nadam()
                    model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=[keras.metrics.Precision()])

                    return model

                # Initialize an empty DataFrame to store the predictions
                predictions_group_df = pd.DataFrame(columns=['date','nse_symbol', 'y_pred', 'Probability'])

                # Group the data by 'group' column
                groups = Train.groupby('nse_symbol')

                # Iterate over each group
                for group_name, group_data in groups:
                    if len(group_data) >= int(n_timesteps):
                        #print('\n', group_data.tail(10))
                        print('\n', group_name)

                        # Convert DataFrame to a NumPy array
                        group_data=group_data.drop(['Returns_5D'],axis=1)
                        group_data_array = np.array(group_data)

                        # Define the target variable column index
                        target_column_index = -1  # Assuming the target variable is the last column

                        # Reshape the array into sequential data
                        sequence_length = n_timesteps
                        num_sequences = group_data_array.shape[0] - sequence_length + 1
                        num_features = group_data_array.shape[1] - 1  # Exclude the target variable column
                        reshaped_array = np.zeros((num_sequences, sequence_length, num_features + 1))  # +1 for the target variable
                        for i in range(num_sequences):
                            reshaped_array[i, :, :num_features] = group_data_array[i:i+sequence_length, :num_features]  # Input features
                            reshaped_array[i, -1, num_features] = group_data_array[i+sequence_length-1, target_column_index]  # Target variable     

                        # Separate the input features and target variable
                        X_train = reshaped_array[:, :, :num_features]
                        y_train = reshaped_array[:, -1, num_features]
                        #print(X_train)
                        #print(y_train)

                        # Create the LSTM model
                        model = create_lstm_model(input_shape=(sequence_length, num_features))

                        # Train the model on the current group's data
                        model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)
            #             print('Training Done')

                        #### Form Test set
                        row_selection = (pred_date, group_name)
                        Test_1 = Test.loc[[row_selection]]
            #           print(Test)

                        # Convert DataFrame to a NumPy arrayTest = df.loc[pred_date:pred_date]
                        Test_1=Test_1.drop(['Returns_5D'],axis=1)
                        Test_array = np.array(Test_1)
            #           print(Test_array)

                        # Define the target variable column index
                        target_column_index = -1  # Assuming the target variable is the last column

                        # Reshape the array into sequential data
                        sequence_length = n_timesteps  # Number of time steps
                        num_features = Test_array.shape[1] - 1  # Exclude the target variable column

                        reshaped_array = np.zeros((1, sequence_length, num_features + 1))  # +1 for the target variable
                        reshaped_array[0, :len(Test_array), :num_features] = Test_array[:, :num_features]  # Input features
                        reshaped_array[0, -1, num_features] = Test_array[-1, target_column_index]  # Target variable

                        # Separate the input features and target variable
                        X_test = reshaped_array[:, :, :num_features]
                        y_test = reshaped_array[:, -1, num_features]
            #           print('Test reshape done')

                        #### mPredict
                        predictions = model.predict(X_test)
                        test_predictions = predictions.flatten()
                        Prediction= np.where(test_predictions >= 0.5, 1, 0)

                        # Create a DataFrame to store the predictions for this group
                        group_predictions_df = pd.DataFrame({'date':row_selection[0], 'nse_symbol':row_selection[1] ,'y_pred': Prediction, 'Probability': predictions.flatten()})
                        #print(group_predictions_df)

                        # Append the group predictions to the main predictions DataFrame
                        predictions_group_df = pd.concat([predictions_group_df, group_predictions_df], ignore_index=True)
                        #print(f'predictions_df for all stocks of date {row_selection[0]} appended ')
                    else:
                        print(f"Group '{group_name}' is dropped due to insufficient data")
                        continue

                df_prob= pd.concat([df_prob, predictions_group_df], ignore_index=True)


            # Sort dataframe by date and predicted probability
            df_prob['date'] = pd.to_datetime(df_prob['date'])
            df_topn = df_prob.sort_values(by=['date', 'Probability'], ascending=[True, False])
            
            df_topn = df_topn.groupby('date').apply(lambda x: x.head(top_n)).reset_index(drop=True)
            
            Output_1 = df_topn
            #Output_2 = summary_df

        return Output_1#, Output_2
    
    Output_a = train_model(zipped)
    
    formatted_date = test_date.strftime("%Y-%m-%d")
    
    # Generate the file name using the formatted date
    #file_name = f"s3://sg-ds-project/stock-prediction-poc/weekly-prediction/Recommended_stocks_for_week_next_of_{formatted_date}.xlsx"

    # Save the DataFrame to Excel using the modified file name
    #Output_a.to_excel(file_name, index=False)
    
    return Output_a

def Back_Test(data,**kwargs):
    import pandas as pd
    import numpy as np
    
    """""
    The Function Take input data. Then uses 'create_Target' function to create Target.
    Change datatype of date column (assumed the data to be in 'yyyy-mm-dd').
    Then makes date and nse_symbol (stock name) columns as Index and sort dataframe as per Index.
    Then call functions 'get_top_n_stocks' & 'get_top_n_stocks'.
    
    The output is 4 Dataframes-
    0. Entire Investment strategy with columns [date, nse_symbol, actyal_y, predicted_y, probability, returns, amount_recieved(per on each date based on returns)] 
    1. Investement Summary ( per date amount recieved)
    2. Top stocks date-wise with predictions & probability
    3. Summary of model performance (actual 1s per date)
    
    """
    #Load Data & Save Copy
    df=create_Target(data)
    print(df)
    
    #Prep Data
    df['date'] = pd.to_datetime(df['date'])
    df.drop(['open','high','low','close','volume'],axis=1,inplace=True)
    df = df.set_index(['date', 'nse_symbol'])
    df_sorted = df.sort_index()
    
    #Get list of Stocls
    stock_df= get_top_n_stocks(df=df_sorted,**kwargs)

    return stock_df

