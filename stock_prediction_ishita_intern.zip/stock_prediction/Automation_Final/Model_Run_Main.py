""""
The script takes data from 41 files (41 dates data of technical Indicators) from folder"s3://sg-ds-project/stock-prediction-poc/feature-data/" relative to today's date.

This data is concatenated and used as input in Back_Test function imported from Model_Run_Function.py script.

The output of the script is list of recommended stocks that is stored on s3 bucket with path-"s3://sg-ds-project/stock-prediction-poc/weekly-prediction/"
"""

import pandas as pd
import numpy as np
import time
from Model_Run_Function import Back_Test
from datetime import datetime, timedelta
import awswrangler as wr

from Get_OHLCV_Data import boto3_session

# Get the path where the Parquet files are present
parquet_files_path = "s3://sg-ds-project/stock-prediction-poc/feature-data/"

# Get today's date and calculate the date 30 days ago
today = datetime.now().date()
date_30_days_ago = today - timedelta(days=41)

# List files in the directory using wr.s3.list_objects()
parquet_files = wr.s3.list_objects(parquet_files_path, boto3_session=boto3_session)

# Filter and sort the Parquet files based on the date in their names
parquet_files = [
    file for file in parquet_files
    if file.endswith(".parquet") and file.startswith(parquet_files_path)
]

parquet_files.sort(key=lambda x: datetime.strptime(x.split("/")[-1].split(".")[0], "%Y-%m-%d"), reverse=True)

# Load and concatenate Parquet files into a single DataFrame using wr.s3.read_csv()
dataframes = []

for file in parquet_files:
    try:
        file_path = file.split("/")[-1].split(".")[0]+".parquet"
        df = wr.s3.read_parquet(parquet_files_path+file_path, boto3_session=boto3_session)
        dataframes.append(df)
    except:
        continue
        
    # Break the loop if we have collected 30 files
    if len(dataframes) == 41:
        break  
result_df = pd.concat(dataframes)

##Get Date for prediction
prediction_date=result_df['date'].max()
prediction_date=prediction_date.strftime("%Y-%m-%d")
print(prediction_date)

start_time = time.time()
output= Back_Test(data=result_df)
print(time.time() - start_time,"seconds")

output_path ="s3://sg-ds-project/stock-prediction-poc/weekly-prediction/"

wr.s3.to_csv(output, output_path + f"Recomended_for_week_after_{prediction_date}.csv", 
        index=False, boto3_session = boto3_session)

