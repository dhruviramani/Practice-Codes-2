""""
The script has Technical_Indicator_features function which creates the Techincal Indicator fetaures from OHLCV which is fetched by get_OHLCV_data.py script.

The script creates data for 5 days at a time (Note- there is parameter to specify the no of days to be created the default is taken as 5)

The output is saved as individual files per date on s3 bucket with path- "s3://sg-ds-project/stock-prediction-poc/feature-data/"

"""

import pandas as pd
import numpy as np 
from Get_OHLCV_Data import get_OHLCV_data
from Get_OHLCV_Data import boto3_session

def Technical_Indicator_features(groupby_col='co_code',**kwargs):

    import pandas as pd
    import numpy as np
    import talib
    import ta
    import pandas_ta as pta    
    import pyarrow as pa
    import pyarrow.parquet as pq
    import boto3
    import awswrangler as wr
    import warnings
    warnings.filterwarnings("ignore")
    
    OHLCV_data= get_OHLCV_data(**kwargs)
      
#     data = get_OHLCV_data(**kwargs)
    df_sorted = OHLCV_data.sort_values('date')
    grouped = df_sorted.groupby('co_code')

    # Apply the tail() function to each group, keeping the last 123 rows
    no_of_days_data_create = kwargs.get('no_of_days_data_create', 5)
    if no_of_days_data_create == 5: 
        no_of_rows_req= 115 + int(no_of_days_data_create)
        
    df = grouped.tail(no_of_rows_req)#116 for 1 day data, 202 for 36 days

    # Reset the index of the result DataFrame
    df = df.reset_index(drop=True)
    num_rows=len(df)
    if num_rows < no_of_rows_req:
        error_message="The Start Date and End Date do not have enough dates to make features"
        raise ValueError(error_message)

    df.sort_values(by=[groupby_col,'date'], ascending=[True,True], inplace= True,ignore_index=True)
    numeric_columns = ['high','low','close','open','net_turnov']
    df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric)

    #1   
    def ADL_Features(df, **kwargs):
        """"
        A function to create Features of AD Line Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_ADL: rolling window period. default:5

        Output:
        Dataframe with ADL featres added.

        """
        window_ADL = kwargs.get('window_ADL',[5])
        df['ADL'] =df.groupby(groupby_col).apply(lambda x: talib.AD(x['high'],x['low'],x['close'],x['volume'])).reset_index(drop=True)
      
        for w in window_ADL:

            df[str(w)+'D_Slope_Close']  = df.groupby(groupby_col).apply(lambda x: (x['close']-x['close'].shift(w))/w).reset_index(drop=True)
            df[str(w)+'D_Slope_ADL']  = df.groupby(groupby_col).apply(lambda x: (x['ADL']-x['ADL'].shift(w))/w).reset_index(drop=True)
            df['No_ADL_gt0_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['ADL'] > 0).astype(int)).rolling(w,min_periods=0).sum()).reset_index(0, drop=True)
            df['No_ADL_lt0_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['ADL'] < 0).astype(int)).rolling(w,min_periods=0).sum()).reset_index(0, drop=True)
            df['Indicator_ADL_'+str(w)+'_Slope'] = df.apply(lambda x: 1 if (x[str(w)+'D_Slope_Close'] > 0) & (x[str(w)+'D_Slope_ADL'] < 0) else -1 if (x[str(w)+'D_Slope_Close'] < 0) & (x[str(w)+'D_Slope_ADL'] > 0) else 0, axis=1)
            df['Indicator_Slope'+str(w)+'_ADL']  = df.groupby(groupby_col).apply(lambda x: ((x[str(w)+'D_Slope_ADL'] > x[str(w)+'D_Slope_ADL'].shift(1)).astype(int)).rolling(5,min_periods=0).sum()).reset_index(0, drop=True)
            df.drop(str(w)+'D_Slope_Close', axis=1,inplace=True)    
        return df

   #2
    def ADX_Features(df, **kwargs):
        """"
        A function to create Features of ADX Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        n_ADX  : Period of ADX. Deafult:14
        window: rolling window period. default:5
        groupby_col: Symbol column name to groupby 

        Output:
        Dataframe with ADX featres added.
        """
        n_ADX   =kwargs.get('n_ADX', 14)
        window_ADX =kwargs.get('window_ADX',[5])
        
        df['ADX'] =df.groupby(groupby_col).apply(lambda x: talib.ADX(x['high'],x['low'],x['close'],timeperiod=n_ADX)).reset_index(drop=True) 
        df = df.groupby([groupby_col]).apply(lambda x: x.assign(plusDI=talib.PLUS_DI(x['high'],x['low'],x['close'])))
        df = df.groupby([groupby_col]).apply(lambda x: x.assign(minusDI=talib.MINUS_DI(x['high'],x['low'],x['close'])))
        df['ADX_Indicator']=df.groupby(groupby_col)['ADX'].transform(lambda x: np.select([x<25, (x >=25) & (x<50), (x>=50) & (x <75), (x >=75) &(x <= 100)],[1,2,3,4],default=0))
        df['UorD_25']=df.groupby(groupby_col).apply(lambda x: x['ADX'].apply(lambda x: 1 if x > 25 else 0)).reset_index(level=0,drop=True)

        #Number of crosses 
        df['Indi_DI_cross'] = (((df['plusDI'].shift(1) < df['minusDI'].shift(1)) & (df['plusDI'] > df['minusDI'])) | ((df['plusDI'].shift(1) > df['minusDI'].shift(1)) & (df['plusDI'] < df['minusDI']))).astype(int)
        #NUmber of Golden crosses in the last 5 days:
        df['plusDI_cross_from_below'] = ((df['plusDI'].shift(1) < df['minusDI'].shift(1)) & (df['plusDI'] > df['minusDI'])).astype(int)
        #NUmber of Death crosses in the last 5 days:
        df['plusDI_cross_from_above'] = ((df['plusDI'].shift(1) > df['minusDI'].shift(1)) & (df['plusDI'] < df['minusDI'])).astype(int)

        for w in window_ADX:
            df['ADX_gt_25_'+str(w)+'D']=df.groupby(groupby_col).apply(lambda x: x['ADX'].rolling(window=w,min_periods=0).apply(lambda x: (x > 25).sum())).reset_index(level=0,drop=True)
            df['ADX_gt_20_'+str(w)+'D']=df.groupby(groupby_col).apply(lambda x: x['ADX'].rolling(window=w,min_periods=0).apply(lambda x: (x < 20).sum())).reset_index(level=0,drop=True)
            df['SMA_ADX_'+str(w)+'D'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.ADX, timeperiod=w)).reset_index(drop=True)
           
            df['No_of_times_DI_cross_'+str(w)+'D'] = df.groupby(groupby_col)['Indi_DI_cross'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
            #NUmber of Golden crosses in the last 5 days: # Create a rolling window of size 5, grouped by groupby_col
            df['plusDI_cross_from_below_'+str(w)+'D'] = df.groupby(groupby_col)['plusDI_cross_from_below'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
            #NUmber of Death crosses in the last 5 days:  #Create a rolling window of size 5, grouped by groupby_col
            df['plusDI_cross_from_above_'+str(w)+'D'] = df.groupby(groupby_col)['plusDI_cross_from_above'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
        return df

   #3    
    def ATR_Features(df, **kwargs):
        """"
        A function to create Features of ATR Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        n_ATR  : Period of ATR. Deafult:14
        window:_ATR rolling window period. default:5

        Output:
        Dataframe with ATR featres added.

        """
        n_ATR   =kwargs.get('n_ATR', 14)
        window_ATR =kwargs.get('window_ATR',[5])
        df['ATR'] =df.groupby(groupby_col).apply(lambda x: talib.ATR(x['high'],x['low'],x['close'],timeperiod=n_ATR)).reset_index(drop=True)
        df['Indicator_ATR'] = df.groupby(groupby_col)['ATR'].diff()
        df['Indicator_ATR'] = df['Indicator_ATR'].apply(lambda x: 1 if x>0 else (-1 if x<0 else 0))
        df['ATR_diff_in_1D']=df.groupby(groupby_col)['ATR'].diff().rolling(window=1,min_periods=0).mean().round(4)
        
        for w in window_ATR:
            df['No_Indicator_ATR_EQ1_inLast_'+str(w)+'D']=df.groupby(groupby_col).apply(lambda x: x['Indicator_ATR'].rolling(window=w,min_periods=0).apply(lambda x: (x == 1).sum())).reset_index(level=0,drop=True)
            #df['No_Indicator_ATR_EQ0_inLast_'+str(w)+'D']=df.groupby(groupby_col).apply(lambda x: x['Indicator_ATR'].rolling(window=w,min_periods=0).apply(lambda x: (x == 0).sum())).reset_index(level=0,drop=True)
            df['No_Indicator_ATR_EQ-1_inLast_'+str(w)+'D']=df.groupby(groupby_col).apply(lambda x: x['Indicator_ATR'].rolling(window=w,min_periods=0).apply(lambda x: (x == -1).sum())).reset_index(level=0,drop=True)
            df['ATR_SMA'+str(w)+'D'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.ATR, timeperiod=w)).reset_index(level=0,drop=True)
            df['Indi_ATR_gtAV_ATR_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: x.ATR > x['ATR_SMA'+str(w)+'D']).astype(int).reset_index(0, drop=True)
            #df[str(w)+'D'+'_Slope_ATR']  = df.groupby(groupby_col).apply(lambda x: (x['ATR']-x['ATR'].shift(w))/w).reset_index(drop=True)
        return df    
  #4
    def AROON_Features(df,**kwargs):
        """"
        A function to create Features of AD Line Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        n_AROON: Period of Aroon. Deafult:25
        window_AROON: rolling window period. default:5

        Output:
        Dataframe with Aroon featres added.

        """
        n_AROON   =kwargs.get('n_AROON', 25)
        window_AROON =kwargs.get('window_AROON',[5])
        df['Aroon_down'] =df.groupby(groupby_col).apply(lambda x: talib.AROON(x['high'],x['low'],timeperiod=n_AROON)[0]).reset_index(drop=True)
        df['Aroon_up'] =df.groupby(groupby_col).apply(lambda x: talib.AROON(x['high'],x['low'],timeperiod=n_AROON)[1]).reset_index(drop=True)

        #df['Aroon_Up_gt70_Down_lt30']=df.groupby(groupby_col).apply(lambda x: ((x['Aroon_up'] > 70) & (x['Aroon_down']<30)).astype(int)).reset_index(level=0,drop=True)
        df['Aroon_Up_lt70_Down_gt30']=df.groupby(groupby_col).apply(lambda x: ((x['Aroon_up'] < 70) & (x['Aroon_down']>30)).astype(int)).reset_index(level=0,drop=True)
        #df['Dist_Aroon_u&d']=df.groupby(groupby_col).apply(lambda x: x['Aroon_up']-x['Aroon_down']).reset_index(drop=True)
        df['Aroon_up_gt_50']=df.groupby(groupby_col)['Aroon_up'].apply(lambda x: (x > 50).astype(int)).reset_index(level=0,drop=True)
        #df['Aroon_down_lt_50']=df.groupby(groupby_col)['Aroon_down'].apply(lambda x: (x < 50).astype(int)).reset_index(level=0,drop=True)
        df = df.groupby(groupby_col).apply(lambda x: x.assign(Indicator_Aroon = np.where(x['Aroon_up'] > x['Aroon_down'], -1, np.where(x['Aroon_up'] < x['Aroon_down'],1,0)))).reset_index(level=0,drop=True)

        #Golden crosses
        df['Aroon_cross_Up_gt'] = ((df['Aroon_up'].shift(1) < df['Aroon_down'].shift(1)) & (df['Aroon_up'] > df['Aroon_down'])).astype(int)
        #Death crosses
        df['Aroon_cross_Up_lt'] = ((df['Aroon_up'].shift(1) > df['Aroon_down'].shift(1)) & (df['Aroon_up'] < df['Aroon_down'])).astype(int)
        #Number of crosses 
        df['Indi_Aroon_cross'] = (((df['Aroon_up'].shift(1) < df['Aroon_down'].shift(1)) & (df['Aroon_up'] > df['Aroon_down'])) | ((df['Aroon_up'].shift(1) > df['Aroon_down'].shift(1)) & (df['Aroon_up'] < df['Aroon_down']))).astype(int)
        df = df.groupby(groupby_col).apply(lambda x: x.assign(Indicator2_Aroon = np.where(((x['Aroon_up']==100) & (x['Aroon_down']==0)), 1, np.where(((x['Aroon_up']==0) & (x['Aroon_down']==100)),-1,0)))).reset_index(level=0,drop=True)

        df['pct_DaysAroon_U_gt_50_'+str(20)+'D']=df.groupby(groupby_col).apply(lambda x: x['Aroon_up_gt_50'].rolling(window=20,min_periods=0).apply(lambda x: (((x == 1).sum())/20)*100)).reset_index(level=0,drop=True)
      
        df[str(5)+'D'+'_Slope_Aroon_up']  = df.groupby(groupby_col).apply(lambda x: (x['Aroon_up']-x['Aroon_up'].shift(5))/5).reset_index(drop=True)
        df[str(20)+'D'+'_Slope_Aroon_down']  = df.groupby(groupby_col).apply(lambda x: (x['Aroon_down']-x['Aroon_down'].shift(20))/20).reset_index(drop=True)

        #NUmber of Golden crosses in the last 5 days:   # Create a rolling window of size 5, grouped by groupby_col
        df['Aroon_No_cross_Up_gt0_in_'+str(10)+'D'] = df.groupby(groupby_col)['Aroon_cross_Up_gt'].rolling(10, min_periods=0).sum().reset_index(0, drop=True)
        #NUmber of Death crosses in the last 5 days:   # Create a rolling window of size 5, grouped by groupby_col
        df['Aroon_No_cross_Up_lt_in_'+str(20)+'D'] = df.groupby(groupby_col)['Aroon_cross_Up_lt'].rolling(20, min_periods=0).sum().reset_index(0, drop=True)
     
        return df

    #5 
    def EOM_Features(df,**kwargs):
        """"
        A function to create Features of EOM Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        n_EOM : Period. Default=26
        window_EOM: rolling window period. default:5

        Output:
        Dataframe with EOM featres added.
        """
        n_EOM   =kwargs.get('n_EOM', 26)
        window_EOM =kwargs.get('window_EOM',[5])
        df['EOM'] =df.groupby(groupby_col).apply(lambda x: ta.volume.ease_of_movement(x['high'],x['low'],x['volume'])).reset_index(drop=True)
     
        for w in window_EOM:
            df[str(w)+'D_Slope_EOM']  = df.groupby(groupby_col).apply(lambda x: (x['EOM']-x['EOM'].shift(w))/w).reset_index(drop=True)
            df[str(w)+'D_Slope_Close']  = df.groupby(groupby_col).apply(lambda x: (x['close']-x['close'].shift(w))/w).reset_index(drop=True)
            df['No_EOM_gt_2_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x.EOM > 2).astype(int)).rolling(w,min_periods=0).sum()).reset_index(0, drop=True)
     

            df['Indicator_EOM_'+str(w)+'Slope'] = df.apply(lambda x: 1 if (x[str(w)+'D_Slope_Close'] > 0) & (x[str(w)+'D_Slope_EOM'] < 0) else -1 if (x[str(w)+'D_Slope_Close'] < 0) & (x[str(w)+'D_Slope_EOM'] > 0) else 0, axis=1)

      
            df['Indi_EOM_lt_crossover'] = ((df['EOM'].shift(1).fillna(0) > df[str(w)+'D_Slope_EOM'].shift(1).fillna(0)) & (df['EOM'].fillna(0) < df[str(w)+'D_Slope_EOM'].fillna(0))).astype(int)
            
            df.drop(str(w)+'D_Slope_Close', axis=1,inplace=True)    

        return df
    
   #6
    def FI_Features(df, **kwargs):
        """"
        A function to create Features of ATR Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_FI: rolling window period. Default:5
        groupby_col: Symbol column name to groupby 

        Output:
        Dataframe with FI featres added.
        """
        window_FI =kwargs.get('window_FI',[5])
        df['Force_Index'] =df.groupby(groupby_col).apply(lambda x: ta.volume.force_index(x['close'],x['volume'])).reset_index(drop=True)
        df = df.groupby(groupby_col).apply(lambda x: x.assign(Force_Index_EMA=talib.EMA(x.Force_Index, timeperiod=13)))
        #NUmber of Golden crosses in the last 5 days:
        #df['Force_cross_Up_gt'] = ((df['Force_Index_EMA'].shift(1) < 0) & (df['Force_Index_EMA'] > 0)).astype(int)
        #NUmber of Death crosses in the last 5 days:
        #df['Force_cross_Up_lt'] = ((df['Force_Index_EMA'].shift(1) > 0) & (df['Force_Index_EMA'] <0)).astype(int)
        #Number of crosses 
        df['Indi_Force_cross'] = (((df['Force_Index_EMA'].shift(1) < 0) & (df['Force_Index_EMA'] > 0)) | ((df['Force_Index_EMA'].shift(1) > 0) & (df['Force_Index_EMA'] < 0))).astype(int)

        df['No_Days_since_last_cross_Force'] =df.groupby(groupby_col)['Indi_Force_cross'].apply(lambda x: (x ==0).cumsum() - ( x==0).cumsum().where(x==1).ffill().fillna(0))
        
        return df
       
  #7  
    def KC_Features(df,**kwargs):
        """"
        A function to create Features of KC Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        n_KC: Keltner channel period. Deafult:14
        window_KC: rolling window period. Default:5
        groupby_col: Symbol column name to groupby 

        Output:
        Dataframe with KC featres added.

        """
        n_window_kC=kwargs.get('n_window_kC',20)
        n_kc_atr=kwargs.get('n_kc_atr',10 )
        window_KC=kwargs.get('window_KC',[5])
        df['keltner_hband'] =df.groupby(groupby_col).apply(lambda x: ta.volatility.keltner_channel_hband(high=x['high'],low=x['low'],close=x['close'],window=n_window_kC, window_atr=n_kc_atr)).reset_index(drop=True)
        df['keltner_mband'] =df.groupby(groupby_col).apply(lambda x: ta.volatility.keltner_channel_mband(high=x['high'],low=x['low'],close=x['close'],window=n_window_kC, window_atr=n_kc_atr)).reset_index(drop=True)
        df['keltner_lband'] =df.groupby(groupby_col).apply(lambda x: ta.volatility.keltner_channel_lband(high=x['high'],low=x['low'],close=x['close'],window=n_window_kC, window_atr=n_kc_atr)).reset_index(drop=True)
     
        df['keltner_channel_wband'] =df.groupby(groupby_col).apply(lambda x: ta.volatility.keltner_channel_wband(high=x['high'],low=x['low'],close=x['close'])).reset_index(drop=True)
        df['keltner_channel_pband'] =df.groupby(groupby_col).apply(lambda x: ta.volatility.keltner_channel_pband(high=x['high'],low=x['low'],close=x['close'])).reset_index(drop=True)
        df['Distance_close_low_Keltner']=df.groupby(groupby_col).apply(lambda x: x['close']-x['keltner_lband']).reset_index(drop=True)
        df['Dist_Keltner_u&l']=df.groupby(groupby_col).apply(lambda x: x['keltner_hband']-x['keltner_lband']).reset_index(drop=True)

        #Golden crosses 'U':
        df['Indi_keltnerU_gt_crossover'] = ((df['keltner_hband'].shift(1) < df['close'].shift(1)) & (df['keltner_hband'] > df['close'])).astype(int)
        #Death crosses 'U':
        df['Indi_keltnerU_lt_crossover'] = ((df['keltner_hband'].shift(1) > df['close'].shift(1)) & (df['keltner_hband'] < df['close'])).astype(int)

        #Golden crosses 'L':
        df['Indi_keltnerL_gt_crossover'] = ((df['keltner_lband'].shift(1) < df['close'].shift(1)) & (df['keltner_lband'] > df['close'])).astype(int)
        #Death crosses 'L':
        df['Indi_keltnerL_lt_crossover'] = ((df['keltner_lband'].shift(1) > df['close'].shift(1)) & (df['keltner_lband'] < df['close'])).astype(int)

        for w in window_KC:
            df['KeltnerU_MA_'+str(w)+'D'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.keltner_hband, timeperiod=w)).reset_index(level=0,drop=True)
            df['KeltnerL_MA_'+str(w)+'D'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.keltner_lband, timeperiod=w)).reset_index(level=0,drop=True)

            df["vol_Ukeltner_"+str(w)+'D']=df.groupby(groupby_col)['keltner_hband'].rolling(w).std().reset_index(0, drop=True)
            df["vol_Lkeltner_"+str(w)+'D']=df.groupby(groupby_col)['keltner_lband'].rolling(w).std().reset_index(0, drop=True)

            df['No_keltnerL_lt_crossover_inLast_'+str(w)+'D'] = df.groupby(groupby_col)['Indi_keltnerL_lt_crossover'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
        return df
    
   #8 
    def MACD_Features(df, **kwargs):
        
        """"
        A function to create Features of ATR Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        MACD_Fast_period: fastperiod (Default: 12).
        MACD_Slow_period: slowperiod (Default: 26).
        MACD_Signal_period: signalperiod (Default: 9).
        window_MACD: rolling window period. default:5

        Output:
        Dataframe with MACD features added.
        """
        MACD_Fast_period = kwargs.get('MACD_Fast_period', [12])
        MACD_Slow_period = kwargs.get('MACD_Slow_period', [26]) 
        MACD_Signal_period = kwargs.get('MACD_Signal_period', 9)
        window_MACD = kwargs.get('window_MACD', [5])

        for f in MACD_Fast_period:
            for s in MACD_Slow_period:
                if f < s:
                    macd_column_name = 'MACD_' + str(f) + 'f_' + str(s) + 's'

                    signal_column_name = 'MACD_signal'
                    df[macd_column_name] = df.groupby(groupby_col)['close'].transform(lambda x: talib.MACD(x, fastperiod=f, slowperiod=s, signalperiod=MACD_Signal_period)[0])
                    df[signal_column_name] = df.groupby(groupby_col)['close'].transform(lambda x: talib.MACD(x, fastperiod=f, slowperiod=s, signalperiod=MACD_Signal_period)[1])
                    df['Indicator_' + macd_column_name + '_gt_Signal'] = (df[macd_column_name] > df[signal_column_name]).astype(int)
                    df['Indi_' + macd_column_name + '_cross_SIGNAL'] = (((df[signal_column_name].shift(1) < df[macd_column_name].shift(1)) &(df[signal_column_name] > df[macd_column_name])) |((df[signal_column_name].shift(1) > df[macd_column_name].shift(1)) &(df[signal_column_name] < df[macd_column_name]))).astype(int)
                    df['Indi_' + macd_column_name + '_lt_signal'] = ((df[signal_column_name].shift(1) < df[macd_column_name].shift(1)) &(df[signal_column_name] > df[macd_column_name])).astype(int)
                    df['Indi_' + macd_column_name + '_gt_signal'] = ((df[signal_column_name].shift(1) > df[macd_column_name].shift(1)) &(df[signal_column_name] < df[macd_column_name])).astype(int)

                    for w in window_MACD:
                        df[macd_column_name + '_LT_0_' + str(w) + 'D'] = df.groupby(groupby_col)[macd_column_name].rolling(window=w).sum().reset_index(0, drop=True).lt(0).astype(int)
                        df[macd_column_name + '_GT_0_' + str(w) + 'D'] = df.groupby(groupby_col)[macd_column_name].rolling(window=w).sum().reset_index(0, drop=True).gt(0).astype(int)
                        df['vol_' + macd_column_name + '_in_' + str(w) + 'D'] = df.groupby(groupby_col)[macd_column_name].rolling(5).std().reset_index(0, drop=True)

                        df['No_' + macd_column_name + '_cross_signal_inLast_' + str(w) + 'D'] = df.groupby(groupby_col)['Indi_' + macd_column_name + '_cross_SIGNAL'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
                        df['No_' + macd_column_name + '_lt_signal_' + str(w) + 'D'] = df.groupby(groupby_col)['Indi_' + macd_column_name + '_lt_signal'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
                        
                        df['No_Days_since_last cross_'+ macd_column_name] =df.groupby(groupby_col)['No_'+macd_column_name +'_cross_signal_inLast_'+str(w)+'D'].apply(lambda x: (x ==0).cumsum() - ( x==0).cumsum().where(x==1).ffill().fillna(0))
#                 else:
#                     print('No Fast period is less than slow period. MACD Features will NOT be added.')
        return df

        #9
    def Parabolic_SAR_Features(df, **kwargs): 
        """"
        A function to create Features of Parabolic Stop & Reverse(SAR) Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_SAR: rolling window period. default:5

        Output:
        Dataframe with Parabolic SAR featres added.
        """
        window_SAR=kwargs.get('window_SAR', [5])

        df['Parabolic_SAR'] =df.groupby(groupby_col).apply(lambda x: talib.SAR(x['high'],x['low'])).reset_index(drop=True)
       
        df['Indicator_SAR1']  = df.groupby(groupby_col).apply(lambda x: x.Parabolic_SAR > x.close).astype(int).reset_index(0, drop=True)
        df['50_SMA_close'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.close, timeperiod=5)).reset_index(level=0,drop=True)
        df['Indicator_SAR'] = df.apply(lambda x: 1 if (x['Parabolic_SAR'] < x['close']) & (x['close'] > x['50_SMA_close']) else -1 if(x['Parabolic_SAR'] > x['close']) & (x['close'] < x['50_SMA_close']) else 0, axis=1)

        #Golden crosses :
        df['Parabolic_SAR_cross_gt'] = ((df['close'].shift(1) < df['Parabolic_SAR'].shift(1)) & (df['close'] > df['Parabolic_SAR'])).astype(int)
        #Death crosses :
        df['Parabolic_SAR_cross_lt'] = ((df['close'].shift(1) > df['Parabolic_SAR'].shift(1)) & (df['close'] < df['Parabolic_SAR'])).astype(int)
        #Number of crosses 
        df['Indi_Parabolic_SAR_cross'] = (((df['close'].shift(1) < df['Parabolic_SAR'].shift(1)) & (df['close'] > df['Parabolic_SAR'])) | ((df['close'].shift(1) > df['Parabolic_SAR'].shift(1)) & (df['close'] < df['Parabolic_SAR']))).astype(int)

        #for w in window_SAR:
            #df[str(w)+'D_Slope_SAR']  = df.groupby(groupby_col).apply(lambda x: (x['Parabolic_SAR']-x['Parabolic_SAR'].shift(w))/w).reset_index(drop=True)
        df['Parabolic_SAR_SMA_'+str(5)+'D'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.Parabolic_SAR, timeperiod=5)).reset_index(level=0,drop=True)
        #Golden crosses in the last 5 days:  # Create a rolling window of size 5, grouped by groupby_col
        df['Parabolic_SAR_No_cross_gt_inLast_'+str(10)+'D'] = df.groupby(groupby_col)['Parabolic_SAR_cross_gt'].rolling(10, min_periods=0).sum().reset_index(0, drop=True)
        #NUmber of Death crosses in the last 5 days:  # Create a rolling window of size 5, grouped by groupby_col
        df['Parabolic_SAR_No_cross_lt_inLast_'+str(20)+'D'] = df.groupby(groupby_col)['Parabolic_SAR_cross_lt'].rolling(20, min_periods=0).sum().reset_index(0, drop=True)
        #Number of crosses     # Create a rolling window of size 5, grouped by groupby_col
        df['No_Parabolic_SAR_cross_inLast_'+str(20)+'D'] = df.groupby(groupby_col)['Indi_Parabolic_SAR_cross'].rolling(20, min_periods=0).sum().reset_index(0, drop=True)
        #df['No_Days_since_last_cross_Parabolic_SAR'] =df.groupby(groupby_col)['No_Parabolic_SAR_cross_inLast_'+str(w)+'D'].apply(lambda x: (x ==0).cumsum() - ( x==0).cumsum().where(x==1).ffill().fillna(0))
        df.drop('50_SMA_close', axis=1,inplace=True)     
        return df
      
   #10 
    def PVO_Features(df,**kwargs):
        """"
        A function to create Features of PVO Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_fast(int): n1_PVO period short-term.Default:12
        window_slow(int): n2_PVO period long-term. Default:26
        window_sign(int): n3_PVO period to signal.Default: 9
        window_PVO: rolling window period. default:5

        Output:
        Dataframe with ATR featres added.
        """
        PVO_Fast_period=kwargs.get('PVO_Fast_period',[12])
        PVO_Slow_period=kwargs.get('PVO_Slow_period',[26]) 
        PVO_Signal_period=kwargs.get('PVO_Signal_period',9)
        window_PVO=kwargs.get('window_PVO', [5])

        for f in PVO_Fast_period:
            for s in PVO_Slow_period:
                if (f<s):
                    df['PVO_'+str(f)+'f_'+str(s)+'s'] =df.groupby(groupby_col).apply(lambda x: ta.momentum.pvo(x['volume'], window_fast=f,window_slow=s)).reset_index(drop=True)
                    df['PVO_signal'] =df.groupby(groupby_col).apply(lambda x: ta.momentum.pvo_signal(x['volume'],window_sign=PVO_Signal_period)).reset_index(drop=True)
                    df['PVO_'+str(f)+'f_'+str(s)+'s_hist'] =df.groupby(groupby_col).apply(lambda x: ta.momentum.pvo_hist(x['volume'])).reset_index(drop=True)
                    df['Indicator_PVO_'+str(f)+'f_'+str(s)+'s'] = df.groupby(groupby_col)['PVO_'+str(f)+'f_'+str(s)+'s'].apply(lambda x: x>0 ).astype(int)

                    #Golden crosses :
                    df['Indi_PVO_'+str(f)+'f_'+str(s)+'s_gt_crossover'] = (((df['PVO_'+str(f)+'f_'+str(s)+'s'].shift(1) < df['PVO_signal'].shift(1)) & (df['PVO_'+str(f)+'f_'+str(s)+'s'] > df['PVO_signal']))& (df['PVO_'+str(f)+'f_'+str(s)+'s_hist'] > 0)).astype(int)

                    #Death crosses :
                    df['Indi_PVO_'+str(f)+'f_'+str(s)+'s_lt_crossover'] = ((df['PVO_'+str(f)+'f_'+str(s)+'s'].shift(1) < df['PVO_signal'].shift(1)) & (df['PVO_'+str(f)+'f_'+str(s)+'s'] > df['PVO_signal'])  & (df['PVO_'+str(f)+'f_'+str(s)+'s_hist'] < 0)).astype(int)

                    #for w in window_PVO:
                    df['No_PVO_'+str(f)+'f_'+str(s)+'s'+'_gt0_'+str(5)+'D']  = df.groupby(groupby_col).apply(lambda x: (((x['PVO_'+str(f)+'f_'+str(s)+'s'] > 0)).astype(int)).rolling(5).sum()).reset_index(0, drop=True)
                    df['No_PVO_'+str(f)+'f_'+str(s)+'s_Lt0_'+str(5)+'D']  = df.groupby(groupby_col).apply(lambda x: (((x['PVO_'+str(f)+'f_'+str(s)+'s'] < 0)).astype(int)).rolling(5).sum()).reset_index(0, drop=True)
                    df[str(10)+'D'+'_Slope_PVO_'+str(f)+'f_'+str(s)+'s']  = df.groupby(groupby_col).apply(lambda x: (x['PVO_'+str(f)+'f_'+str(s)+'s']-x['PVO_'+str(f)+'f_'+str(s)+'s'].shift(10))/10).reset_index(drop=True)
    
                    for w in window_PVO:
                        #NUmber of Golden crosses in the last W days: # Create a rolling window of size 5, grouped by groupby_col
                        df['No_times_PVO_'+str(f)+'f_'+str(s)+'s_gt_crossover_inLast_'+str(w)+'D'] = df.groupby(groupby_col)['Indi_PVO_'+str(f)+'f_'+str(s)+'s_gt_crossover'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
                        #NUmber of Death crosses in the last w days: # Create a rolling window of size 5, grouped by groupby_col
                        df['No_times_PVO_'+str(f)+'f_'+str(s)+'s_lt_crossover_inLast_'+str(w)+'D'] = df.groupby(groupby_col)['Indi_PVO_'+str(f)+'f_'+str(s)+'s_lt_crossover'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
#                 else:
#                     print('No Fast period is less than slow period. PVO Features will NOT be added.')

        return df

    #11
    def RSI_Features(df, **kwargs):
        """"
        A function to create Features of RSI Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        n_RSI  : Period of RSI. Deafult:14
        window_RSI: rolling window period. default:5

        Output:
        Dataframe with RSI featres added.
        """
        n_RSI=kwargs.get('n_RSI',14)
        window_RSI=kwargs.get('window_RSI',[5])
        
        df['RSI'] = df.groupby(groupby_col)['close'].apply(lambda y: talib.RSI(y,timeperiod= n_RSI))
       
        df['No_RSI_lt30_inLast_'+str(5)+'D'] = df.groupby(groupby_col).apply(lambda x: x['RSI'].rolling(window=5,min_periods=0).apply(lambda x: (x < 30).sum())).reset_index(level=0,drop=True)
        #df['RSI_diff_in_'+str(w)+'D']=df.groupby(groupby_col)['RSI'].diff().rolling(window=w).mean().round(4)
        return df
    
    #12
    def STOCH_Features(df,**kwargs):
        """"
        A function to create Features of Stochastic Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_STOCH: rolling window period. default:5

        Output:
        Dataframe with window_STOCH featres added.
        """
        window_STOCH=kwargs.get('window_STOCH',[5])
        
        df['slowk'] =df.groupby(groupby_col).apply(lambda x: talib.STOCH(x['high'],x['low'],x['close'])[0]).reset_index(drop=True)
        df['slowd'] =df.groupby(groupby_col).apply(lambda x: talib.STOCH(x['high'],x['low'],x['close'])[1]).reset_index(drop=True)
      
        #Golden crosses
        df['golden_cross_stochastic'] = (((df['slowk'].shift(1) < df['slowd'].shift(1)) & (df['slowk'] > df['slowd']))&((df['slowk'] <20)&(df['slowd'] <20))).astype(int)
      
        #for w in window_STOCH:
        df[str(15)+'D_Slope_Stochd']  = df.groupby(groupby_col).apply(lambda x: (x['slowd']-x['slowd'].shift(15))/15).reset_index(drop=True)
        #df['No_times_stochk_gt80_'+str(w)+'D']=df.groupby(groupby_col).apply(lambda x: x['slowk'].rolling(window=w,min_periods=0).apply(lambda x: (x > 80).sum())).reset_index(level=0,drop=True)
        df['No_times_stochk_lt20_'+str(20)+'D']=df.groupby(groupby_col).apply(lambda x: x['slowk'].rolling(window=20,min_periods=0).apply(lambda x: (x < 20).sum())).reset_index(level=0,drop=True)
       
        df['Indicator_STOCH_'+str(15)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['slowk'] > x['slowd']).astype(int)).rolling(15).sum()).reset_index(0, drop=True)

        #Number of Golden crosses in the last 5 days:    # Create a rolling window of size 5, grouped by groupby_col
        df['No_golden_cross_stochastic_in_'+str(20)+'D'] = df.groupby(groupby_col)['golden_cross_stochastic'].rolling(20, min_periods=0).sum().reset_index(0, drop=True)

        return df

    #13
    def VPT_Features(df,**kwargs):
        """"
        A function to create Features of VPT Indicator
        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_VPT: rolling window period. default:5

        Output:
        Dataframe with VPT featres added.
        """
        window_VPT=kwargs.get('window_VPT',[5])
        
        df['VPT'] =df.groupby(groupby_col).apply(lambda x: ta.volume.volume_price_trend(x['close'],x['volume'])).reset_index(drop=True)
        df = df.groupby([groupby_col]).apply(lambda x: x.assign(VPT_EMA=talib.EMA(x.VPT, timeperiod=9)))
        #df['Indicator_VPT']  = df.groupby(groupby_col).apply(lambda x: x['VPT'] > x['VPT'].shift(1)).astype(int).reset_index(0, drop=True)

        #Golden crosses:
        df['Indi_VPT_gt_crossover'] = ((df['VPT'].shift(1) < df['VPT_EMA'].shift(1)) & (df['VPT'] > df['VPT_EMA'])).astype(int).reset_index(0, drop=True)
   
        df['ADX'] =df.groupby(groupby_col).apply(lambda x: talib.ADX(x['high'],x['low'],x['close'])).reset_index(drop=True)
        df['ADX_gt25_vpt_gt_Signal']= df.groupby(groupby_col).apply(lambda x: ((x['ADX'] > 25) &(x['VPT']>x['VPT_EMA'])).astype(int)).reset_index(0, drop=True)
        df['ADX_lt25_vpt_lt_Signal']= df.groupby(groupby_col).apply(lambda x: ((x['ADX'] < 25) &(x['VPT'] < x['VPT_EMA'])).astype(int)).reset_index(0, drop=True)
        #df = df.groupby([groupby_col]).apply(lambda x: x.assign(SMA_10=talib.SMA(x.close, timeperiod=5),SMA_25=talib.SMA(x.close, timeperiod=10))).reset_index(drop=True)

 
        df.drop(['ADX'],axis = 1, inplace =True)
        #df.drop(drop_list, axis=1,inplace=True)      
        return df
    
    #14 
    def VWAP_Features(df,**kwargs):
        """"
        A function to create Features of volumw weighted average price (VWAP) Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_VWAP: rolling window period. default:5

        Output:
        Dataframe with VWAP featres added.
        """
        window_VWAP=kwargs.get('window_VWAP',[5])
        
        df['VWAP'] =df.groupby(groupby_col).apply(lambda x: ta.volume.volume_weighted_average_price(x['high'],x['low'],x['close'],x['volume'])).reset_index(drop=True)
        
        return df

    #15
    def WILLR_Features(df,**kwargs):
        """"
        A function to create Features of WILLR Indicator

        Input:
        df : OHLCV Data with Symbol column as Dataframe

        Parameters:
        window_WILLR: rolling window period. default:5
        groupby_col: Symbol column name to groupby 

        Output:
        Dataframe with WILLR featres added.
        """
        window_WILLR=kwargs.get('window_WILLR',[5])
        
        df['WILLR'] =df.groupby(groupby_col).apply(lambda x: talib.WILLR(x['high'],x['low'],x['close'])).reset_index(drop=True)
      
        df['WILLR_MA_'+str(15)+'D'] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.WILLR, timeperiod=15)).reset_index(level=0,drop=True)

         #Golden crosses:
        df['Indi_WILLR_gt_crossover'] = ((df['WILLR'].shift(1) < df['WILLR_MA_'+str(15)+'D'].shift(1)) & (df['WILLR'] > df['WILLR_MA_'+str(15)+'D'])).astype(int)
        #Death crosses:
        
        #NUmber of Golden crosses in the last 5 days:    # Create a rolling window of size 5, grouped by groupby_col
        df['No_of_times_WILLR_gt_crossover_in_'+str(15)+'D'] = df.groupby(groupby_col)['Indi_WILLR_gt_crossover'].rolling(15, min_periods=0).sum().reset_index(0, drop=True)
        
        return df 
    #16 Candlestick
    def CandleStick_Features(df):
        '''
        A function to create Features of the Candlestick Patterns

        Input:
        df : OHLCV data with symbols as dataframe
        groupby_col : Symbol column name to groupby

        Output:
        Dataframe with CandleStick features added
        '''
        
        df = df.groupby(groupby_col).apply(lambda x: x.assign(Doji = np.where(x['close'] == x['open'], 1, 0)))
        
        return df
    #17 ROC
    def ROC_Features(df, **kwargs):
        '''
        A function to create Features of ROC Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_ROC : Period of ROC, default period is 10
        window_ROC : Rolling window period (For considering number of days before), default window is 5
        SMA_period_ROC : To calculate SMA of ROC, what period to consider, default is 5

        Output:
        Dataframe with ROC features added
        '''
        n_ROC = kwargs.get('n_ROC',10)
        window_ROC = kwargs.get('window_ROC',[5])
        SMA_period_ROC = kwargs.get('SMA_period_ROC',[5])

        df['ROC'] = df.groupby(groupby_col)['close'].apply(lambda x: talib.ROC(x, timeperiod=n_ROC))
        df["ROC_Thresholds"] = df.groupby(groupby_col)['ROC'].apply(lambda x: x.apply(lambda y: 1 if y > 1 else -1 if y < -1 else 0))
        
        df['Slope_ROC'+str(15)]  = df.groupby(groupby_col).apply(lambda x: (x['ROC']-x['ROC'].shift(15))/15).reset_index(drop=True)

        return df

    #18 PVI
    def PVI_Features(df, **kwargs):
        '''
        A function to create Features of PVI indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        window_PVI : Rolling window period (For considering number of days before), default window is 5 
        Fast_SMA_period_PVI : To calculate Fast SMA, what period to consider, default is 9
        Slow_SMA_period_PVI : To calculate Slow SMA, what period to consider, default is 26

        Output:
        Dataframe with PVI features added
        '''
        window_PVI = kwargs.get('window_PVI',[5])
        Fast_SMA_period_PVI = kwargs.get('Fast_SMA_period_PVI',9)
        Slow_SMA_period_PVI = kwargs.get('Slow_SMA_period_PVI', 26)
        df['pvi'] = df.groupby(groupby_col).apply(lambda x: pta.pvi(x['close'], x['volume'], initial=1000)).reset_index(level=0, drop=True)
        
        df = df.groupby(groupby_col).apply(lambda x: x.assign(Fast_SMA_of_PVI=talib.SMA(x.pvi, timeperiod=Fast_SMA_period_PVI))).reset_index(drop=True)
        df = df.groupby(groupby_col).apply(lambda x: x.assign(Slow_SMA_of_PVI=talib.SMA(x.pvi, timeperiod=Slow_SMA_period_PVI))).reset_index(drop=True)
        
        for w in window_PVI:
            #df['Slope_PVI_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: (x['pvi']-x['pvi'].shift(w))/w).reset_index(drop=True)
            df['Slope_of_Fast_SMA_of_PVI'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: (x['Fast_SMA_of_PVI']-x['Fast_SMA_of_PVI'].shift(w))/w).reset_index(drop=True)
            df['Slope_of_Slow_SMA_of_PVI'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: (x['Slow_SMA_of_PVI']-x['Slow_SMA_of_PVI'].shift(w))/w).reset_index(drop=True)
            df['PVI_Min_in_last_'+str(w)+'D'] = df.groupby(groupby_col)['pvi'].rolling(w).min().reset_index(0, drop=True)
            df['PVI_Max_in_last_'+str(w)+'D'] = df.groupby(groupby_col)['pvi'].rolling(w).max().reset_index(0, drop=True)
        return df

    #19 NVI
    def NVI_Features(df, **kwargs):
        '''
        A function to create Features of NVI indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        window_NVI : Rolling window period (For considering number of days before), default window is 5
        SMA_period_NVI : To calculate SMA, what period to consider, default is 26

        Output:
        Dataframe with NVI features added
        '''
        window_NVI = kwargs.get('window_NVI',[5])
        SMA_period_NVI = kwargs.get('SMA_period_NVI',[26])

        df['nvi'] = df.groupby(groupby_col).apply(lambda x: ta.volume.NegativeVolumeIndexIndicator(x['close'], x['volume']).negative_volume_index()).reset_index(drop=True)
    
        for w in window_NVI:
            
            for p in SMA_period_NVI:
                df['SMA_NVI_'+str(p)] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.nvi , timeperiod=p)).reset_index(drop=True)
                df['Count_NVI_gt_SMA_of_NVI_'+str(p)+'_in_last_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['nvi'] >  x['SMA_NVI_'+str(p)]).astype(int)).rolling(w).sum()).reset_index(0, drop=True)
                df['Count_NVI_lt_SMA_of_NVI_'+str(p)+'_in_last_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['nvi'] <  x['SMA_NVI_'+str(p)]).astype(int)).rolling(w).sum()).reset_index(0, drop=True)
                df['Slope_of_SMA_of_nvi_'+str(p)+'in_last'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: (x['SMA_NVI_'+str(p)]-x['SMA_NVI_'+str(p)].shift(w))/w).reset_index(drop=True) 
        return df


    #20 MFI
    def MFI_Features(df, **kwargs):
        '''
        A function to create Features of MFI Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_MFI : Period of MFI, default period is 14
        window_MFI : Rolling window period (For considering number of days before), default window is 5
        SMA_period_MFI : To calculate SMA, what period to consider, default is 20

        Output:
        Dataframe with MFI features added
        '''
        n_MFI = kwargs.get('n_MFI',14)
        window_MFI = kwargs.get('window_MFI', [5])
        SMA_period_MFI = kwargs.get('SMA_period_MFI', [20])
        df['MFI'] = df.groupby(groupby_col).apply(lambda x: talib.MFI(x['high'], x['low'], x['close'], x['volume'], timeperiod=n_MFI)).reset_index(drop=True)
        
        df['Count_MFI_gt_80_in_last_'+str(15)+'D'] = df.groupby(groupby_col).apply(lambda x: x['MFI'].rolling(15).apply(lambda x: (x>80).sum())).reset_index(drop=True)
        df['Slope_MFI_'+str(5)]  = df.groupby(groupby_col).apply(lambda x: (x['MFI']-x['MFI'].shift(5))/5).reset_index(drop=True)
        df['SMA_MFI_'+str(20)] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.MFI , timeperiod=20)).reset_index(drop=True)
        return(df)

    #21 Donchian_Channel
    def Donchian_Channel_Features(df, **kwargs):
        '''
        A function to create Features of Donchian_Channel Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_DC: Period of DC, default period is 20
        window_DC: Rolling window period (For considering number of days before), default window is 5

        Output:
        Dataframe with DC features added
        '''
        n_DC = kwargs.get('n_DC',[20])
        window_DC = kwargs.get('window_DC', [5])

        for i in n_DC:
            df['upper_band_Donchian_'+str(i)] = df.groupby(groupby_col).apply(lambda x: ta.volatility.DonchianChannel(high=x['high'], low=x['low'], close=x['close'], window=i).donchian_channel_hband()).reset_index(level=0, drop=True)
            df['lower_band_Donchian_'+str(i)] = df.groupby(groupby_col).apply(lambda x: ta.volatility.DonchianChannel(high=x['high'], low=x['low'], close=x['close'], window=i).donchian_channel_lband()).reset_index(level=0, drop=True)
            df['diff_Upper_Donchian_Lower_Donchian'+str(i)]  = df.groupby(groupby_col).apply(lambda x: (x['upper_band_Donchian_'+str(i)]-x['lower_band_Donchian_'+str(i)])).reset_index(drop=True)

            for w in window_DC:
                df['Upper_Donchian_'+str(i)+'_Std_Dev_'+str(w)+'D'] = df.groupby(groupby_col)['upper_band_Donchian_'+str(i)].rolling(w).std().reset_index(0, drop=True)
                df['Lower_Donchian_'+str(i)+'_Std_Dev_'+str(w)+'D'] = df.groupby(groupby_col)['lower_band_Donchian_'+str(i)].rolling(w).std().reset_index(0, drop=True)
        return df


    #22 Bollinger_Bands 
    def BB_Features(df, **kwargs):
        '''
        A function to create Features of BB indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_BB: Period of SMA for the creation of the middle band, default is 20
        window_BB : Rolling window period (For considering number of days before), default window is 5
        SMA_period_BB : To calculate SMA, what period to consider, default is 5

        Output:
        Dataframe with BB features added
        '''
        n_BB = kwargs.get('n_BB',20)
        window_BB = kwargs.get('window_BB', [5])
        SMA_period_BB = kwargs.get('SMA_period_BB',[5])

        #df['middle_bb_'+str(n_BB)] = df.groupby(groupby_col).apply(lambda x: ta.volatility.bollinger_mavg(x['close'], window=n_BB, fillna=False)).reset_index(drop=True)
        df['upper_bb_'+str(n_BB)] =  df.groupby(groupby_col).apply(lambda x: ta.volatility.bollinger_hband(x['close'], window=n_BB, window_dev=2, fillna=False)).reset_index(drop=True)
        df['lower_bb_'+str(n_BB)] = df.groupby(groupby_col).apply(lambda x: ta.volatility.bollinger_lband(x['close'], window=n_BB, window_dev=2, fillna=False)).reset_index(drop=True)

        df = df.groupby(groupby_col).apply(lambda x: x.assign(compare_close_and_UpperBB = np.where(x['close'] > x['upper_bb_'+str(n_BB)], 1, 0)))
        df = df.groupby(groupby_col).apply(lambda x: x.assign(compare_close_and_LowerBB = np.where(x['close'] < x['lower_bb_'+str(n_BB)], 1, 0)))
        df = df.groupby(groupby_col).apply(lambda x: x.assign(diff_UpperBB_and_LowerBB = x['upper_bb_'+str(n_BB)]-x['lower_bb_'+str(n_BB)]))
        df['Std_Dev_UpperBB_'+str(5)+'D']  = df.groupby(groupby_col).apply(lambda x: (x['upper_bb_'+str(n_BB)].rolling(5).std())).reset_index(drop=True)
        df['Std_Dev_LowerBB_'+str(5)+'D']  = df.groupby(groupby_col).apply(lambda x: (x['lower_bb_'+str(n_BB)].rolling(5).std())).reset_index(drop=True)
        df['SMA_UpperBB_'+str(5)]  = df.groupby(groupby_col).apply(lambda x: (x['upper_bb_'+str(n_BB)].rolling(5).mean())).reset_index(drop=True)
        df['SMA_LowerBB_'+str(5)]  = df.groupby(groupby_col).apply(lambda x: (x['lower_bb_'+str(n_BB)].rolling(5).mean())).reset_index(drop=True)                                                                                                                                                                                                                                         
        return df


    #23 CMF
    def CMF_Features(df, **kwargs):
        '''
        A function to create Features of CMF Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_CMF : Period of CMF, default period is 20
        window_CMF : Rolling window period, default window is 5
        EMA_period_CMF : To calculate EMA, what period to consider, default is 20

        Output:
        Dataframe with CMF features added
        '''
        n_CMF  = kwargs.get('n_CMF',20)
        window_CMF = kwargs.get('window_CMF',[5])
        EMA_period_CMF = kwargs.get('EMA_period_CMF', [20])
        df['EMA_close_for_CMF_5'] =df.groupby(groupby_col).apply(lambda x: talib.EMA(x.close , timeperiod=5)).reset_index(drop=True)
                
        return df

    #24 OBV
    def OBV_Features(df, **kwargs):
        '''
        A function to create Features of OBV indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        window_OBV : Rolling window period (For considering number of days before), default window is 5 
        SMA_period_OBV : To calculate  SMA, what period to consider, default is 20

        Output:
        Dataframe with OBV features added
        '''
        window_OBV = kwargs.get('window_OBV', [5])
        SMA_period_OBV = kwargs.get('SMA_period_OBV',[20])
        df['OBV'] = df.groupby(groupby_col).apply(lambda x: talib.OBV(x['close'], x['volume'])).reset_index(drop=True)
        #df = df.groupby(groupby_col).apply(lambda x: x.assign(Compare_Today_and_Yesterday_OBV = np.where(x['OBV'] > x['OBV'].shift(1), 1, 0)))
        for w in window_OBV:     
            df['OBV_Std_Dev_'+str(w)+'D'] = df.groupby(groupby_col)['OBV'].rolling(w).std().reset_index(0, drop=True)

            for p in SMA_period_OBV:
                df['MA_of_OBV_'+str(p)] = df.groupby(groupby_col)['OBV'].rolling(p).mean().reset_index(0, drop=True)
                df['Indicator_for_Cross_of_OBV_and_SMA_of_OBV_'+str(p)] = (((df['OBV'].shift(1) < df['MA_of_OBV_'+str(p)].shift(1)) & (df['OBV'] > df['MA_of_OBV_'+str(p)])) | ((df['OBV'].shift(1) > df['MA_of_OBV_'+str(p)].shift(1)) & (df['OBV'] < df['MA_of_OBV_'+str(p)]))).astype(int)
                df['Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_'+str(p)] =df.groupby(groupby_col)['Indicator_for_Cross_of_OBV_and_SMA_of_OBV_'+str(p)].apply(lambda x: (x ==0).cumsum() - ( x==0).cumsum().where(x==1).ffill().fillna(0))
                df['golden_cross_OBV_and_SMA_of_OBV_'+str(p)+'Indicator_'+str(w)+'D'] = ((df['OBV'].shift(1) < df['MA_of_OBV_'+str(p)].shift(1)) & (df['OBV'] > df['MA_of_OBV_'+str(p)])).astype(int)
                df['Count_of_golden_crosses_OBV_and_SMA_of_OBV_'+str(p)+'_in_'+str(w)+'D'] = df.groupby(groupby_col)['golden_cross_OBV_and_SMA_of_OBV_'+str(p)+'Indicator_'+str(w)+'D'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
              
        return df
        
    #25 UI
    def UI_Features(df, **kwargs):
        '''
        A function to create Features of UI Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_UI : Period of UI, default period is 14
        window_UI : Rolling window period (For considering number of days before), default window is 5
        SMA_period_UI : To calculate SMA , what period to consider, default is 14

        Output:
        Dataframe with UI features added
        '''
        n_UI = kwargs.get('n_UI', 14)
        window_UI = kwargs.get('window_UI',[5])
        SMA_period_UI = kwargs.get('SMA_period_UI',[14])
        df['ulcer_index'] = df.groupby(groupby_col)['close'].apply(lambda x: ta.volatility.ulcer_index(x, window=n_UI))

        #for w in window_UI:
        df['Slope_UI'+str(15)]  = df.groupby(groupby_col).apply(lambda x: (x['ulcer_index']-x['ulcer_index'].shift(15))/15).reset_index(drop=True)
        df['Slope_UI'+str(10)]  = df.groupby(groupby_col).apply(lambda x: (x['ulcer_index']-x['ulcer_index'].shift(10))/10).reset_index(drop=True)

        df['Count_Slope_of_UI_gt_0_in_last_'+str(10)+'D'] = df.groupby(groupby_col)['Slope_UI'+str(10)].rolling(window = 10).agg(lambda x: (x>0).sum()).reset_index(drop=True)
        df['Count_Slope_of_UI_lt_0_in_last_'+str(10)+'D'] = df.groupby(groupby_col)['Slope_UI'+str(10)].rolling(window = 10).agg(lambda x: (x<0).sum()).reset_index(drop=True)
        df['UI_Min_'+str(5)+'D'] = df.groupby(groupby_col)['ulcer_index'].rolling(5).min().reset_index(0, drop=True)
        df['UI_Max_'+str(5)+'D'] = df.groupby(groupby_col)['ulcer_index'].rolling(5).max().reset_index(0, drop=True)
        for w in window_UI:
            for p in SMA_period_UI:
                df['SMA_of_UI_'+str(p)] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x['ulcer_index'] , timeperiod=p)).reset_index(drop=True)
                df['Count_UI_lt_UI_SMA_'+str(p)+'_in_last_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['ulcer_index']<  x['SMA_of_UI_'+str(p)]).astype(int)).rolling(w).sum()).reset_index(0, drop=True)
                df['Count_UI_gt_UI_SMA_'+str(p)+'_in_last_'+str(w)+'D']  = df.groupby(groupby_col).apply(lambda x: ((x['ulcer_index']>  x['SMA_of_UI_'+str(p)]).astype(int)).rolling(w).sum()).reset_index(0, drop=True)
        return df

    #27 CCI
    def CCI_Features(df, **kwargs):
        '''
        A function to create Features of CCI Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        n_CCI : Period of CCI, default period is 20
        window_CCI : Rolling window period (For considering number of days before), default window is 5
        SMA_period_CCI : To calculate SMA, what period to consider, default is 5

        Output:
        Dataframe with CCI features added
        '''
        n_CCI = kwargs.get('n_CCI',20)
        window_CCI = kwargs.get('window_CCI', [5])
        SMA_period_CCI = kwargs.get('SMA_period_CCI', [5])
        df['cci'] = df.groupby(groupby_col).apply(lambda x: talib.CCI(x['high'], x['low'], x['close'], timeperiod=n_CCI)).reset_index(drop=True)
        df["cci_Thresholds_Indicator"] = df.groupby(groupby_col)["cci"].apply(lambda x: x.apply(lambda y: 1 if y > 200 else -1 if y < -200 else 0))
  
        return df

    #28 Ichimoku
    def Ichimoku_Features(df, **kwargs):
        '''
        A function to create Features of Ichimoku Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        window_Ichimoku : Rolling window period (For considering number of days before), default window is 5

        Output:
        Dataframe with Ichimoku features added
        '''
        window_Ichimoku = kwargs.get('window_Ichimoku', [5])
        df['ichimoku_conversion_line'] = df.groupby(groupby_col).apply(lambda x: ta.trend.ichimoku_conversion_line(x['high'], x['low'])).reset_index(drop=True)
        df['ichimoku_base_line'] = df.groupby(groupby_col).apply(lambda x: ta.trend.ichimoku_base_line(x['high'], x['low'])).reset_index(drop=True)
        df = df.groupby(groupby_col).apply(lambda x: x.assign(compare_Conversion_Baseline_Ichimoku = np.where(x['ichimoku_conversion_line'] > x['ichimoku_base_line'], 1, 0)))
        df['Indicator_golden_cross_of_Conversion_and_Baseline_'+str(20)+'D'] = ((df['ichimoku_conversion_line'].shift(1) < df['ichimoku_base_line'].shift(1)) & (df['ichimoku_conversion_line'] > df['ichimoku_base_line'])).astype(int)
        df['Count_of_golden_crosses_of_Conversion_and_Baseline_'+str(20)+'D'] = df.groupby(groupby_col)['Indicator_golden_cross_of_Conversion_and_Baseline_'+str(20)+'D'].rolling(20, min_periods=0).sum().reset_index(0, drop=True)
        return df

    #29 KAMA
    def KAMA_Features(df, **kwargs):
        '''
        A function to create Features of KAMA Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        KAMA_Fast_period : KAMA with Fast period, deafault is 14
        KAMA_Slow_period : KAMA with slow period, default is 28
        window_KAMA : Rolling window period, default window is 5

        Output:
        Dataframe with KAMA features added
        '''
        KAMA_Fast_period = kwargs.get('KAMA_Fast_period',[14])
        KAMA_Slow_period = kwargs.get('KAMA_Slow_period', [28])
        window_KAMA = kwargs.get('window_KAMA', [5])

        df['KAMA_Fast_'+str(14)+'_'+str(56)] = df.groupby(groupby_col)['close'].transform(lambda x: talib.KAMA(x.values, timeperiod=14))
        df['KAMA_Slow_'+str(56)+'_'+str(14)] = df.groupby(groupby_col)['close'].transform(lambda x: talib.KAMA(x.values, timeperiod=56))
        df['Indicator_Cross_KAMA_Fast_'+str(14)+'Slow'+str(56)] = (((df['KAMA_Fast_'+str(14)+'_'+str(56)].shift(1) < df['KAMA_Slow_'+str(56)+'_'+str(14)].shift(1)) & (df['KAMA_Fast_'+str(14)+'_'+str(56)] > df['KAMA_Slow_'+str(56)+'_'+str(14)])) | ((df['KAMA_Fast_'+str(14)+'_'+str(56)].shift(1) > df['KAMA_Slow_'+str(56)+'_'+str(14)].shift(1)) & (df['KAMA_Fast_'+str(14)+'_'+str(56)] < df['KAMA_Slow_'+str(56)+'_'+str(14)]))).astype(int)
        return df

    #30 SMA
    def SMA_Features(df,  **kwargs):
        '''
        A function to create Features of SMA Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        SMA_Fast_period : SMA with Fast period, deafault is 5
        SMA_Slow_period : SMA with slow period, default is 20
        window_SMA : Rolling window period, default window is 5

        Output:
        Dataframe with SMA features added
        '''
        SMA_Fast_period = kwargs.get('SMA_Fast_period', [5])
        SMA_Slow_period = kwargs.get('SMA_Slow_period', [20])
        window_SMA = kwargs.get('window_SMA',[5])

        for f in SMA_Fast_period:
            for s in SMA_Slow_period:
                if (f<s):
                    df['SMA_Fast_'+str(f)+'of_close_'+str(s)] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.close , timeperiod=f)).reset_index(drop=True)
                    df['SMA_Slow_'+str(s)+'of_close_'+str(f)] =df.groupby(groupby_col).apply(lambda x: talib.SMA(x.close , timeperiod=s)).reset_index(drop=True)
                    df['Indicator_for_Cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)] = (((df['SMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) < df['SMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['SMA_Fast_'+str(f)+'of_close_'+str(s)] > df['SMA_Slow_'+str(s)+'of_close_'+str(f)])) | ((df['SMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) > df['SMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['SMA_Fast_'+str(f)+'of_close_'+str(s)] < df['SMA_Slow_'+str(s)+'of_close_'+str(f)]))).astype(int)
                    df['Num_days_since_last_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)] =df.groupby(groupby_col)['Indicator_for_Cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)].apply(lambda x: (x ==0).cumsum() - ( x==0).cumsum().where(x==1).ffill().fillna(0))

                    for w in window_SMA:
                        df['Indicator_for_golden_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)+'_'+str(w)+'D'] = ((df['SMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) < df['SMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['SMA_Fast_'+str(f)+'of_close_'+str(s)] > df['SMA_Slow_'+str(s)+'of_close_'+str(f)])).astype(int)
                        df['Indicator_for_death_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)+'_'+str(w)+'D'] = ((df['SMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) > df['SMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['SMA_Fast_'+str(f)+'of_close_'+str(s)] < df['SMA_Slow_'+str(s)+'of_close_'+str(f)])).astype(int)
                        df['Count_of_golden_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)+'_'+str(w)+'D'] = df.groupby(groupby_col)['Indicator_for_golden_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)+'_'+str(w)+'D'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
                        df['Count_of_death_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)+'_'+str(w)+'D'] = df.groupby(groupby_col)['Indicator_for_death_cross_of_Fast_SMA_'+str(f)+'_Slow_SMA_'+str(s)+'_'+str(w)+'D'].rolling(w, min_periods=0).sum().reset_index(0, drop=True) 
#                 else:
#                     print('Please Check your parameter input for SMA_Fast_period and SMA_Slow_period, atlease one fast period should be less than slow period')
        return df

    #31 EMA
    def EMA_Features(df, **kwargs):
        '''
        A function to create Features of EMA Indicator

        Inputs:
        df : OHLCV data with symbols as dataframe
        EMA_Fast_period : EMA with Fast period, deafault is 5
        EMA_Slow_period : EMA with slow period, default is 20
        window_EMA : Rolling window period, default window is 5

        Output:
        Dataframe with EMA features added
        '''
        EMA_Fast_period = kwargs.get('EMA_Fast_period', [5])
        EMA_Slow_period = kwargs.get('EMA_Slow_period', [20])
        window_EMA = kwargs.get('window_EMA',[5])

        for f in EMA_Fast_period:
            for s in EMA_Slow_period:
                if (f<s):
                    df['EMA_Fast_'+str(f)+'of_close_'+str(s)] =df.groupby(groupby_col).apply(lambda x: talib.EMA(x.close , timeperiod=f)).reset_index(drop=True)
                    df['EMA_Slow_'+str(s)+'of_close_'+str(f)] =df.groupby(groupby_col).apply(lambda x: talib.EMA(x.close , timeperiod=s)).reset_index(drop=True)
                    df['Indicator_for_Cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)] = (((df['EMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) < df['EMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['EMA_Fast_'+str(f)+'of_close_'+str(s)] > df['EMA_Slow_'+str(s)+'of_close_'+str(f)])) | ((df['EMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) > df['EMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['EMA_Fast_'+str(f)+'of_close_'+str(s)] < df['EMA_Slow_'+str(s)+'of_close_'+str(f)]))).astype(int)
                    df['Num_days_since_last_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)] =df.groupby(groupby_col)['Indicator_for_Cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)].apply(lambda x: (x ==0).cumsum() - ( x==0).cumsum().where(x==1).ffill().fillna(0))

                    for w in window_EMA:
                        df['Indicator_for_golden_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)+'_'+str(w)+'D'] = ((df['EMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) < df['EMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['EMA_Fast_'+str(f)+'of_close_'+str(s)] > df['EMA_Slow_'+str(s)+'of_close_'+str(f)])).astype(int)
                        df['Indicator_for_death_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)+'_'+str(w)+'D'] = ((df['EMA_Fast_'+str(f)+'of_close_'+str(s)].shift(1) > df['EMA_Slow_'+str(s)+'of_close_'+str(f)].shift(1)) & (df['EMA_Fast_'+str(f)+'of_close_'+str(s)] < df['EMA_Slow_'+str(s)+'of_close_'+str(f)])).astype(int)
                        df['Count_of_golden_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)+'_'+str(w)+'D'] = df.groupby(groupby_col)['Indicator_for_golden_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)+'_'+str(w)+'D'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)
                        df['Count_of_death_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)+'_'+str(w)+'D'] = df.groupby(groupby_col)['Indicator_for_death_cross_of_Fast_EMA_'+str(f)+'_Slow_EMA_'+str(s)+'_'+str(w)+'D'].rolling(w, min_periods=0).sum().reset_index(0, drop=True)                                                           
#                 else:  
#                     print('Please Check your parameter input for EMA_Fast_period and EMA_Slow_period, atlease one fast period should be less than slow period')

        return df
    
    df = ADL_Features(df, window_ADL = [5,15],**kwargs)  #14 (5 +9w)
 
    df = ADX_Features(df,n_ADX = 14, window_ADX = [5], **kwargs)  #15 (8+7)
 
    df = ATR_Features(df,n_ATR = 14, window_ATR = [5], **kwargs)  #10 (3+6w)
    
    df = AROON_Features(df,n_AROON = 25, window_AROON = [5,10,15,20], **kwargs)#25 (13+12w) #not given any loop but, manually feeded
   
    df = EOM_Features(df,n_EOM = 26, window_EOM = [5,10], **kwargs)  #16 (4+12w)
    
    df = FI_Features(df,window_FI = [5,10,15,20],**kwargs)   #14 (6+8w) not gien any loop but manually feede
  
    df = KC_Features(df,n_window_kC = 20,n_kc_atr = 10, window_KC = [5], **kwargs)   #25(15+12w) 
   
    df = MACD_Features(df,MACD_Fast_period = [12,24,36,48], MACD_Slow_period = [26,52,78,104],MACD_Signal_period = 9, window_MACD = [5,15,20],**kwargs) #17 (8+9)
   
    df = Parabolic_SAR_Features(df, window_SAR = [5,10,15,20], **kwargs)#14 (9+5W)  not gien any loop but manually feeded
    
    df = PVO_Features(df,PVO_Fast_period = [12,24,36,48],PVO_Slow_period = [26,52,78,104],PVO_Signal_period = 9,window_PVO = [10,15,20], **kwargs)  #11 (6+5w)
    
    df = RSI_Features(df,n_RSI = 14, window_RSI = [5,10,15,20],**kwargs)  #5 (2+3w) not gien any loop but manually feeded
    
    df = STOCH_Features(df,window_STOCH = [5,10,15,20],**kwargs)#14 (6+8) not gien any loop but manually feeded
   
    df = VPT_Features(df,window_VPT = [5,10,15,20],**kwargs)  # 17 (9+8) not gien any loop but manually feeded
    
    df = VWAP_Features(df,window_VWAP = [5,10,15,20] ,**kwargs) #12 (6+6) not gien any loop but manually feeded
    
    df = WILLR_Features(df,window_WILLR = [5,10,15,20],**kwargs)#15 (8+7) not gien any loop but manually feeded
   
    df = CandleStick_Features(df) #4
    
    df = ROC_Features(df,n_ROC = 10,window_ROC = [5,10,15,20],SMA_period_ROC=[5,10,15,20], **kwargs) #8 not gien any loop but manually feeded
   
    df = PVI_Features(df,window_PVI = [5,20],Fast_SMA_period_PVI=9, Slow_SMA_period_PVI=26, **kwargs) #17
   
    df = NVI_Features(df,window_NVI = [10,15], SMA_period_NVI = [78,104], **kwargs) #9
   
    df = MFI_Features(df,n_MFI = 14, window_MFI = [5,10,15,20], MA_period_MFI= [10, 40, 70, 100], **kwargs) #12 not gien any loop but manually feeded

    df = Donchian_Channel_Features(df,n_DC = [10,20,30,40], window_DC = [5,10,15,20], **kwargs) #10
 
    df = BB_Features(df,n_BB = 20, window_BB = [5,10,15,20], SMA_period_BB = [5,10,15,20], **kwargs) #14 not gien any loop but manually feeded
   
    df = CMF_Features(df,n_CMF = 20, window_CMF = [5,10,15,20], EMA_period_CMF =[5,10,15,20], **kwargs) #14
 
    df = OBV_Features(df,window_OBV = [5,20], SMA_period_OBV =[40, 70, 100], **kwargs) #14

    df = UI_Features(df,n_UI = 14, window_UI = [10,15,20], SMA_period_UI =[14,28,42,56], **kwargs) #9
  
    df = CCI_Features(df,n_CCI = 20, window_CCI = [5,10,15,20], SMA_period_CCI = [5,10,15,20], **kwargs) #9 not gien any loop
    
    df = Ichimoku_Features(df,window_Ichimoku = [5,10,15,20], **kwargs) #19 not gien any loop but manually feeded
   
    df = KAMA_Features(df,KAMA_Fast_period = [14, 28, 42, 56], KAMA_Slow_period= [28,56,84,112], window_KAMA = [5,10,15,20], **kwargs) #15 not gien any loop but manually feeded
  
    df = SMA_Features(df,SMA_Fast_period = [5,10,15,20], SMA_Slow_period = [10, 20 ,40 ,80], window_SMA = [10,15,20], **kwargs) #22
  
    df = EMA_Features(df, EMA_Fast_period = [5,10,15,20], EMA_Slow_period = [10,20 ,40, 80], window_EMA = [15,20], **kwargs) #22
        
    df.rename(columns = {'co_code':'nse_symbol'}, inplace = True)
   
    #Keep Significant Features
    Imp_Features = ['Indicator_ADL_15_Slope', 'Indicator_Slope15_ADL', 'No_ADL_gt0_5D', 'No_ADL_lt0_5D', 'ADX_gt_20_5D', 'ADX_gt_25_5D', 'ADX_Indicator', 'No_of_times_DI_cross_5D', 'plusDI_cross_from_above', 'plusDI_cross_from_above_5D', 'plusDI_cross_from_below_5D', 'SMA_ADX_5D', 'UorD_25', '20D_Slope_Aroon_down', '5D_Slope_Aroon_up', 'Aroon_No_cross_Up_gt0_in_10D', 'Aroon_No_cross_Up_lt_in_20D', 'Aroon_Up_lt70_Down_gt30', 'pct_DaysAroon_U_gt_50_20D', 'ATR', 'ATR_SMA5D', 'Indi_ATR_gtAV_ATR_5D', 'Indicator_ATR', 'No_Indicator_ATR_EQ-1_inLast_5D', 'No_Indicator_ATR_EQ1_inLast_5D', 'compare_close_and_LowerBB', 'compare_close_and_UpperBB', 'diff_UpperBB_and_LowerBB', 'SMA_LowerBB_5', 'SMA_UpperBB_5', 'Std_Dev_LowerBB_5D', 'Std_Dev_UpperBB_5D', 'Doji', 'cci_Thresholds_Indicator', 'diff_Upper_Donchian_Lower_Donchian10', 'diff_Upper_Donchian_Lower_Donchian20', 'diff_Upper_Donchian_Lower_Donchian30', 'diff_Upper_Donchian_Lower_Donchian40', 'Lower_Donchian_10_Std_Dev_10D', 'Lower_Donchian_20_Std_Dev_15D', 'Lower_Donchian_30_Std_Dev_5D', 'Lower_Donchian_40_Std_Dev_20D', 'Upper_Donchian_10_Std_Dev_10D', 'Upper_Donchian_20_Std_Dev_5D', 'Count_of_death_cross_of_Fast_EMA_10_Slow_EMA_20_15D', 'Count_of_death_cross_of_Fast_EMA_10_Slow_EMA_40_15D', 'Count_of_death_cross_of_Fast_EMA_15_Slow_EMA_20_15D', 'Count_of_death_cross_of_Fast_EMA_15_Slow_EMA_40_20D', 'Count_of_death_cross_of_Fast_EMA_5_Slow_EMA_20_20D', 'Count_of_death_cross_of_Fast_EMA_5_Slow_EMA_40_20D', 'Count_of_golden_cross_of_Fast_EMA_20_Slow_EMA_80_20D', 'Num_days_since_last_cross_of_Fast_EMA_10_Slow_EMA_20', 'Num_days_since_last_cross_of_Fast_EMA_10_Slow_EMA_40', 'Num_days_since_last_cross_of_Fast_EMA_10_Slow_EMA_80', 'Num_days_since_last_cross_of_Fast_EMA_15_Slow_EMA_20', 'Num_days_since_last_cross_of_Fast_EMA_15_Slow_EMA_40', 'Num_days_since_last_cross_of_Fast_EMA_15_Slow_EMA_80', 'Num_days_since_last_cross_of_Fast_EMA_20_Slow_EMA_40', 'Num_days_since_last_cross_of_Fast_EMA_20_Slow_EMA_80', 'Num_days_since_last_cross_of_Fast_EMA_5_Slow_EMA_40', 'Num_days_since_last_cross_of_Fast_EMA_5_Slow_EMA_80', 'Indi_EOM_lt_crossover', 'Indicator_EOM_10Slope', 'No_EOM_gt_2_5D', 'No_Days_since_last_cross_Force', 'compare_Conversion_Baseline_Ichimoku', 'Count_of_golden_crosses_of_Conversion_and_Baseline_20D', 'Indicator_Cross_KAMA_Fast_14Slow56', 'Dist_Keltner_u&l', 'Distance_close_low_Keltner', 'Indi_keltnerL_gt_crossover', 'Indi_keltnerL_lt_crossover', 'keltner_channel_wband', 'keltner_hband', 'keltner_lband', 'keltner_mband', 'KeltnerL_MA_5D', 'KeltnerU_MA_5D', 'No_keltnerL_lt_crossover_inLast_5D', 'vol_Lkeltner_5D', 'vol_Ukeltner_5D', 'Indi_MACD_12f_104s_gt_signal', 'Indicator_MACD_36f_104s_gt_Signal', 'Indicator_MACD_48f_104s_gt_Signal', 'Indicator_MACD_48f_78s_gt_Signal', 'MACD_12f_104s_GT_0_15D', 'MACD_12f_104s_LT_0_15D', 'MACD_24f_104s_GT_0_5D', 'MACD_24f_104s_LT_0_5D', 'MACD_24f_78s_GT_0_20D', 'MACD_24f_78s_LT_0_20D', 'MACD_36f_104s_GT_0_5D', 'MACD_36f_104s_LT_0_5D', 'MACD_36f_78s_GT_0_5D', 'MACD_36f_78s_LT_0_5D', 'MACD_48f_104s_GT_0_5D', 'MACD_48f_104s_LT_0_5D', 'MACD_48f_52s_GT_0_15D', 'MACD_48f_52s_LT_0_15D', 'MACD_48f_78s_GT_0_5D', 'MACD_48f_78s_LT_0_5D', 'No_Days_since_last cross_MACD_36f_104s', 'No_MACD_24f_104s_lt_signal_20D', 'No_MACD_24f_52s_lt_signal_20D', 'No_MACD_24f_78s_lt_signal_20D', 'No_MACD_36f_104s_lt_signal_20D', 'No_MACD_36f_78s_lt_signal_20D', 'No_MACD_48f_104s_lt_signal_20D', 'No_MACD_48f_52s_lt_signal_20D', 'No_MACD_48f_78s_lt_signal_20D', 'vol_MACD_12f_104s_in_5D', 'vol_MACD_12f_26s_in_5D', 'vol_MACD_12f_52s_in_5D', 'vol_MACD_12f_78s_in_5D', 'vol_MACD_24f_104s_in_5D', 'vol_MACD_24f_26s_in_5D', 'vol_MACD_24f_52s_in_5D', 'vol_MACD_24f_78s_in_5D', 'vol_MACD_36f_104s_in_5D', 'vol_MACD_36f_52s_in_5D', 'vol_MACD_36f_78s_in_5D', 'vol_MACD_48f_104s_in_5D', 'vol_MACD_48f_52s_in_5D', 'vol_MACD_48f_78s_in_5D', 'Count_MFI_gt_80_in_last_15D', 'Slope_MFI_5', 'SMA_MFI_20', 'Count_NVI_gt_SMA_of_NVI_104_in_last_15D', 'Count_NVI_gt_SMA_of_NVI_78_in_last_10D', 'Count_NVI_lt_SMA_of_NVI_104_in_last_15D', 'Count_NVI_lt_SMA_of_NVI_78_in_last_10D', 'Slope_of_SMA_of_nvi_78in_last10D', 'Count_of_golden_crosses_OBV_and_SMA_of_OBV_100_in_20D', 'Count_of_golden_crosses_OBV_and_SMA_of_OBV_70_in_20D', 'Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_100', 'Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_40', 'Num_days_since_last_cross_of_OBV_and_SMA_of_OBV_70', 'OBV_Std_Dev_5D', 'Indicator_SAR', 'Indicator_SAR1', 'No_Parabolic_SAR_cross_inLast_20D', 'Parabolic_SAR', 'Parabolic_SAR_No_cross_gt_inLast_10D', 'Parabolic_SAR_No_cross_lt_inLast_20D', 'Parabolic_SAR_SMA_5D', 'Fast_SMA_of_PVI', 'pvi', 'PVI_Max_in_last_5D', 'PVI_Min_in_last_5D', 'Slope_of_Fast_SMA_of_PVI20D', 'Slope_of_Slow_SMA_of_PVI20D', 'Slow_SMA_of_PVI', '10D_Slope_PVO_12f_26s', 'Indicator_PVO_12f_104s', 'Indicator_PVO_12f_26s', 'Indicator_PVO_12f_52s', 'Indicator_PVO_12f_78s', 'Indicator_PVO_24f_104s', 'Indicator_PVO_24f_26s', 'Indicator_PVO_24f_52s', 'Indicator_PVO_24f_78s', 'Indicator_PVO_36f_104s', 'Indicator_PVO_36f_52s', 'Indicator_PVO_36f_78s', 'Indicator_PVO_48f_104s', 'Indicator_PVO_48f_52s', 'Indicator_PVO_48f_78s', 'No_PVO_36f_104s_gt0_5D', 'No_PVO_36f_104s_Lt0_5D', 'No_PVO_48f_104s_gt0_5D', 'No_PVO_48f_104s_Lt0_5D', 'No_PVO_48f_78s_gt0_5D', 'No_PVO_48f_78s_Lt0_5D', 'No_times_PVO_24f_52s_gt_crossover_inLast_15D', 'No_times_PVO_24f_78s_gt_crossover_inLast_20D', 'No_times_PVO_36f_52s_lt_crossover_inLast_10D', 'No_times_PVO_48f_104s_lt_crossover_inLast_10D', 'No_times_PVO_48f_52s_lt_crossover_inLast_10D', 'No_times_PVO_48f_78s_lt_crossover_inLast_10D', 'PVO_12f_104s_hist', 'PVO_12f_26s_hist', 'PVO_12f_52s_hist', 'PVO_12f_78s_hist', 'PVO_24f_104s_hist', 'PVO_24f_26s_hist', 'PVO_24f_52s_hist', 'PVO_24f_78s_hist', 'PVO_36f_104s_hist', 'PVO_36f_52s_hist', 'PVO_36f_78s_hist', 'PVO_48f_104s_hist', 'PVO_48f_52s_hist', 'PVO_48f_78s_hist', 'ROC_Thresholds', 'Slope_ROC15', 'No_RSI_lt30_inLast_5D', 'Count_of_death_cross_of_Fast_SMA_10_Slow_SMA_20_20D', 'Count_of_death_cross_of_Fast_SMA_10_Slow_SMA_40_15D', 'Count_of_death_cross_of_Fast_SMA_15_Slow_SMA_20_15D', 'Count_of_death_cross_of_Fast_SMA_15_Slow_SMA_40_15D', 'Count_of_death_cross_of_Fast_SMA_20_Slow_SMA_40_10D', 'Count_of_death_cross_of_Fast_SMA_5_Slow_SMA_20_20D', 'Count_of_death_cross_of_Fast_SMA_5_Slow_SMA_40_20D', 'Count_of_golden_cross_of_Fast_SMA_15_Slow_SMA_20_15D', 'Num_days_since_last_cross_of_Fast_SMA_10_Slow_SMA_40', 'Num_days_since_last_cross_of_Fast_SMA_10_Slow_SMA_80', 'Num_days_since_last_cross_of_Fast_SMA_15_Slow_SMA_40', 'Num_days_since_last_cross_of_Fast_SMA_15_Slow_SMA_80', 'Num_days_since_last_cross_of_Fast_SMA_20_Slow_SMA_40', 'Num_days_since_last_cross_of_Fast_SMA_20_Slow_SMA_80', 'Num_days_since_last_cross_of_Fast_SMA_5_Slow_SMA_40', 'Num_days_since_last_cross_of_Fast_SMA_5_Slow_SMA_80', '15D_Slope_Stochd', 'Indicator_STOCH_15D', 'No_golden_cross_stochastic_in_20D', 'No_times_stochk_lt20_20D', 'Count_Slope_of_UI_gt_0_in_last_10D', 'Count_Slope_of_UI_lt_0_in_last_10D', 'Count_UI_gt_UI_SMA_14_in_last_10D', 'Count_UI_gt_UI_SMA_42_in_last_20D', 'Count_UI_gt_UI_SMA_56_in_last_15D', 'Count_UI_lt_UI_SMA_14_in_last_10D', 'Count_UI_lt_UI_SMA_42_in_last_20D', 'Count_UI_lt_UI_SMA_56_in_last_15D', 'Slope_UI15', 'SMA_of_UI_14', 'SMA_of_UI_28', 'SMA_of_UI_42', 'SMA_of_UI_56', 'UI_Max_5D', 'UI_Min_5D', 'ulcer_index', 'ADX_gt25_vpt_gt_Signal', 'ADX_lt25_vpt_lt_Signal', 'Indi_VPT_gt_crossover', 'VWAP', 'No_of_times_WILLR_gt_crossover_in_15D','EMA_close_for_CMF_5']
    keep_cols = ['date', 'nse_symbol','close','open','high','low','volume']  + Imp_Features
    df = df.loc[:, keep_cols]
    
    df.dropna(inplace=True)
    df['date'] = df['date'].astype(str)

    # Extract the unique dates from the 'date' column of the DataFrame
    date_list = df['date'].unique().tolist()
    
    # Sort the date list in ascending order
    date_list.sort()
    
    # Select the last five dates
    last_five_dates = date_list[-5:]
    print(last_five_dates)
    
    # Create the final DataFrame with data for the last five dates
    final_df = df[df['date'].isin(last_five_dates)]
    final_df['date'] = pd.to_datetime(final_df['date'])
    print(final_df['date'].nunique())
    grouped_by_date = final_df.groupby('date')
    
    # Iterate over each group
    for date, group in grouped_by_date:
        
        # Format the date as a string
        date = date 
        formatted_date = date.strftime('%Y-%m-%d')
        
        # Define the output file name
        destination_path = "s3://sg-ds-project/stock-prediction-poc/feature-data/"
        
        # Save the group as a Parquet file
        file_name =  f"{formatted_date}.parquet" 
        print('check_files',file_name)     
        wr.s3.to_parquet(group, destination_path + file_name , index=False, boto3_session = boto3_session)

    return df 

import time
start_time = time.time()
feature_data = Technical_Indicator_features()

print("Execution time:", time.time() - start_time, "seconds")

