import pandas as pd
import numpy as np
import sys
import os
import io
from io import StringIO, BytesIO
from datetime import datetime
from pytz import timezone
import time
from copy import deepcopy
import glob
import xlsxwriter

import xgboost as xgb
import pickle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.model_selection import GridSearchCV,RandomizedSearchCV,StratifiedKFold
from skopt import BayesSearchCV
from sklearn.metrics import classification_report

import awswrangler as wr
import boto3

import json
import logging as logger

import seaborn as sns
from matplotlib import pyplot as plt

import warnings 
warnings.filterwarnings('ignore')

from logger import Logger
logger = Logger()

pd.set_option('display.max_columns',None)
pd.set_option('display.max_rows',None)

logger.debug("version-3")

## function to read the passed json object as dictionary
def get_dict():
    temp = sys.argv[1]
    with open(temp, "r") as json_file:
        dictt = json.load(json_file)
    logger.debug("dictionary loaded")
    return dictt

def decile_table_plots(dict1,dir_name,df,target_col,pred_probabilties,name, save = 'yes'):
    '''
        Info : creates deciles table, roc curve and lift curve
        
        Args = 
        dict1             : the dictionary which is passed as json object
        dir_name          : the dir_name where the files will be saved
        df                : the dataframe on which you want to calculate the deciles
        target_col        : the target column in the dataframe
        pred_probabilties : the predicted probabilities column name in the dataframe
        name              : str value to save the files generated
    '''

    if dict1['write_to'] == 's3':
        s31 = boto3.resource('s3')
        bucket = s31.Bucket(dict1['bucket_name'])

    op_df = deepcopy(df)
    start_range = 0
    op_df = op_df.sort_values([pred_probabilties],ascending=False)
    ten_per = np.ceil(0.1 * op_df.shape[0])
    decile_df = pd.DataFrame()
    decile_df["decile"] = np.arange(1, 11)
    decile_df["decile"] = "decile_"+ decile_df["decile"].astype(str)
    mean_list = []
    min_list = []
    max_list = []
    number_frauds_list = []
    number_rows_list = []
    op_df["decile_label"] = ""
    op_df= op_df.reset_index(drop=True)

    for count in range(0,10):

        end_range = int(((count + 1) * ten_per)-1)
        op_df.loc[start_range:end_range, "decile_label"] = "decile_" + str(count + 1)
        mean_decile = op_df.loc[start_range:end_range, pred_probabilties].mean()
        min_decile =  op_df.loc[start_range:end_range, pred_probabilties].min()
        max_decile =  op_df.loc[start_range:end_range, pred_probabilties].max()
        
        total = len(op_df.loc[start_range:end_range, pred_probabilties])
        number_frauds = op_df.loc[start_range:end_range, target_col].sum()
        start_range = end_range + 1

        mean_list.append(mean_decile)
        min_list.append(min_decile)
        max_list.append(max_decile)
        number_frauds_list.append(number_frauds)
        number_rows_list.append(total)


    decile_df["mean_prob"] = mean_list
    decile_df["min_prob"] = min_list
    decile_df['max_prob'] = max_list
    decile_df["number_events"] = number_frauds_list
    decile_df["total"] = number_rows_list
    decile_df['number_non_events'] = decile_df['total'] - decile_df['number_events']

    decile_df = decile_df[['decile','mean_prob','min_prob','max_prob','number_events','number_non_events','total']]
    decile_df = decile_df.round(2)

    if save == 'yes':
        op_df = op_df[[dict1["aggr_attr"], target_col , pred_probabilties, "decile_label"]].round(2)
        if dict1['write_to'] == 's3':
            op_df.to_csv(f"s3://"+dict1['bucket_name']+"/"+dir_name+'/'+name+'_predprob_decile_df.csv',index=False)
        elif dict1['write_to'] == 'local':
            op_df.to_csv(dir_name + '/'+name+'_predprob_decile_df.csv',index=False)

    decile_df['cum_event'] = decile_df['number_events'].cumsum()
    decile_df['cum_non_event'] = decile_df['number_non_events'].cumsum()
    decile_df['cum_total'] = decile_df['total'].cumsum()
    decile_df['%cum_total'] = (decile_df['cum_total']/sum(decile_df['total'])*100).round(0)
    decile_df['%cum_event'] = (decile_df['cum_event']/sum(decile_df['number_events'])*100).round(2)
    decile_df['%cum_non_event'] = (decile_df['cum_non_event']/sum(decile_df['number_non_events'])*100).round(2)
    decile_df['actual_event_rate'] = round((sum(decile_df['number_events'])/sum(decile_df['total'])*100),2)
    decile_df['response_rate_decilewise'] = round((decile_df['number_events']/decile_df['total']*100),2)
    decile_df['Lift'] = (decile_df['%cum_event']/decile_df['%cum_total']).round(2)
    decile_df['KS'] = decile_df['%cum_event']-decile_df['%cum_non_event']
    decile_df['TP'] = decile_df['cum_event']
    decile_df['TN'] = sum(decile_df['number_non_events'])-decile_df['cum_non_event']
    decile_df['FP'] = decile_df['cum_non_event']
    decile_df['FN'] = sum(decile_df['number_events']) - decile_df['cum_event']
    decile_df['Sensitivity'] = ((decile_df['TP']/(decile_df['TP']+decile_df['FN']))*100).round(0)
    decile_df['Specificity'] = ((decile_df['TN']/(decile_df['TN']+decile_df['FP']))*100).round(0)
    decile_df['Accuracy'] = ((decile_df['TP']+decile_df['TN'])/sum(decile_df['total'])*100).round(0)
    decile_df['1-Specificity'] = 100-decile_df['Specificity']
    decile_df['dataset'] = name
    
    decile_df = decile_df[['dataset','decile', 'mean_prob', 'min_prob', 'max_prob', 'number_events',
                            'number_non_events', 'total', 'actual_event_rate','response_rate_decilewise',
                            'cum_event', 'cum_non_event', 'cum_total',
                            '%cum_total', '%cum_event', '%cum_non_event', 
                            'Lift', 'KS', 'TP', 'TN', 'FP', 'FN',
                            'Sensitivity', 'Specificity', 'Accuracy', '1-Specificity']]
    if save == 'yes':
        if dict1['write_to'] == 's3':
            decile_df.to_csv(f"s3://"+dict1['bucket_name']+"/"+dir_name+'/'+name+'_decile_table.csv',index=False)
        elif dict1['write_to'] =='local':
            decile_df.to_csv(dir_name + '/'+name+'_decile_table.csv',index=False)
        
#--------------------------------------ROC-Curve------------------------------------------------------------------

    roc_curve = sns.lineplot(data=decile_df, x="1-Specificity", y="Sensitivity", sort=False,marker="o")
    roc_curve.set_title(name+" Roc Curve")
    roc_curve.set_ylabel("(True Positive Rate) Sensitivity")
    roc_curve.set_xlabel("(False Positive Rate) 1-Specificity")
    ax = roc_curve.get_figure()
    if save == 'yes':
        if dict1['write_to'] == 'local':
            ax.savefig(dir_name +'/'+name+'_roc_curve.jpg',bbox_inches="tight",format="jpg")
        elif dict1['write_to'] == 's3':
            plt.tight_layout()  
            ax = io.BytesIO()
            plt.savefig(ax, format='png')
            ax.seek(0)
            bucket.put_object(Body=ax, ContentType='image/png',Key= (dir_name+'/'+name+'_roc_curve.png'))
            
#--------------------------------------Lift-Curve-----------------------------------------------------------------

    lift_curve = sns.lineplot(data=decile_df, x="%cum_total", y="Lift", sort=False,marker="o")
    lift_curve.set_title(name+" Lift Curve")
    lift_curve.set_ylabel("Lift")
    lift_curve.set_xlabel("Percentage of records")
    ax1 = lift_curve.get_figure()
    if save == 'yes':
        if dict1['write_to'] == 'local':
            ax1.savefig(dir_name+'/'+name+'_lift_curve.jpg',bbox_inches="tight",format="jpg")
        elif dict1['write_to'] == 's3':
            plt.tight_layout()
            ax1 = io.BytesIO()
            plt.savefig(ax1, format='png')
            ax1.seek(0)
            bucket.put_object(Body=ax1, ContentType='image/png',Key= (dir_name+'/'+name+'_lift_curve.png'))

    return decile_df

def read_files_from_s3(dict1):
    '''
    Info : reads the data files from given s3 location

    Args = 
    dict1 : the dictionary passed as json object

    Returns = 
    returns training, validation, testing dataframes along with directory name where the output files will be saved
    '''

    logger.debug("reading files..")

    if dict1['ext'] == 'csv':
        train_df = wr.s3.read_csv(dict1['train_path'])
        validation_df = wr.s3.read_csv(dict1['val_path'])
        test_df = []
        for i in dict1['test_path'].keys():
            test_file = wr.s3.read_csv(dict1['test_path'][i])
            test_df.append(test_file)

    elif dict1['ext'] =='parquet':
        train_df = wr.s3.read_parquet(dict1['train_path'])
        validation_df = wr.s3.read_parquet(dict1['val_path'])
        test_df = []
        for i in dict1['test_path'].keys():
            test_file = wr.s3.read_parquet(dict1['test_path'][i])
            test_df.append(test_file)
    
    logger.debug("files read complete")

    if dict1['write_to'] == 'local':
        dir_name = dict1['directory_name'] + dict1['itr']
        dir_train = dict1['directory_name'] + dict1['itr'] + '/train'
        dir_val = dict1['directory_name'] + dict1['itr'] + '/validation'
        dir_test = []
        for i in dict1['test_path'].keys():
            dir_test_file = dict1['directory_name'] + dict1['itr'] + '/' + i
            dir_test.append(dir_test_file)
            if not os.path.exists(dir_test_file):
                os.makedirs(dir_test_file)
        
        for i in [dir_name, dir_train, dir_val] :
            if not os.path.exists(i):
                os.makedirs(i)

    elif dict1['write_to'] == 's3':
        s3 = boto3.client('s3')

        dir_name = dict1['directory_name'] + dict1['itr']
        s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_name+'/'))
        dir_train = dict1['directory_name'] + dict1['itr'] + '/train'
        s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_train+'/'))
        dir_val = dict1['directory_name'] + dict1['itr'] + '/validation'
        s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_val+'/'))
        dir_test = []
        for i in dict1['test_path'].keys():
            dir_test_file = dict1['directory_name'] + dict1['itr'] + '/' + i
            dir_test.append(dir_test_file)
            s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_test_file+'/'))
        
    return train_df, validation_df, test_df, dir_name, dir_train, dir_val, dir_test

def read_files_from_local(dict1):
    '''
    Info : reads the data files from given file location

    Args = 
    dict1 : the dictioanry passed as json object
    
    Returns = 
    returns training, validation, testing dataframes and a directory name where the output files will be saved
    '''

    logger.debug("reading files..")

    if dict1['ext'] == 'csv':
        train_df = pd.read_csv(dict1['train_path'])
        validation_df = pd.read_csv(dict1['val_path'])
        test_df = []
        for i in dict1['test_path'].keys():
            test_file = pd.read_csv(dict1['test_path'][i])
            test_df.append(test_file)

    elif dict1['ext'] =='parquet':
        train_df = pd.read_parquet(dict1['train_path'])
        validation_df = pd.read_parquet(dict1['val_path'])
        test_df = []
        for i in dict1['test_path'].keys():
            test_file = pd.read_parquet(dict1['test_path'][i])
            test_df.append(test_file)
    
    logger.debug("files read complete")

    if dict1['write_to'] == 'local':
        dir_name = dict1['directory_name'] + dict1['itr']
        dir_train = dict1['directory_name'] + dict1['itr'] + '/train'
        dir_val = dict1['directory_name'] + dict1['itr'] + '/validation'
        dir_test = []
        for i in dict1['test_path'].keys():
            dir_test_file = dict1['directory_name'] + dict1['itr'] + '/' + i
            dir_test.append(dir_test_file)
            if not os.path.exists(dir_test_file):
                os.makedirs(dir_test_file)
        
        for i in [dir_name, dir_train, dir_val] :
            if not os.path.exists(i):
                os.makedirs(i)

    elif dict1['write_to'] == 's3':
        s3 = boto3.client('s3')

        dir_name = dict1['directory_name'] + dict1['itr']
        s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_name+'/'))
        dir_train = dict1['directory_name'] + dict1['itr'] + '/train'
        s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_train+'/'))
        dir_val = dict1['directory_name'] + dict1['itr'] + '/validation'
        s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_val+'/'))
        dir_test = []
        for i in dict1['test_path'].keys():
            dir_test_file = dict1['directory_name'] + dict1['itr'] + '/' + i
            dir_test.append(dir_test_file)
            s3.put_object(Bucket=dict1['bucket_name'], Key=(dir_test_file+'/'))
        
    return train_df, validation_df, test_df, dir_name, dir_train, dir_val, dir_test

def get_data(dict1):
    '''
    Info : reads the file from s3 or local directory as per the passed argument

    Args = 
    dict1 : the dictioinary passed as json object

    Returns = 
    returns training, validation, testing dataframes and a directory name where the output files will be saved
    '''

    if not ((dict1['ext']=='csv') | (dict1['ext']=='parquet')):
        logger.debug("Please specify correct extension for files")
        sys.exit(-1)
    
    if dict1['read_from'] == 's3':
        train_df, validation_df, test_df, dir_name, dir_train, dir_val, dir_test = read_files_from_s3(dict1)

    elif dict1['read_from'] =='local':
        train_df, validation_df, test_df, dir_name, dir_train, dir_val, dir_test = read_files_from_local(dict1)

    return train_df, validation_df, test_df, dir_name, dir_train, dir_val, dir_test

def bayesian_tuning(dict1, df):
    '''
    Info : applies bayesian search based on the parameters passed in dictionary

    Args = 
    dict1 : the dictioanry passed as json object
    df    : the dataframe on which you want to do bayesian search (generally done on training dataframe)

    Returns =
    returns a dictionary with the best estimator from the search
    '''

    logger.debug("Bayesian Search hyperparameter tuning started")
    logger.debug("bayesian search start time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))
    
    X = df[dict1['feature_list']]
    y = df[dict1['target_col']].values
    
    xgb_clf = xgb.XGBClassifier(objective='binary:logistic')
    skf = StratifiedKFold(**dict1['hyperparameter_tuning']['StratifiedKFold_params'])
    
    bayesian_search = BayesSearchCV(estimator = xgb_clf,
                                    cv = skf.split(X,y), 
                                    search_spaces = dict1['hyperparameter_tuning']['params'],
                                    **dict1['hyperparameter_tuning']['bayesian_params'])
    
    bayesian_search_fit = bayesian_search.fit(X, y)
    best_estimator = bayesian_search_fit.best_estimator_.get_params()

    logger.debug("bayesian search end time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))

    return best_estimator

def random_tuning(dict1, df):
    '''
    Info : applies random search based on the parameters passed in dictionary

    Args = 
    dict1 : the dictioanry passed as json object
    df    : the dataframe on which you want to do random search (generally done on training dataframe)

    Returns =
    returns a dictionary with the best estimator from the search
    '''

    logger.debug("Random Search hyperparameter tuning started")
    logger.debug("random search start time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))
    
    X = df[dict1['feature_list']]
    y = df[dict1['target_col']].values
    
    xgb_clf = xgb.XGBClassifier(objective='binary:logistic')
    skf = StratifiedKFold(**dict1['hyperparameter_tuning']['StratifiedKFold_params'])
    
    random_search = RandomizedSearchCV(estimator = xgb_clf,
                                       param_distributions = dict1['hyperparameter_tuning']['params'], 
                                       cv = skf.split(X,y), 
                                       **dict1['hyperparameter_tuning']['random_params'])

    random_search_fit = random_search.fit(X, y)
    best_estimator = random_search_fit.best_estimator_.get_params()

    logger.debug("random search end time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))

    return best_estimator

def grid_tuning(dict1, df):
    '''
    Info : applies grid search based on the parameters passed in dictionary

    Args = 
    dict1 : the dictioanry passed as json object
    df    : the dataframe on which you want to do grid search (generally done on training dataframe)

    Returns =
    returns a dictionary with the best estimator from the search
    '''

    logger.debug("Grid Search hyperparameter tuning started")
    logger.debug("Grid search start time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))
    
    X = df[dict1['feature_list']]
    y = df[dict1['target_col']].values
    
    xgb_clf = xgb.XGBClassifier(objective='binary:logistic')
    skf = StratifiedKFold(**dict1['hyperparameter_tuning']['StratifiedKFold_params'])

    grid_search = GridSearchCV(estimator = xgb_clf,
                               param_grid = dict1['hyperparameter_tuning']['params'], 
                               cv = skf.split(X,y), 
                               **dict1['hyperparameter_tuning']['grid_params'])
    
    grid_search_fit = grid_search.fit(X, y)
    best_estimator = grid_search_fit.best_estimator_.get_params()
    
    logger.debug("grid search end time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))

    return best_estimator

def hyper_parameter_tuning(dict1, df):
    '''
    Info : carries out hyper-parameter tuning based on the argument passed in the dictionary

    Args = 
    dict1 : the dictioanry passed as json object
    df    : the dataframe on which you want to do grid search (generally done on training dataframe)

    Returns =
    returns a dictionary with the best estimator from the search
    '''

    if dict1['hyperparameter_tuning']['method'] == '':
        logger.debug("no hyperparameter tuning")
        best_estimator = {}
    
    elif dict1['hyperparameter_tuning']['method'] == 'bayesian':
        best_estimator = bayesian_tuning(dict1, df)
        
    elif dict1['hyperparameter_tuning']['method'] == 'random':
        best_estimator = random_tuning(dict1, df)
        
    elif dict1['hyperparameter_tuning']['method'] == 'grid':
        best_estimator = grid_tuning(dict1, df)
    
    ## the best_estimator gives a key "missing" with value nan, and is not used in xgb model building, hence deleting it
    # removing 'missing' key from best_estimator dict
    if dict1['hyperparameter_tuning']['method'] != '':
        del best_estimator['missing']

    return best_estimator

def calculate_vif(dict1, df, dir_name, file_type, file_name = ''):
    '''
    Info : calculates the variance inflation factor for each feature passed

    Args = 
    dict1     : the dictioanry passed as json object
    df        : the dataframe for which vif will be calculated (generally done on training dataframe)
    dir_name  : the directory name where the output files will be saved
    file_type : the type of file to be saved
    file_name : the name of the file to be saved as
    '''

    logger.debug("vif started")
    t_vif = pd.DataFrame()
    t_vif["VIF Factor"] = [variance_inflation_factor(df[dict1['feature_list']].values, i) 
                           for i in range(df[dict1['feature_list']].shape[1])]
    t_vif["features"] = dict1['feature_list']
    t_vif.sort_values(["VIF Factor"], ascending=False, inplace=True)
    t_vif.reset_index(drop=True,inplace=True)
    
    save_files(dict1, t_vif, dir_name, 'csv', 'vif')

    logger.debug("vif done")

def save_files(dict1, df, dir_name, file_type, file_name = ''):
    '''
    Info : saves the file generated in the given location

    Args = 
    dict1     : the dictioanry passed as json object
    df        : the dataframe which is to be saved
    dir_name  : the directory name where the output files will be saved
    file_type : the type of file to be saved
    file_name : the name of the file to be saved as 
    '''

    if file_type == 'csv':
        if dict1['write_to'] == 's3':
            df.round(2).to_csv("s3://" + dict1['bucket_name'] + "/" + dir_name + '/' + str(file_name) + '.csv',index=False)
        elif dict1['write_to'] == 'local':
            df.round(2).to_csv(dir_name + '/' + str(file_name) + '.csv',index=False)

    elif file_type == 'xlsx':
        if dict1['write_to'] == 's3':
            df.round(2).to_excel("s3://" + dict1['bucket_name'] + "/" + dir_name + '/' + str(file_name) + '.xlsx',index=False)
        elif dict1['write_to'] == 'local':
            df.round(2).to_excel(dir_name + '/' + str(file_name) + '.xlsx',index=False)

    elif file_type == 'parquet':
        if dict1['write_to'] == 's3':
            df.round(2).to_parquet("s3://" + dict1['bucket_name'] + "/" + dir_name + '/' + str(file_name) + '.parquet')
        elif dict1['write_to'] == 'local':
            df.round(2).to_parquet(dir_name + '/' + str(file_name) + '.parquet')

    elif file_type == 'pkl':
        if dict1['write_to'] == 's3':
            key = dir_name + "/xgb_" + dict1['itr'] + ".pkl"
            pickle_byte_obj = pickle.dumps(df) 
            s3_resource = boto3.resource('s3')
            s3_resource.Object(dict1['bucket_name'],key).put(Body=pickle_byte_obj)
        elif dict1['write_to'] == 'local':
            pickle.dump(df, open(dir_name + "/xgb_" + dict1['itr'] + ".pkl", 'wb'))   


def predictions(dict1, df, model_object, dataset = '', print_log = 'yes'):
    '''
    Info : gives the predictions on the passed dataframe

    Args = 
    dict1 : the dictioanry passed as json object
    df    : the dataframe on which the predictions are required
    model_object : the xgb model object 
    dataset : the name of the dataset on which the predictions are required
    print_log = print the statement for predictions (by default = 'yes')

    Returns:
    returns the subset of dataframe with aggr_attr, actual target, model predictions and set of features
    '''
    if print_log == 'yes':
        logger.debug("Started - Predicting on {} data".format(dataset))
    preds = model_object.predict(df[dict1['feature_list']])

    pred_prob = model_object.predict_proba(df[dict1['feature_list']])

    prob_name_list = ["pred_prob_"+str(model_object.classes_[0]), "pred_prob_" + str(model_object.classes_[1])]

    df["pred_prob_"+str(model_object.classes_[0])] = pred_prob[:,0]
    df["pred_prob_" + str(model_object.classes_[1])] = pred_prob[:, 1]

    df["y_pred"] = preds

    df = df[[dict1['aggr_attr'],  dict1['target_col']] + ["y_pred"] + prob_name_list]

    if print_log == 'yes':
        logger.debug("Completed - Predicting on {} data".format(dataset))

    # Generate classification report for predicted labels
    y_ = df[dict1['target_col']].values
    report = classification_report(y_ , preds)

    data = StringIO(report)
    class_df = pd.read_csv(data, sep=r'\s{2,}', engine='python').reset_index()

    accuracy_precision = class_df.loc[class_df['index'] == 'accuracy', 'precision'].values[0]
    accuracy_recall = class_df.loc[class_df['index'] == 'accuracy', 'recall'].values[0]
    # Update the f1-score and support columns in the accuracy row with the retrieved values
    class_df.loc[class_df['index'] == 'accuracy', 'f1-score'] = accuracy_precision
    class_df.loc[class_df['index'] == 'accuracy', 'support'] = accuracy_recall
    class_df.loc[class_df['index'] == 'accuracy', 'precision'] = np.nan
    class_df.loc[class_df['index'] == 'accuracy', 'recall'] = np.nan

    return df, class_df

def combine_decile_tables(dict1, dir_name, ext='csv', file_name='', all_itr='No'):
    '''
    Info : combines the decile tables for train, validation, test datasets and saves it
           also, combines all the decile tables for all iterations and saves it

    Args = 
    dict1     : the dictionary passed as json object
    dir_name  : the directory where the file will be saved
    ext       : type of file to be saved
    file_name : the name of the file to be saved as
    all_itr   : parameter if all deciles tables to be saved or not (by default = 'No')
    '''

    if all_itr == 'No':
        lst = []
        lst2 = ['train', 'validation'] + list(dict1['test_path'].keys())
        for i in lst2:
            if dict1['write_to'] == 'local':
                df = pd.read_csv(dir_name + '/' + i + '/' + i + '_decile_table.csv')
            if dict1['write_to'] =='s3':
                df = wr.s3.read_csv('s3://' + dict1['bucket_name'] + '/' + dir_name + '/' + i + '/' + i + '_decile_table.csv')
            df['dataset'] = i
            df.insert(0, 'dataset', df.pop('dataset'))
            lst.append(df)

        cmb_df = pd.concat(lst, ignore_index=True)
        
        save_files(dict1, cmb_df, dir_name, 'csv', 'combined_decile_table')
        # cmb_df.to_csv(dir_name + '/combined_decile_table.csv', index=False)

    if all_itr == 'Yes':
        lst1 = []

        if dict1['write_to'] == 'local':
            for file in glob.glob(dict1['directory_name']+'/*'):
                if not file.split('.')[-1] == 'csv':
                    df = pd.read_csv(file + '/combined_decile_table.csv')
                    df['itr'] = str(file.split('\\')[-1])
                    df.insert(1, 'itr', df.pop('itr'))
                    lst1.append(df)
                
            temp = pd.concat(lst1, ignore_index=True)
            temp.to_csv(dict1['directory_name'] + '/all_decile_table.csv', index=False)

        if dict1['write_to'] =='s3':
            s3 = boto3.client('s3')

            response = s3.list_objects_v2(Bucket=dict1['bucket_name'], Prefix=dict1['directory_name'], Delimiter='/')
            folder_names = [common_prefix['Prefix'] for common_prefix in response.get('CommonPrefixes', [])]

            for folder_name in folder_names:

                folder_response = s3.list_objects_v2(Bucket=dict1['bucket_name'], Prefix=folder_name, Delimiter='/')
                file_objects = folder_response.get('Contents', [])
                
                for file_object in file_objects:
                    # print("File object: ", file_object)
                    if file_object['Key'].endswith('.csv'): 
                        file_content = s3.get_object(Bucket=dict1['bucket_name'], Key=file_object['Key'])
                        csv_content = file_content['Body'].read().decode('utf-8')

                        df = pd.read_csv(StringIO(csv_content))
                        df['itr'] = str(file_object['Key'].split('/')[-2])
                        df.insert(1, 'itr', df.pop('itr'))
                        lst1.append(df)

            temp = pd.concat(lst1, ignore_index=True)
            temp.to_csv("s3://" + dict1['bucket_name'] + '/' + dict1['directory_name'] + 'all_decile_table.csv', index=False)
            

def xgb_classifier(dict1):
    '''
    Info : builds a xgbboost model

    Args = 
    dict1 : the dictionary passed as json object
    '''
    st_time = time.time()
    
    ## reading data files
    train_df, validation_df, test_df, dir_name, dir_train, dir_val, dir_test = get_data(dict1)

    non_calc_columns = [dict1['aggr_attr'],  dict1['target_col'], dict1['date_col']]
    
    feat_list = dict1['feature_list']
    logger.debug("number of features - {}".format(len(feat_list)))
    
    train_df = train_df[non_calc_columns + feat_list]
    validation_df = validation_df[non_calc_columns + feat_list]
    for i in range(len(test_df)):
        test_df[i] = test_df[i][non_calc_columns + feat_list]
    
    train_df = train_df.fillna(0.0)
    validation_df = validation_df.fillna(0.0)
    for i in range(len(test_df)):
        test_df[i] = test_df[i].fillna(0.0)
        
    logger.debug("TRAIN: {}".format(train_df.shape))
    logger.debug("VALIDATION: {}".format(validation_df.shape))
    qw = list(dict1['test_path'].keys())
    qw = [x.upper() for x in qw]
    for i in range(len(test_df)):
        logger.debug("{}: {}".format(qw[i], test_df[i].shape))
    
    ## hyper-parameter tuning
    best_estimator = hyper_parameter_tuning(dict1, train_df)   
    
    ## VIF calculation
    calculate_vif(dict1, train_df, dir_train, 'csv', 'vif')

    if dict1['hyperparameter_tuning']['method'] != '':
        dict1['xgb_params'] = best_estimator
    
    if dict1['write_to'] == 'local':
        with open(dir_name + "/best_params.txt", 'w') as f: 
            for key, value in dict1['xgb_params'].items(): 
                f.write('%s:%s\n' % (key, value))

    if dict1['write_to'] == 's3':
        s3 = boto3.client('s3')
        bucket_name = dict1['bucket_name']
        object_key = dict1['directory_name'] + dict1['itr']
        params_string = '\n'.join([f'{key}:{value}' for key, value in dict1['xgb_params'].items()])
        s3.put_object(Bucket=bucket_name, Key=(object_key + '/best_params.txt'), Body=params_string)

    ## xgboost model building
    logger.debug("Model Building Started")
    logger.debug("Model building start time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))
    xg_clf = xgb.XGBClassifier()
    xg_clf.set_params(**dict1['xgb_params'])
    
    xg_clf.fit(train_df[feat_list], train_df[dict1['target_col']])
    
    ## feature importance df
    feat_imp_df = pd.DataFrame()
    feat_imp_df["Feature_Name"] = feat_list
    feat_imp_df["Imp"] = xg_clf.feature_importances_

    feat_imp_df.sort_values(["Imp"], ascending=False, inplace=True)
    feat_imp_df.reset_index(drop=True, inplace=True)

    save_files(dict1, feat_imp_df, dir_train, 'csv', 'feat_imp')
    
    ## save pickle object
    save_files(dict1, xg_clf, dir_name, file_type = 'pkl')

    if dict1['write_to'] == 'local':

        writer = pd.ExcelWriter(dict1['directory_name']+ dict1['itr'] + '/classification_report.xlsx', engine='xlsxwriter')

    if dict1['write_to'] == 's3':

        excel_buffer = BytesIO()
        writer = pd.ExcelWriter(excel_buffer, engine='xlsxwriter')

    ## train data predictions
    train_df1, class_df_train = predictions(dict1, train_df, xg_clf, dataset = 'Train')
    class_df_train.to_excel(writer, sheet_name='train',index=False)
    save_files(dict1, train_df1, dir_train, 'csv', 'training_data_pred')
    
    # validation data predictions
    validation_df1, class_df_val = predictions(dict1, validation_df, xg_clf, dataset = 'Validation')
    class_df_val.to_excel(writer, sheet_name='validation',index=False)
    save_files(dict1, validation_df1, dir_val, 'csv', 'validation_data_pred')
    ## daywise deciling (val)
    if dict1['daywise_decile'].lower() == 'yes':
        logger.debug("Doing daywise deciling on validation dataset..")
        val_daywise_dict = {}
        val_daywise_class_rep_dict = {}
        val_daywise_lst = []
        for i in validation_df[dict1['date_col']].unique():
            val_subset = validation_df[validation_df[dict1['date_col']]==i].reset_index(drop=True)
            val_daywise_dict[i], val_daywise_class_rep_dict[i]  = predictions(dict1, val_subset, xg_clf, dataset = 'Validation_'+str(i), print_log = 'no')
            # save_files(dict1, val_daywise_dict[i], dir_val, 'csv', 'validation_' + str(i) + '_data_pred')
            try:
                val_temp = decile_table_plots(dict1, dir_val, val_daywise_dict[i], dict1['target_col'],'pred_prob_1','validation_'+str(i), save='no')
                val_daywise_lst.append(val_temp)
            except:
                val_temp = decile_table_plots(dict1, dir_val, val_daywise_dict[i], dict1['target_col'],'pred_prob_1.0','validation_'+str(i), save='no')
                val_daywise_lst.append(val_temp)

        val_daywise_df = pd.concat(val_daywise_lst, axis=0, ignore_index=True)
        save_files(dict1, val_daywise_df, dir_val, 'csv', 'validation_decile_table_daywise')

        logger.debug("Completed daywise deciling on validation dataset")
    else:
        logger.debug("Skipped daywise deciling on validation dataset..")
        
    # hold-out test data(10%)
    test_df1 = {}
    class_df_test = {}
    for i in range(len(test_df)):
        test_df1[i], class_df_test[i] = predictions(dict1, test_df[i], xg_clf, dataset = str(qw[i]).title())
        class_df_test[i].to_excel(writer, sheet_name=str(qw[i]).lower(),index=False)
        save_files(dict1, test_df1[i], dir_test[i], 'csv', str(qw[i]).lower() + '_data_pred')
        ## daywise deciling (test)
        if dict1['daywise_decile'].lower() == 'yes':
            logger.debug("Doing daywise deciling on {} dataset..".format(str(qw[i]).lower()))
            test_daywise_dict = {}
            test_daywise_class_rep_dict = {}
            test_daywise_lst = []
            for j in test_df[i][dict1['date_col']].unique():
                test_subset = test_df[i][test_df[i][dict1['date_col']]==j].reset_index(drop=True)
                test_daywise_dict[j], test_daywise_class_rep_dict[j]  = predictions(dict1, test_subset, xg_clf, dataset = str(qw[i]).title() + '_' +str(j), print_log = 'no')
                # save_files(dict1, test_daywise_dict[j], dir_test[i], 'csv', str(qw[i]).lower() + '_' + str(j) + '_data_pred')
                try:
                    test_temp = decile_table_plots(dict1, dir_test[i], test_daywise_dict[j], dict1['target_col'],'pred_prob_1', str(qw[i]).lower()+'_'+str(j), save='no')
                    test_daywise_lst.append(test_temp)
                except:
                    test_temp = decile_table_plots(dict1, dir_test[i], test_daywise_dict[j], dict1['target_col'],'pred_prob_1.0', str(qw[i]).lower()+'_'+str(j), save='no')
                    test_daywise_lst.append(test_temp)

            test_daywise_df = pd.concat(test_daywise_lst, axis=0, ignore_index=False)
            save_files(dict1, test_daywise_df, dir_test[i], 'csv', str(qw[i]).lower() + '_decile_table_daywise')

            logger.debug("Completed daywise deciling on {} dataset".format(str(qw[i]).lower()))    
        else:
            logger.debug("Skipped daywise deciling on {} dataset..".format(str(qw[i]).lower()))

    if dict1['write_to'] == 'local':
        try:
            writer.save()
        except:
            writer.close()

    if dict1['write_to'] == 's3':
        try:
            writer.save()
            excel_buffer.seek(0)
        except:
            writer.close()
            excel_buffer.seek(0)

        bucket_name_class_df = dict1['bucket_name']  
        file_name_class =  dict1['directory_name'] + dict1['itr'] + '/classification_report.xlsx' 
        # Upload the Excel file to S3
        s3 = boto3.client('s3')
        s3.upload_fileobj(excel_buffer, bucket_name_class_df, file_name_class)

    logger.debug("Saved Classification Report")
    
    logger.debug("Model building end time: {}".format(datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')))
    
    # decile tables 
    logger.debug("Generating decile tables..")
    try:
        decile_table_plots(dict1, dir_train, train_df1, dict1['target_col'],'pred_prob_1','train')
        decile_table_plots(dict1, dir_val, validation_df1, dict1['target_col'],'pred_prob_1','validation')
        for i in range(len(test_df)):
            decile_table_plots(dict1, dir_test[i], test_df1[i], dict1['target_col'],'pred_prob_1',str(qw[i]).lower())
    except:
        decile_table_plots(dict1, dir_train, train_df1, dict1['target_col'],'pred_prob_1.0','train')
        decile_table_plots(dict1, dir_val, validation_df1, dict1['target_col'],'pred_prob_1.0','validation')
        for i in range(len(test_df)):
            decile_table_plots(dict1, dir_test[i], test_df1[i], dict1['target_col'],'pred_prob_1.0',str(qw[i]).lower())

    combine_decile_tables(dict1, dir_name, ext='csv', file_name='', all_itr='No')
    combine_decile_tables(dict1, dir_name, ext='csv', file_name='', all_itr='Yes')
    
    logger.debug("DONE")
    logger.debug("Time Taken: {}  mins".format(round(((time.time() - st_time)/60),2)))          


if __name__ == '__main__':
    dictt = get_dict()
    xgb_classifier(dictt)
