How to run batch file:
1) open anaconda command prompt
2) navigate to the folder location where the xgb_model.py file is located
3) run this command -->  <name of batch file>.bat  (eg: run.bat) {here the name of batch file is run}


How to use/create the dictionary:
1) read_from : the location from where you want to read the data files [accepted value = 's3', 'local']

2) write_to : the location where you want to write/save the output files [accepted values = 's3', 'local']

3) bucket_name : the bucket-name in s3, if you want to store/save the output files in s3 

4) itr: the iteration number [accepts any value passed in string] 

5) directory_name: the directory name in s3 OR the directory location in local system where the output files are to be saved

6) ext: the data files extension format for reading train/test/validation dataframes

7) train_path: the s3 or local path where training data is stored

8) val_path: the s3 or local path where validation data is stored

9) test_path: a dictionary of s3 or local test paths where the data is stored 

10) daywise_decile: if daywise deciling is required for validaton and test datasets [accepted values = 'yes', 'no']

11) date_col: the date column name in the dataframe (required for daywise deciling)

12) target_col: the name of target column in your dataset (eg: 'tgt_5d')

13) aggr_attr: the name of the aggregate attribute in your dataframe (eg: 'clientcode')

14) feature_list: a list of features from the dataframe on which you want to build/tune the xgboost model

15) hyperparameter_tuning: 3 ways to tune your xgboost model to get a set of parameters to start with. As of now it supports RandomSearch, BayesianSearch and GridSearch.
	a) method: the hyper-parameter tuning method which you want to use. 
		   can pass a blank string if you do not wish to hyper-parameter tune the model
		   [accepted values = 'random', 'bayesian', 'grid', '']
	b) params: a dictionary of xgboost parameter values which you want to tune
	c) StratifiedKFold_params: a dictionary of parameters for StratifiedKfold cross validation which is called to split the training dataset
	d) bayesian_params: a dictionary of parameters for bayesian search cv if you want to run bayesian search
	e) random_params: a dictionary of parameters for random search cv if you want to run random search
	f) grid_params: a dictionary of parameters for grid search cv if you want to run grid search

16) xgb_params: a dictionary of xgboost parameters on which you want to build the xgboost model

