# Import necessary libraries and modules
import ast
import h5py
import math
import os.path
import pickle
import sys
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from copy import deepcopy
from tensorflow import keras
from tensorflow.keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, CSVLogger, TensorBoard
from tensorflow.keras.layers import LSTM, Dense, concatenate, Activation, BatchNormalization, Dropout
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.optimizers import Adam, Adagrad, Adamax, SGD, RMSprop, Nadam
from tensorflow.keras.utils import normalize
from tensorflow.keras.metrics import AUC

# Set pandas display options
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

def Define_Multihead_Network(seq_feat, n_fet, steps, lstm_units, layers_mlp1, layers_mlp2, initializers_mlp1,
                             initializers_mlp2, dropout_mlp1, dropout_mlp2, batchNormalization_mlp1,
                             batchNormalization_mlp2, regularizer_mlp1, regularizer_mlp2, loss, optimizer,
                             metric, lr):
    """
    Define the Multihead Network model.

    Arguments:
    seq_feat -- Number of features in the sequential input
    n_fet -- Number of features in the static input
    steps -- Number of time steps in the sequential input
    lstm_units -- List of LSTM units for each layer in the sequential model
    layers_mlp1 -- List of units for each layer in the MLP for static features
    layers_mlp2 -- List of units for each layer in the MLP after concatenation
    initializers_mlp1 -- List of initializers for each layer in the MLP for static features
    initializers_mlp2 -- List of initializers for each layer in the MLP after concatenation
    dropout_mlp1 -- List of dropout rates for each layer of the MLP for static features
    dropout_mlp2 -- List of dropout rates for each layer of the MLP after concatenation
    batchNormalization_mlp1 -- Boolean indicating whether to use batch normalization for the MLP for static features
    batchNormalization_mlp2 -- Boolean indicating whether to use batch normalization after concatenation
    regularizer_mlp1 -- Boolean indicating whether to use regularization for the MLP for static features
    regularizer_mlp2 -- Boolean indicating whether to use regularization after concatenation
    loss -- Loss function for model training
    optimizer -- Optimizer algorithm for model training
    metric -- Metrics to evaluate the model during training
    lr -- Learning rate for the optimizer

    Returns:
    model -- Multihead Network model
    """

    # Static model
    static_model = Sequential()

    # Create MLP layers for static features
    for i in range(len(layers_mlp1)):
        if(i == 0):
            if regularizer_mlp1:
                # Add Dense layer with input shape and regularization
                static_model.add(Dense(layers_mlp1[i], input_shape=(n_fet,),
                                       kernel_regularizer=regularizers.l2(0.01), kernel_initializer=initializers_mlp1[i]))
            else:
                # Add Dense layer with input shape
                static_model.add(Dense(layers_mlp1[i], input_shape=(n_fet,), kernel_initializer=initializers_mlp1[i]))
            static_model.add(Activation('relu'))

            if dropout_mlp1[i] != 0.0:
                # Add Dropout layer
                static_model.add(Dropout(dropout_mlp1[i]))

            if batchNormalization_mlp1:
                # Add Batch Normalization layer
                static_model.add(BatchNormalization())
        else:
            if regularizer_mlp1:
                # Add Dense layer with regularization
                static_model.add(Dense(layers_mlp1[i], kernel_regularizer=regularizers.l2(0.01),
                                       kernel_initializer=initializers_mlp1[i]))
            else:
                # Add Dense layer
                static_model.add(Dense(layers_mlp1[i], kernel_initializer=initializers_mlp1[i]))
            static_model.add(Activation('relu'))

            if dropout_mlp1[i] != 0.0:
                # Add Dropout layer
                static_model.add(Dropout(dropout_mlp1[i]))

            if batchNormalization_mlp1:
                # Add Batch Normalization layer
                static_model.add(BatchNormalization())

    # Sequential model
    sequential_model = Sequential()

    # Create LSTM layers for sequential features
    for k in range(len(lstm_units)):
        if (k < (len(lstm_units)-1)):
            # Add LSTM layer with return_sequences=True for intermediate layers
            sequential_model.add(LSTM(lstm_units[k], return_sequences=True, input_shape=(steps, seq_feat)))
        else:
            # Add LSTM layer without return_sequences=True for last layer
            sequential_model.add(LSTM(lstm_units[k], input_shape=(steps, seq_feat)))

    # Merge the models
    merged_model = concatenate([static_model.output, sequential_model.output])

    # Create MLP layers after concatenation
    for j in range(len(layers_mlp2)):
        if regularizer_mlp2:
            # Add Dense layer with regularization
            merged_model = Dense(layers_mlp2[j], activation='relu',
                                 kernel_regularizer=regularizers.l2(0.01),
                                 kernel_initializer=initializers_mlp2[j])(merged_model)
        else:
            # Add Dense layer
            merged_model = Dense(layers_mlp2[j], activation='relu',
                                 kernel_initializer=initializers_mlp2[j])(merged_model)

        if dropout_mlp2[j] != 0.0:
            # Add Dropout layer
            merged_model = (Dropout(dropout_mlp2[j]))(merged_model)

        if batchNormalization_mlp2:
            # Add Batch Normalization layer
            merged_model = merged_model.add(BatchNormalization())(merged_model)

    # Output layer
    merged_model = Dense(1, activation='sigmoid')(merged_model)

    # Create the final model
    model = keras.Model(inputs=[static_model.input, sequential_model.input], outputs=merged_model)

    # Compile the model
    if optimizer == 'Adam':
        opt = Adam(lr=lr)
    elif optimizer == "Adagrad":
        opt = Adagrad(lr=lr)
    elif optimizer == "Adamax":
        opt = Adamax(lr=lr)
    elif optimizer == "SGD":
        opt = SGD(lr=lr)
    elif optimizer == "RMSprop":
        opt = RMSprop(lr=lr)
    elif optimizer == "Nadam":
        opt = Nadam(lr=lr)

    model.compile(optimizer=opt, loss=loss, metrics=metric)

    return model


def Train_LSTM_Model(x_seq, x_static, y, p_epochs, p_batchsize, p_iter, seq_feat, n_fet, steps, lstm_units,
                     layers_mlp1, layers_mlp2, initializers_mlp1, initializers_mlp2, dropout_mlp1, dropout_mlp2,
                     batchNormalization_mlp1, batchNormalization_mlp2, regularizer_mlp1, regularizer_mlp2, loss,
                     optimizer, metric, lr):
    """
    Train the LSTM model.

    Arguments:
    x_seq -- Sequential input features
    x_static -- Static input features
    y -- Target labels
    p_epochs -- Number of epochs for training
    p_batchsize -- Batch size for training
    p_iter -- Iteration name or identifier
    seq_feat -- Number of features in the sequential input
    n_fet -- Number of features in the static input
    steps -- Number of time steps in the sequential input
    lstm_units -- List of LSTM units for each layer in the sequential model
    layers_mlp1 -- List of units for each layer in the MLP for static features
    layers_mlp2 -- List of units for each layer in the MLP after concatenation
    initializers_mlp1 -- List of initializers for each layer in the MLP for static features
    initializers_mlp2 -- List of initializers for each layer in the MLP after concatenation
    dropout_mlp1 -- List of dropout rates for each layer of the MLP for static features
    dropout_mlp2 -- List of dropout rates for each layer of the MLP after concatenation
    batchNormalization_mlp1 -- Boolean indicating whether to use batch normalization for the MLP for static features
    batchNormalization_mlp2 -- Boolean indicating whether to use batch normalization after concatenation
    regularizer_mlp1 -- Boolean indicating whether to use regularization for the MLP for static features
    regularizer_mlp2 -- Boolean indicating whether to use regularization after concatenation
    loss -- Loss function for model training
    optimizer -- Optimizer algorithm for model training
    metric -- Metrics to evaluate the model during training
    lr -- Learning rate for the optimizer

    Returns:
    history -- Training history
    """

    # Define the Multihead Network model
    model_path = f"./Trained_Model/LSTM_{p_iter}.hdf5"
    reduce_lr = ReduceLROnPlateau(monitor='val_accuracy', factor=0.9, patience=30, min_lr=0.000001, verbose=1)
    checkpointer = ModelCheckpoint(filepath=model_path, verbose=1, save_best_only=True)
    tensorboard = TensorBoard(log_dir=f"./tensor_logs/{p_iter}", histogram_freq=2, write_graph=True, write_images=False)

    mhn_model = Define_Multihead_Network(seq_feat, n_fet, steps, lstm_units, layers_mlp1, layers_mlp2,
                                         initializers_mlp1, initializers_mlp2, dropout_mlp1, dropout_mlp2,
                                         batchNormalization_mlp1, batchNormalization_mlp2, regularizer_mlp1,
                                         regularizer_mlp2, loss, optimizer, metric, lr)

    # Train the model
    history = mhn_model.fit([x_static, x_seq], y, epochs=p_epochs, batch_size=p_batchsize, validation_split=0.20,
                            callbacks=[reduce_lr, checkpointer, tensorboard], shuffle=True)

    return history


def decile_table_plots(df, target_col, pred_probabilities, name):
    """
    Generate decile table and plots.

    Arguments:
    df -- Dataframe containing target labels and predicted probabilities
    target_col -- Name of the target column
    pred_probabilities -- Name of the column containing predicted probabilities
    name -- Name or identifier for the decile table and plots

    Returns:
    decile_df -- Decile table dataframe
    """

    op_df = deepcopy(df)
    start_range = 0
    op_df = op_df.sort_values([pred_probabilities], ascending=False)
    ten_per = np.ceil(0.1 * op_df.shape[0])
    decile_df = pd.DataFrame()
    decile_df["decile"] = np.arange(1, 11)
    decile_df["decile"] = "decile_" + decile_df["decile"].astype(str)
    mean_list = []
    min_list = []
    max_list = []
    number_frauds_list = []
    number_rows_list = []
    op_df["decile_label"] = ""
    op_df = op_df.reset_index(drop=True)

    # Calculate decile statistics
    for count in range(0, 10):
        end_range = int(((count + 1) * ten_per) - 1)
        op_df.loc[start_range:end_range, "decile_label"] = "decile_" + str(count + 1)
        mean_decile = op_df.loc[start_range:end_range, pred_probabilities].mean()
        min_decile = op_df.loc[start_range:end_range, pred_probabilities].min()
        max_decile = op_df.loc[start_range:end_range, pred_probabilities].max()
        total = len(op_df.loc[start_range:end_range, pred_probabilities])
        number_frauds = op_df.loc[start_range:end_range, target_col].sum()
        start_range = end_range + 1

        mean_list.append(mean_decile)
        min_list.append(min_decile)
        max_list.append(max_decile)
        number_frauds_list.append(number_frauds)
        number_rows_list.append(total)

    # Build decile table
    decile_df["mean_prob"] = mean_list
    decile_df["min_prob"] = min_list
    decile_df['max_prob'] = max_list
    decile_df["number_events"] = number_frauds_list
    decile_df["total"] = number_rows_list
    decile_df['number_non_events'] = decile_df['total'] - decile_df['number_events']

    # Reorder columns
    decile_df = decile_df[['decile', 'mean_prob', 'min_prob', 'max_prob', 'number_events', 'number_non_events', 'total']]
    decile_df = decile_df.round(2)

    # Calculate cumulative statistics
    decile_df['cum_event'] = decile_df['number_events'].cumsum()
    decile_df['cum_non_event'] = decile_df['number_non_events'].cumsum()
    decile_df['cum_total'] = decile_df['total'].cumsum()
    decile_df['%cum_total'] = (decile_df['cum_total'] / sum(decile_df['total']) * 100).round(0)
    decile_df['%cum_event'] = (decile_df['cum_event'] / sum(decile_df['number_events']) * 100).round(2)
    decile_df['%cum_non_event'] = (decile_df['cum_non_event'] / sum(decile_df['number_non_events']) * 100).round(2)
    decile_df['actual_event_rate'] = round((sum(decile_df['number_events']) / sum(decile_df['total']) * 100), 2)
    decile_df['response_rate_decilewise'] = round((decile_df['number_events'] / decile_df['total'] * 100), 2)
    decile_df['Lift'] = (decile_df['%cum_event'] / decile_df['%cum_total']).round(2)
    decile_df['KS'] = decile_df['%cum_event'] - decile_df['%cum_non_event']
    decile_df['TP'] = decile_df['cum_event']
    decile_df['TN'] = sum(decile_df['number_non_events']) - decile_df['cum_non_event']
    decile_df['FP'] = decile_df['cum_non_event']
    decile_df['FN'] = sum(decile_df['number_events']) - decile_df['cum_event']
    decile_df['Recall'] = ((decile_df['TP'] / (decile_df['TP'] + decile_df['FN'])) * 100).round(0)
    decile_df['Precision'] = ((decile_df['TP'] / (decile_df['TP'] + decile_df['FP'])) * 100).round(0)
    decile_df['Accuracy'] = ((decile_df['TP'] + decile_df['TN']) / sum(decile_df['total']) * 100).round(0)

    # Reorder columns
    decile_df = decile_df[['decile', 'mean_prob', 'min_prob', 'max_prob', 'number_events', 'number_non_events',
                           'total', 'actual_event_rate', 'response_rate_decilewise', 'cum_event', 'cum_non_event',
                           'cum_total', '%cum_total', '%cum_event', '%cum_non_event', 'Lift', 'KS', 'TP', 'TN',
                           'FP', 'FN', 'Recall', 'Precision', 'Accuracy']]

    return decile_df


def Generate_Model_Results(p_iter, x_train_static, x_train_seq, y_train, x_test_static, x_test_seq, y_test):
    """
    Generate model results and decile tables for training and testing datasets.

    Arguments:
    p_iter -- Iteration name or identifier
    x_train_static -- Training set static input features
    x_train_seq -- Training set sequential input features
    y_train -- Training set target labels
    x_test_static -- Testing set static input features
    x_test_seq -- Testing set sequential input features
    y_test -- Testing set target labels
    """

    # Load the trained model
    model_path = f"./Trained_Model/LSTM_{p_iter}.hdf5"
    model_file = h5py.File(model_path, 'r')
    model_lstm = keras.models.load_model(model_file)
    model_file.close()

    # Create dataframes for training and testing results
    df_train_res = pd.DataFrame(y_train)
    df_train_res.columns = ['target']
    df_train_res['pred_prob'] = model_lstm.predict([x_train_static, x_train_seq])

    df_test_res = pd.DataFrame(y_test)
    df_test_res.columns = ['target']
    df_test_res['pred_prob'] = model_lstm.predict([x_test_static, x_test_seq])

    # Generate decile tables and save as CSV
    decile_train = decile_table_plots(df_train_res, 'target', 'pred_prob', 'df_train_res')
    decile_test = decile_table_plots(df_test_res, 'target', 'pred_prob', 'df_test_res')

    decile_train.to_csv(f"./Train_Results/TrainResults_LSTM_{p_iter}.csv", index=False)
    decile_test.to_csv(f"./Test_Results/TestResults_LSTM_{p_iter}.csv", index=False)


def main():
    """
    Main function.
    """

    print("function")

    # Read command-line arguments
    a_epoch = int(sys.argv[1])
    a_batchs = int(sys.argv[2])
    a_itr_name = str(sys.argv[3])
    a_seq_fet = int(sys.argv[4])
    a_static_fet = int(sys.argv[5])
    a_steps = int(sys.argv[6])
    a_lstm_units = ast.literal_eval(sys.argv[7])
    a_layer_mlp1 = ast.literal_eval(sys.argv[8])
    a_layer_mlp2 = ast.literal_eval(sys.argv[9])
    a_ini_mlp1 = ast.literal_eval(sys.argv[10])
    a_ini_mlp2 = ast.literal_eval(sys.argv[11])
    a_dropout_mlp1 = ast.literal_eval(sys.argv[12])
    a_dropout_mlp2 = ast.literal_eval(sys.argv[13])
    a_bn_mlp1 = int(sys.argv[14])
    a_bn_mlp2 = int(sys.argv[15])
    a_regu_mlp1 = int(sys.argv[16])
    a_regu_mlp2 = int(sys.argv[17])
    a_loss = sys.argv[18]
    a_opt = sys.argv[19]
    a_metric = ast.literal_eval(sys.argv[20])
    a_lr = float(sys.argv[21])
    a_input_files = ast.literal_eval(sys.argv[22])

    # Load data from input files
    x_static = np.load(f"./data_arrays/{a_input_files[0]}")
    x_seq = np.load(f"./data_arrays/{a_input_files[1]}")
    y = np.load(f"./data_arrays/{a_input_files[2]}")
    x_static_test = np.load(f"./data_arrays/{a_input_files[3]}")
    x_seq_test = np.load(f"./data_arrays/{a_input_files[4]}")
    y_test = np.load(f"./data_arrays/{a_input_files[5]}")

    # Train the LSTM model and generate results
    history = Train_LSTM_Model(x_seq, x_static, y, a_epoch, a_batchs, a_itr_name, a_seq_fet, a_static_fet, a_steps,
                               a_lstm_units, a_layer_mlp1, a_layer_mlp2, a_ini_mlp1, a_ini_mlp2, a_dropout_mlp1,
                               a_dropout_mlp2, a_bn_mlp1, a_bn_mlp2, a_regu_mlp1, a_regu_mlp2, a_loss, a_opt,
                               a_metric, a_lr)

    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    #plt.to_png
    plt.savefig(f"./Train_Val_Loss/Train_Val_Loss_{a_itr_name}")
    
    
    # Generate model results and decile tables for training and testing datasets
    Generate_Model_Results(a_itr_name, x_static, x_seq, y, x_static_test, x_seq_test, y_test)

    # # Save the training history
    # with open(f"./Training_History/history_{a_itr_name}.pkl", 'wb') as file:
    #     pickle.dump(history.history, file)


if __name__ == "__main__":
    main()
